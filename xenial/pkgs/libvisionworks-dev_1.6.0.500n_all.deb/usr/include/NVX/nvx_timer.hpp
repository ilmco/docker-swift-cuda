/*
 * Copyright (c) 2012-2015, NVIDIA CORPORATION.  All rights reserved.
 *
 * NVIDIA Corporation and its licensors retain all intellectual property
 * and proprietary rights in and to this software, related documentation
 * and any modifications thereto.  Any use, reproduction, disclosure or
 * distribution of this software and related documentation without an express
 * license agreement from NVIDIA Corporation is strictly prohibited.
 */

/**
 * \file
 * \brief NVIDIA VisionWorks Simple Timer API
 */

#ifndef NVX_TIMER_HPP
#define NVX_TIMER_HPP

#include "nvx.h"

/**
 * \brief NVIDIA VisionWorks Framework and Primitives C++ API
 */
namespace nvx {

/**
 * \ingroup nvx_framework_timer
 * \brief `%Timer` class interface.
 *
 * ### Sample code ###
 *
 * @snippet framework.cpp timer
 */
class NVX_CXX_API Timer
{
public:
    /**
     * \brief Timer class constructor.
     *
     * \param [in] _dumpStatistics  Specifies a flag variable that controls whether to print timer
     *                                  statistics when it's destructor is called.
     * \param [in] _name            Specifies the label of the timer. If \p _dumpStatistics
     *                                  is true, this label prints in the log
     *                                  when the timer object desctructor is called.
     */
    Timer(bool _dumpStatistics=false, const char* _name = "");

    /**
     * \brief Destructor.
     */
    ~Timer();

    /**
     * \brief Starts (or restarts) timer.
     */
    void tic();

    /**
     * \brief Returns the elapsed time since the most recent tic() function call.
     *
     * \return The elapsed time since the most recent call to the tic() function (in ms).
     */
    double toc();

private:
    char name[255];
    vx_perf_t perf;
    bool dumpStatistics;
};

}

/**
 * \brief Creates a static instance of the \ref nvx::Timer class and calls the \ref nvx::Timer::tic() method.
 * \ingroup nvx_framework_timer
 *
 * \note The created object dumps statistic at a deallocation stage.
 *
 * \param [in] suffix Defines a suffix for the object name.
 * \param [in] str    Defines an internal name for the object. The internal name identifies
 *                    the timer instance in the statistic dumping stage.
 */
#define NVX_TIMER(suffix, str) static nvx::Timer timer_##suffix(true, str); timer_##suffix.tic()

/**
 * \brief Stops the timer with the suffix `suffix`.
 * \ingroup nvx_framework_timer
 *
 * \param [in] suffix The timer's name suffix.
 */
#define NVX_TIMEROFF(suffix) (void)timer_##suffix.toc()

#endif
