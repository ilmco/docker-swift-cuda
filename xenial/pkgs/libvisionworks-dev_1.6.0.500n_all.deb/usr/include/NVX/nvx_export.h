
#ifndef NVX_EXPORT_H
#define NVX_EXPORT_H

#ifdef NVX_STATIC_DEFINE
#  define NVX_EXPORT
#  define NVX_NO_EXPORT
#else
#  ifndef NVX_EXPORT
#    ifdef visionworks_EXPORTS
        /* We are building this library */
#      define NVX_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define NVX_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef NVX_NO_EXPORT
#    define NVX_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef NVX_DEPRECATED
#  define NVX_DEPRECATED __attribute__ ((__deprecated__))
#  define NVX_DEPRECATED_EXPORT NVX_EXPORT __attribute__ ((__deprecated__))
#  define NVX_DEPRECATED_NO_EXPORT NVX_NO_EXPORT __attribute__ ((__deprecated__))
#endif

#define DEFINE_NO_DEPRECATED 0
#if DEFINE_NO_DEPRECATED
# define NVX_NO_DEPRECATED
#endif

#endif
