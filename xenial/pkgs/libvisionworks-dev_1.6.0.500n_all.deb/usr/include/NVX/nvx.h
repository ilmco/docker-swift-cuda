/*
 * Copyright (c) 2012-2016, NVIDIA CORPORATION.  All rights reserved.
 *
 * NVIDIA Corporation and its licensors retain all intellectual property
 * and proprietary rights in and to this software, related documentation
 * and any modifications thereto.  Any use, reproduction, disclosure or
 * distribution of this software and related documentation without an express
 * license agreement from NVIDIA Corporation is strictly prohibited.
 */

/**
 * \file
 * \brief NVIDIA VisionWorks Framework and Primitives Extension API
 */

#ifndef NVX_H
#define NVX_H

//----------------------------------------------------------------------------
// Include
//----------------------------------------------------------------------------

#include <VX/vx.h>
#include <VX/vxu.h>
#include <NVX/nvx_api_macros.h>
#include <NVX/nvx_compatibility.h>

//----------------------------------------------------------------------------
// Framework : Version Information
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_framework_version
 * \brief VisionWorks module version.
 */
typedef struct _nvx_module_version_t {
    vx_uint32 major;  /**< \brief Major version component. */
    vx_uint32 minor;  /**< \brief Minor version component. */
    vx_uint32 patch;  /**< \brief Patch version component. */
    char suffix[12];  /**< \brief Version suffix. Empty in a production release. */
} nvx_module_version_t;

/**
 * \ingroup nvx_framework_version
 * \brief VisionWorks library version information.
 */
typedef struct _nvx_version_info_t {
    nvx_module_version_t visionworks_version;

    vx_uint32 openvx_major_version;       /**< \brief Major version of OpenVX standard implemented by VisionWorks library. */
    vx_uint32 openvx_minor_version;       /**< \brief Minor version of OpenVX standard implemented by VisionWorks library. */
    vx_uint32 openvx_patch_version;       /**< \brief Patch version of OpenVX standard implemented by VisionWorks library. */
} nvx_version_info_t;

/**
 * \ingroup nvx_framework_version
 * \brief Gets information about VisionWorks library version.
 *
 * \param [out] info    Structure with information to fill.
 */
NVX_C_API void nvxGetVersionInfo(nvx_version_info_t *info);

//----------------------------------------------------------------------------
// Framework : Debug Log
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_framework_debug_log
 * \brief The debug log zone.
 */
enum nvx_log_zone_e {
    /*! \brief Error messages. */
    NVX_LOG_ZONE_ERROR,
    /*! \brief Warning messages. */
    NVX_LOG_ZONE_WARNING,
    /*! \brief API calls. */
    NVX_LOG_ZONE_API,
    /*! \brief Information related to graphs verification, execution, and to the execution of primitives in immediate mode. */
    NVX_LOG_ZONE_GRAPH,
    /*! \brief Information about data objects. */
    NVX_LOG_ZONE_DATA,
    /*! \brief Memory allocation / deallocation information. */
    NVX_LOG_ZONE_MEMORY,
    /*! \brief Performance messages. */
    NVX_LOG_ZONE_PERF,
    /*! \brief Messages that do not fit any other category. */
    NVX_LOG_ZONE_MISC,
};

/**
 * \ingroup nvx_framework_debug_log
 * \brief Enables or disables debug log zone.
 *
 * \param [in] zone         Specifies a zone to set.
 * \param [in] enabled      Specifies a zone status:
 *                              (\ref vx_true_e to enable the zone,
 *                               \ref vx_false_e to disable the zone).
 *
 * \return A \ref vx_status_e enumerated value.
 * \retval VX_SUCCESS                   Debug log zone was successfully set.
 * \retval VX_ERROR_INVALID_PARAMETERS  The value passed as \p zone was not a \ref nvx_log_zone_e.
 */
NVX_C_API vx_status nvxSetLogZone(vx_enum zone, vx_bool enabled);

//----------------------------------------------------------------------------
// Framework : User Kernel Extension
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_framework_basic_types
 * \brief Defines the additional set of supported enumerations.
 */
enum nvx_enum_e {
    NVX_ENUM_MUTABILITY  = 0x00, /*!< \brief Parameter mutability. */
};

/**
 * \ingroup nvx_framework_kernel
 * \brief Defines the mutability state of custom kernel parameter.
 */
enum nvx_mutability_e {
    /*! \brief A Change of the parameter does not imply a node re-initialization. */
    NVX_MUTABLE_INIT = VX_ENUM_BASE(VX_ID_NVIDIA, NVX_ENUM_MUTABILITY) + 0x0,
    /*! \brief A Change of the parameter meta-data implies a node re-initialization.*/
    NVX_METADATA_IMMUTABLE_INIT = VX_ENUM_BASE(VX_ID_NVIDIA, NVX_ENUM_MUTABILITY) + 0x1,
    /*! \brief A Change of the parameter meta-data or value implies a node re-initialization.*/
    NVX_IMMUTABLE_INIT = VX_ENUM_BASE(VX_ID_NVIDIA, NVX_ENUM_MUTABILITY) + 0x2,
};

/*! \brief Allows users to set the mutability of the custom kernel. By default, kernel parameters are
 *         set to NVX_MUTABLE_INIT
 * \param [in] kernel The reference to the kernel added with <tt>\ref vxAddUserKernel</tt>.
 * \param [in] index The index of the parameter to add.
 * \param [in] mutability The mutability of the parameter with regard to the kernel initialization function.
 * This must be a value from <tt>\ref nvx_mutability_e</tt>.
 * \return A <tt>\ref vx_status_e</tt> enumerated value.
 * \retval VX_SUCCESS Parameter is successfully set on kernel.
 * \retval VX_ERROR_INVALID_REFERENCE The value passed as kernel was not a \c vx_kernel.
 * \pre <tt>\ref vxAddUserKernel</tt>
 * \ingroup nvx_framework_kernel
 */
NVX_C_API vx_status nvxSetKernelParameterMutability(vx_kernel kernel, vx_uint32 index, vx_enum mutability);

//----------------------------------------------------------------------------
// Framework : Types Extensions
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_framework_basic_types
 * \brief Defines additional types.
 */
enum nvx_type_e {
    NVX_TYPE_POINT2F = VX_TYPE_VENDOR_STRUCT_START,     /**< \brief A \ref nvx_point2f_t */
    NVX_TYPE_POINT3F,                                   /**< \brief A \ref nvx_point3f_t */
    NVX_TYPE_POINT4F,                                   /**< \brief A \ref nvx_point4f_t */
    NVX_TYPE_KEYPOINTF,                                 /**< \brief A \ref nvx_keypointf_t */

    /** \brief A floating value for comparison between structs and objects */
    NVX_TYPE_STRUCT_MAX,

    /** \brief A floating value used for bound checking the VisionWorks object types. */
    NVX_TYPE_OBJECT_MAX = VX_TYPE_VENDOR_OBJECT_START,
};

/**
 * \ingroup nvx_framework_error_management
 * \brief Defines additional error codes.
 */
enum nvx_status_e {
    NVX_ERROR_NO_CUDA_GPU          = -1000, /**< \brief Indicates that no CUDA-capable GPU was found. */
    NVX_ERROR_UNSUPPORTED_CUDA_GPU = -1001, /**< \brief Indicates that the CUDA-capable GPU is not supported. */
    NVX_ERROR_CUDA_FAILURE         = -1002, /**< \brief Indicates internal CUDA failure. */
};

/**
 * \ingroup nvx_framework_basic_types
 * \brief The extended set of kernels provided by NVIDIA.
 */
#define NVX_LIBRARY_NVIDIA (0x0)

/*!
 * \ingroup nvx_framework_basic_types
 * \brief Defines a list of extended vision kernels.
 */
enum nvx_kernel_e {
    /*! \brief Specifies Harris Track Kernel. */
    NVX_KERNEL_HARRIS_TRACK = VX_KERNEL_BASE(VX_ID_NVIDIA, NVX_LIBRARY_NVIDIA),
    /*! \brief Specifies FAST Track Kernel. */
    NVX_KERNEL_FAST_TRACK,
    /*! \brief Specifies Flip Image Kernel. */
    NVX_KERNEL_FLIP_IMAGE,
    /*! \brief Specifies Copy Image Kernel. */
    NVX_KERNEL_COPY_IMAGE,
    /*! \brief Specifies Semi Global Matching Kernel. */
    NVX_KERNEL_SEMI_GLOBAL_MATCHING,
    /*! \brief Specifies Hough Lines Kernel. */
    NVX_KERNEL_HOUGH_LINES,
    /*! \brief Specifies Hough Segments Kernel. */
    NVX_KERNEL_HOUGH_SEGMENTS,
    /*! \brief Specifies Hough Circles Kernel. */
    NVX_KERNEL_HOUGH_CIRCLES,
    /*! \brief Specifies Scharr 3 x 3 Kernel. */
    NVX_KERNEL_SCHARR_3x3,
    /*! \brief Specifies Laplacian 3 x 3 Kernel. */
    NVX_KERNEL_LAPLACIAN_3x3,
    /*! \brief Specifies Median Flow Kernel. */
    NVX_KERNEL_MEDIAN_FLOW,
    /*! \brief Specifies Stereo Block Matching Kernel. */
    NVX_KERNEL_STEREO_BLOCK_MATCHING,
    /*! \brief Specifies Find Homography Kernel. */
    NVX_KERNEL_FIND_HOMOGRAPHY,
    /*! \brief Specifies Create Motion Field Kernel. */
    NVX_KERNEL_CREATE_MOTION_FIELD,
    /*! \brief Specifies Refine Motion Field Kernel. */
    NVX_KERNEL_REFINE_MOTION_FIELD,
    /*! \brief Specifies Partition Motion Field Kernel. */
    NVX_KERNEL_PARTITION_MOTION_FIELD,
    /*! \brief Specifies Multiply by Scalar Kernel. */
    NVX_KERNEL_MULTIPLY_BY_SCALAR,
    /*! \brief Specifies SGBM Compute Cost BT Kernel. */
    NVX_KERNEL_SGBM_COMPUTE_COST_BT,
    /*! \brief Specifies SGBM Aggregate Cost Kernel. */
    NVX_KERNEL_SGBM_AGGREGATE_COST_SCANLINES,
    /*! \brief Specifies SGBM Convolve Cost Kernel. */
    NVX_KERNEL_SGBM_CONVOLVE_COST,
    /*! \brief Specifies SGBM Compute Disparity Kernel. */
    NVX_KERNEL_SGBM_COMPUTE_DISPARITY,
    /*! \brief Specifies SGBM Compute Modified Cost BT Kernel. */
    NVX_KERNEL_SGBM_COMPUTE_MODIFIED_COST_BT,
    /*! \brief Specifies SGBM Filter Cost Kernel. */
    NVX_KERNEL_SGBM_FILTER_COST,
    /*! \brief Specifies SGBM Pyramidal Cost Prior Kernel. */
    NVX_KERNEL_SGBM_PYRAMIDAL_COST_PRIOR,
    /*! \brief Specifies SGBM Pyramidal Disparity Merge Kernel. */
    NVX_KERNEL_SGBM_PYRAMIDAL_DISPARITY_MERGE,
    /*! \brief Specifies SGBM Census Transform Kernel. */
    NVX_KERNEL_SGBM_CENSUS_TRANSFORM,
    /*! \brief Specifies SGBM Compute Cost Hamming Kernel. */
    NVX_KERNEL_SGBM_COMPUTE_COST_HAMMING,
};

//----------------------------------------------------------------------------
// Framework : Point Types
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_framework_point
 * \brief Defines a 2D point (float coordinates).
 */
typedef struct _nvx_point2f_t {
    vx_float32 x;   /**< \brief The X coordinate. */
    vx_float32 y;   /**< \brief The Y coordinate. */
} nvx_point2f_t;

/**
 * \ingroup nvx_framework_point
 * \brief Defines a 3D point (float coordinates).
 */
typedef struct _nvx_point3f_t {
    vx_float32 x;   /**< \brief The X coordinate. */
    vx_float32 y;   /**< \brief The Y coordinate. */
    vx_float32 z;   /**< \brief The Z coordinate. */
} nvx_point3f_t;

/**
 * \ingroup nvx_framework_point
 * \brief Defines a 4D point (float coordinates).
 */
typedef struct _nvx_point4f_t {
    vx_float32 x;   /**< \brief The X coordinate. */
    vx_float32 y;   /**< \brief The Y coordinate. */
    vx_float32 z;   /**< \brief The Z coordinate. */
    vx_float32 w;   /**< \brief The W coordinate. */
} nvx_point4f_t;

//----------------------------------------------------------------------------
// Framework : KeyPoint Types
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_framework_keypoint
 * \brief Defines a keypoint data structure.
 */
typedef struct _nvx_keypointf_t {
    vx_float32 x;               /*!< \brief Holds the x coordinate. */
    vx_float32 y;               /*!< \brief Holds the y coordinate. */
    vx_float32 strength;        /*!< \brief Holds the strength of the keypoint. Its definition is specific to the corner detector. */
    vx_float32 scale;           /*!< \brief Holds the scale initialized to 0 by corner detectors. */
    vx_float32 orientation;     /*!< \brief Holds the orientation initialized to 0 by corner detectors. */
    vx_int32 tracking_status;   /*!< \brief Holds tracking status. Zero indicates a lost point. Initialized to 1 by corner detectors. */
    vx_float32 error;           /*!< \brief Holds a tracking method-specific error. Initialized to 0 by corner detectors. */
} nvx_keypointf_t;

//----------------------------------------------------------------------------
// Framework : Image Extensions
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_framework_image
 * \brief Defines additional image formats.
 */
enum nvx_df_image_e {
    /** \brief A single plane of vx_float32 data. */
    NVX_DF_IMAGE_F32   = VX_DF_IMAGE('F','0','3','2'),

    /** \brief A single plane of vx_float32[2] data (eg. motion fields). */
    NVX_DF_IMAGE_2F32   = VX_DF_IMAGE('2','F','3','2'),

    /** \brief A single plane of vx_int16[2] data (eg. motion fields). */
    NVX_DF_IMAGE_2S16   = VX_DF_IMAGE('2','S','1','6'),

    /**
     * \brief A single plane of 48 bit pixels as 3 interleaved 16 bit signed integers of
     * R then G then B data.
     */
    NVX_DF_IMAGE_RGB16 = VX_DF_IMAGE('S','3','1','6'),
};

//----------------------------------------------------------------------------
// Framework : CUDA Interoperability
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_framework_cuda
 * \brief Extended memory accessors.
 */
enum nvx_accessor_e {
    /** \brief RO with CUDA pointer. */
    NVX_READ_ONLY_CUDA = VX_ENUM_BASE(VX_ID_NVIDIA, VX_ENUM_ACCESSOR) + 0x0,
    /** \brief WO with CUDA pointer. */
    NVX_WRITE_ONLY_CUDA = VX_ENUM_BASE(VX_ID_NVIDIA, VX_ENUM_ACCESSOR) + 0x1,
    /** \brief RW with CUDA pointer. */
    NVX_READ_AND_WRITE_CUDA = VX_ENUM_BASE(VX_ID_NVIDIA, VX_ENUM_ACCESSOR) + 0x2,
};

/**
 * \ingroup nvx_framework_cuda
 * \brief Extended import type.
 */
enum nvx_memory_type_e {
    /** \brief The CUDA import memory type. */
    NVX_MEMORY_TYPE_CUDA = VX_ENUM_BASE(VX_ID_NVIDIA, VX_ENUM_MEMORY_TYPE) + 0x0,
    /** \brief The CUDA array import memory type. */
    NVX_MEMORY_TYPE_CUDA_ARRAY,
};

//----------------------------------------------------------------------------
// Framework : Context Extensions
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_framework_context
 * \brief The extended context attributes list.
 */
enum nvx_context_attribute_e {
    /**
     * \brief ID of the CUDA device that was selected as current prior to \ref vx_context object creation
     * (use an <tt>int</tt> parameter).
     */
    NVX_CONTEXT_INITIAL_CUDA_DEVICE = VX_ENUM_BASE(VX_ID_NVIDIA, VX_TYPE_CONTEXT) + 0x1
};

//----------------------------------------------------------------------------
// Framework : Resource Control
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_framework_resource_control
 * \brief NVIDIA-specific targets.
 */
enum nvx_target_e
{
    /** \brief Run on a CPU. */
    NVX_TARGET_CPU = VX_ATTRIBUTE_BASE(VX_ID_NVIDIA, VX_ENUM_TARGET) + 0x0,
    /** \brief Run on a GPU. */
    NVX_TARGET_GPU = VX_ATTRIBUTE_BASE(VX_ID_NVIDIA, VX_ENUM_TARGET) + 0x1
};

//----------------------------------------------------------------------------
// Framework : Reference extension
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_framework_reference
 * \brief Releases a list of references to OpenVX objects.
 *
 * All references that are released without error are zeroed.
 * If there were errors for some of the references in the list, the function
 * returns the error status of the last failing reference release in the list.
 *
 * \note A referenced object is not destroyed until its total reference
 *       count reaches zero
 *
 * \par Example Code
 *
 * \snippet framework.cpp release_reference_list
 *
 * \param [in] ref_list     A pointer to the list of references to release.
 * \param [in] num_refs     The number of references in the list.
 *
 * \return A `vx_status` enumerator.
 * \retval VX_SUCCESS                   No errors.
 * \retval VX_ERROR_INVALID_REFERENCE   If the reference is not valid.
 */
NVX_C_API vx_status nvxReleaseReferenceList(vx_reference ref_list[], vx_size num_refs);

//----------------------------------------------------------------------------
// Framework : Graph Extension
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_framework_graph
 * \brief The extended graph attributes list
 */
enum nvx_graph_attribute_e {
    /*!
     * \brief Sets the graph verification options.
     *
     * Use a `vx_char *` parameter.
     *
     * Supported options:
     *
     * - `-O0` : Disables graph optimizations.
     * - `-O1` : Sets the graph optimization level to 1.
     * - `-O2` : Sets the graph optimization level to 2. This is the default level.
     * - `-O3` : Sets the graph optimization level to 3. This level activates advanced optimizations.
     *           For example, it activates the asynchronous CUDA execution beyond nodes boundaries.
     * - `--dot <file prefix>` : Activates the generation in a file of a dot representation of the graph
     *           at some stages of the graph verification.
     *
     * \par Example Code
     *
     * \snippet framework.cpp graph_verify_options
     */
    NVX_GRAPH_VERIFY_OPTIONS = VX_ENUM_BASE(VX_ID_NVIDIA, VX_TYPE_GRAPH) + 0x0,

    /*!
     * \brief Informs if graph verification is needed before graph execution.
     *
     * Use a `vx_bool` parameter.
     *
     * Graph verification may be needed in multiple situations, for example
     * - when it has never been verified
     * - when a change in the graph (node removal, node parameter change)
     *   changes its connectivity
     * - when a node parameter is changed with an other one that has different
     *   meta-data
     * - when an immutable node parameter is modified by the application
     *
     * The OpenVX implementation automatically detects when a graph
     * (re)verification is needed and will automatically verify the graph
     * if needed when the application requests a graph execution.
     *
     * This attribute provides the current verification requirement status
     * to the application.
     *
     */
    NVX_GRAPH_VERIFY_NEEDED = VX_ENUM_BASE(VX_ID_NVIDIA, VX_TYPE_GRAPH) + 0x1,
};

/**
 * \ingroup nvx_framework_graph
 * \brief Defines directives that control different features for graph / immediate processing.
 *
 * These enumerations are given to the \c vxDirective API to enable/disable
 * related features on the node, graph or context level.
 *
 * The directives may be applied to \c vx_node, \c vx_graph or \c vx_context objects.
 * Immediate mode functions inherit this property from parent \c vx_context object.
 * Graph objects inherit this property from the parent \c vx_context object
 * if the graph directive was not set by the application.
 * Node objects inherit this property from the parent \c vx_graph object
 * if the node directive was not set by the application.
 * The keypoint error calculation control directives are inherited at graph verification time.
 * The performance measurement control directives are inherited at graph execution time.
 */
enum nvx_directive_e {
    /**
     * \brief Disables keypoint's error calculation by optical flow and similar primitives.
     * \note It is the default behavior.
     */
    NVX_DIRECTIVE_DISABLE_KEYPOINT_ERROR = VX_ENUM_BASE(VX_ID_NVIDIA, VX_ENUM_DIRECTIVE) + 0x0,
    /**
     * \brief Enables keypoint's error calculation by optical flow and similar primitives.
     */
    NVX_DIRECTIVE_ENABLE_KEYPOINT_ERROR,
    /**
     * \brief Uses default behavior for keypoint's error calculation.
     */
    NVX_DIRECTIVE_DEFAULT_KEYPOINT_ERROR,

    /**
     * \brief Disables performance measurement.
     *
     * Equivalent to \ref VX_DIRECTIVE_DISABLE_PERFORMANCE, but can be used on more than
     * just contexts.
     *
     * \note It is the default behavior.
     */
    NVX_DIRECTIVE_DISABLE_PERFORMANCE,
    /**
     * \brief Enables performance measurement.
     *
     * Equivalent to \ref VX_DIRECTIVE_ENABLE_PERFORMANCE, but can be used on more than
     * just contexts.
     */
    NVX_DIRECTIVE_ENABLE_PERFORMANCE,
    /**
     * \brief Use default behavior for performance measurement.
     */
    NVX_DIRECTIVE_DEFAULT_PERFORMANCE,
};

/**
 * \ingroup nvx_framework_graph
 * \brief Creates an empty graph as a node stream.
 *
 * A stream-graph only differs from a standard OpenVX graph by the fact that
 * its semantics is determined by the behavior that would have the sequential
 * execution of nodes in the order they have been created (this order does
 * not matter for a standard graph).
 * The stream-graph then relaxes the single-assignment rule of the standard
 * graph, and a data object is allowed to be written multiple times in a
 * stream-graph.
 *
 * VisionWorks applies to a stream-graph the same optimizations as
 * to a standard graph, but ensures its semantics is preserved.
 *
 * \note A node cannot be removed from a stream-graph.
 *
 * \note A stream graph assumes that a data object written by a node may be
 * entirely modified by the node and then VisionWorks does not change execution
 * order of two nodes writing the same data object.
 *
 * \par Example Code
 *
 * \snippet framework.cpp stream_graph
 *
 * \param [in] context      The reference to the implementation context.
 *
 * \return A valid graph reference or an error object (use `vxGetStatus`).
 */
NVX_C_API vx_graph nvxCreateStreamGraph(vx_context context);

//----------------------------------------------------------------------------
// Framework : Remap Extensions
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_framework_remap
 * \brief Maps a rectangular patch (subset) of a remap object.
 *
 * \param [in] remap    The reference to the remap object from which to map the patch.
 * \param [in] rect     The coordinates from which to get the patch. Must be 0 <= start < end.
 * \param [out] addr    Address of a structure, which will be set to the layout information
 *                          of the mapped patch.
 * \param [out] ptr     Address of a pointer, which will be set to the address of the mapped remap patch.
 * \param [in] usage    This declares the intended usage of the mapped remap patch.
 *                          Use the \ref vx_accessor_e enumeration.
 *
 * \return A \ref vx_status_e enumeration.
 */
NVX_C_API vx_status nvxMapRemapPatch(vx_remap remap,
                                     vx_rectangle_t *rect,
                                     vx_imagepatch_addressing_t *addr,
                                     void **ptr,
                                     vx_enum usage);

/**
 * \ingroup nvx_framework_remap
 * \brief Unmaps a mapped patch (subset) of a remap object.
 *
 * \param [in] remap    The reference to the remap object.
 * \param [in] ptr      Address where the remap patch was mapped, as returned by \ref nvxMapRemapPatch.
 *
 * \return A \ref vx_status_e enumeration.
 */
NVX_C_API vx_status nvxUnmapRemapPatch(vx_remap remap,
                                       void *ptr);

//----------------------------------------------------------------------------
// Framework : Node Extensions
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_framework_node
 * \brief The extended node attributes list.
 */
enum nvx_node_attribute_e {
    /**
     * \brief Gets the CUDA stream object associated with the current node.
     *
     * This attribute is read-only and is only meaningful when queried from a kernel processing callback.
     * To ensure a correct execution, user custom kernels for the GPU target must use this attribute
     * to enqueue their own CUDA kernels to the CUDA stream, provided by the framework,
     * or to synchronize with it, if they use own streams.
     *
     * \see \ref nvx_tutorial_user_custom_node
     */
    NVX_NODE_CUDA_STREAM = VX_ATTRIBUTE_BASE(VX_ID_NVIDIA, VX_TYPE_NODE) + 0x0,
};

//----------------------------------------------------------------------------
// Framework : Scalar Extensions
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_framework_scalar
 * \brief Maps a scalar object.
 *
 * \param [in]  scalar         The reference to the scalar object to map.
 * \param [out] map_id         A pointer to output map ID.
 * \param [out] ptr            A pointer to a pointer to a location to access the requested data.
 * \param [in]  usage          This declares the intended usage of the mapped scalar
 *                                 using the \ref vx_accessor_e enumeration.
 * \param [in]  memory_type    This declares the intended memory type of the mapped memory.
 *                                 Supported values : \ref VX_MEMORY_TYPE_HOST and
 *                                 \ref NVX_MEMORY_TYPE_CUDA.
 * \param [in]  flags          An integer that allows passing options to the map operation.
 *                                 Use 0 for this option.
 *
 * \return A \ref vx_status_e enumeration.
 */
NVX_C_API vx_status nvxMapScalar(vx_scalar scalar,
                                 vx_map_id *map_id,
                                 void **ptr,
                                 vx_enum usage,
                                 vx_enum memory_type,
                                 vx_bitfield flags);

/**
 * \ingroup nvx_framework_scalar
 * \brief Unmaps a mapped scalar object.
 *
 * \param [in] scalar       The reference to the scalar.
 * \param [in] map_id       The map ID.
 *
 * \return A \ref vx_status_e enumeration.
 */
NVX_C_API vx_status nvxUnmapScalar(vx_scalar scalar,
                                   vx_map_id map_id);

//----------------------------------------------------------------------------
// Framework : Matrix Extensions
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_framework_matrix
 * \brief Maps a matrix object.
 *
 * \param [in]  matrix         The reference to the matrix object to map.
 * \param [out] map_id         A pointer to output map ID.
 * \param [out] ptr            A pointer to a pointer to a location to access the requested data.
 * \param [in]  usage          This declares the intended usage of the mapped matrix
 *                                 using the \ref vx_accessor_e enumeration.
 * \param [in]  memory_type    This declares the intended memory type of the mapped memory.
 *                                 Supported values : \ref VX_MEMORY_TYPE_HOST and
 *                                 \ref NVX_MEMORY_TYPE_CUDA.
 * \param [in]  flags          An integer that allows passing options to the map operation.
 *                                 Use 0 for this option.
 *
 * \return A \ref vx_status_e enumeration.
 */
NVX_C_API vx_status nvxMapMatrix(vx_matrix matrix,
                                 vx_map_id *map_id,
                                 void **ptr,
                                 vx_enum usage,
                                 vx_enum memory_type,
                                 vx_bitfield flags);

/**
 * \ingroup nvx_framework_matrix
 * \brief Unmaps a mapped matrix object.
 *
 * \param [in] matrix       The reference to the matrix.
 * \param [in] map_id       The map ID.
 *
 * \return A \ref vx_status_e enumeration.
 */
NVX_C_API vx_status nvxUnmapMatrix(vx_matrix matrix,
                                   vx_map_id map_id);

//----------------------------------------------------------------------------
// Framework : Convolution Extensions
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_framework_convolution
 * \brief Maps a convolution object in reversed order.
 *
 * The mapped data is stored in reversed order, i.e., `conv[r][c]` is located at
 * `ptr[NB_COLS*(NB_ROWS-1 - r) + (NB_COLS-1 - c)]`.
 *
 * \param [in]  conv           The reference to the convolution object to map.
 * \param [out] map_id         A pointer to output map ID.
 * \param [out] ptr            A pointer to a pointer to a location to access the requested data.
 * \param [in]  usage          This declares the intended usage of the mapped convolution
 *                                 using the \ref vx_accessor_e enumeration.
 * \param [in]  memory_type    This declares the intended memory type of the mapped memory.
 *                                 Supported values : \ref VX_MEMORY_TYPE_HOST and
 *                                 \ref NVX_MEMORY_TYPE_CUDA.
 * \param [in]  flags          An integer that allows passing options to the map operation.
 *                                 Use 0 for this option.
 *
 * \return A \ref vx_status_e enumeration.
 */
NVX_C_API vx_status nvxMapConvolutionReversed(vx_convolution conv,
                                              vx_map_id *map_id,
                                              void **ptr,
                                              vx_enum usage,
                                              vx_enum memory_type,
                                              vx_bitfield flags);

/**
 * \ingroup nvx_framework_convolution
 * \brief Unmaps a mapped convolution object.
 *
 * \param [in] conv         The reference to the convolution.
 * \param [in] map_id       The map ID.
 *
 * \return A \ref vx_status_e enumeration.
 */
NVX_C_API vx_status nvxUnmapConvolution(vx_convolution conv,
                                        vx_map_id map_id);

//----------------------------------------------------------------------------
// Primitive : Harris Track
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_p_harris_track
 * \brief [Graph] Detects and tracks Harris corners for the input image.
 *
 * \param [in]  graph           Specifies the graph.
 * \param [in]  input           Specifies the input image.
 *                                  Only `VX_DF_IMAGE_U8` format is supported.
 *                                  The image size must be not greater than \f$ 2^{32} \f$ pixels.
 * \param [out] output          Specifies the output list of corners.
 *                                  Only `VX_TYPE_KEYPOINT`, `NVX_TYPE_KEYPOINTF` and `NVX_TYPE_POINT2F`
 *                                  item types are supported.
 *                                  The array capacity must be explicitly provided, even for virtual arrays.
 * \param [in]  mask            Specifies the optional mask.
 *                                  Only `VX_DF_IMAGE_U8` format is supported.
 *                                  The \p mask should have the same size as \p input image.
 * \param [in]  tracked_points  Specifies the optional tracked features list.
 *                                  If specified, it should have the same item type
 *                                  as \p output array.
 * \param [in]  k               Specifies the Harris K parameter.
 *                                  The value of \p k has to be determined empirically,
 *                                  and in the literature values in the range \f$ [0.04, 0.15] \f$
 *                                  have been reported as feasible.
 * \param [in]  threshold       Specifies the Harris threshold.
 * \param [in]  cell_size       Specifies the size of cells for cell-based non-max suppression.
 *                                  The \p cell_size should be less than \p input image dimensions.
 * \param [out] num_corners     Specifies the total number of detected corners in image (optional).
 *                                  It should be `VX_TYPE_SIZE` scalar.
 *
 * \return A valid node reference or an error object (use `vxGetStatus`).
 */
NVX_C_API vx_node nvxHarrisTrackNode(vx_graph graph, vx_image input, vx_array output,
                                     vx_image mask, vx_array tracked_points,
                                     vx_float32 k, vx_float32 threshold, vx_uint32 cell_size,
                                     vx_scalar num_corners);

/**
 * \ingroup nvx_p_harris_track
 * \brief [Immediate] Detects and tracks Harris corners for the input image.
 *
 * \param [in]  context         Specifies the context.
 * \param [in]  input           Specifies the input image.
 *                                  Only `VX_DF_IMAGE_U8` format is supported.
 *                                  The image size must be not greater than \f$ 2^{32} \f$ pixels.
 * \param [out] output          Specifies the output list of corners.
 *                                  Only `VX_TYPE_KEYPOINT`, `NVX_TYPE_KEYPOINTF` and `NVX_TYPE_POINT2F`
 *                                  item types are supported.
 *                                  The array capacity must be explicitly provided, even for virtual arrays.
 * \param [in]  mask            Specifies the optional mask.
 *                                  Only `VX_DF_IMAGE_U8` format is supported.
 *                                  The \p mask should have the same size as \p input image.
 * \param [in]  tracked_points  Specifies the optional tracked features list.
 *                                  If specified, it should have the same item type
 *                                  as \p output array.
 * \param [in]  k               Specifies the Harris K parameter.
 *                                  The value of \p k has to be determined empirically,
 *                                  and in the literature values in the range \f$ [0.04, 0.15] \f$
 *                                  have been reported as feasible.
 * \param [in]  threshold       Specifies the Harris threshold.
 * \param [in]  cell_size       Specifies the size of cells for cell-based non-max suppression.
 *                                  The \p cell_size should be less than \p input image dimensions.
 * \param [out] num_corners     Specifies the total number of detected corners in image (optional).
 *                                  It should be `VX_TYPE_SIZE` scalar.
 *
 * \return A `vx_status` enumerator.
 * \retval VX_SUCCESS                       No errors.
 * \retval VX_ERROR_INVALID_REFERENCE       Supplied parameters are not a valid references.
 * \retval VX_ERROR_INVALID_PARAMETERS      Supplied parameters are not valid.
 * \retval VX_ERROR_INVALID_SCOPE           Supplied parameters are virtual objects,
 *                                              which can't be used in immediate mode.
 * \retval VX_FAILURE                       Internal error in primitive implementation,
 *                                              check log for detailed information
 *                                              (\ref group_log).
 */
NVX_C_API vx_status nvxuHarrisTrack(vx_context context, vx_image input, vx_array output,
                                    vx_image mask, vx_array tracked_points,
                                    vx_float32 k, vx_float32 threshold, vx_uint32 cell_size,
                                    vx_scalar num_corners);

//----------------------------------------------------------------------------
// Primitive : FAST Track
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_p_fast_track
 * \brief [Graph] Detects and tracks corners using the FAST algorithm.
 *
 * \param [in]  graph           Specifies the graph.
 * \param [in]  input           Specifies the input image.
 *                                  Only `VX_DF_IMAGE_U8` format is supported.
 *                                  The image size must be not greater than \f$ 2^{32} \f$ pixels.
 * \param [out] output          Specifies the output list of corners.
 *                                  Only `VX_TYPE_KEYPOINT`, `NVX_TYPE_KEYPOINTF` and `NVX_TYPE_POINT2F`
 *                                  item types are supported.
 *                                  The array capacity must be explicitly provided, even for virtual arrays.
 * \param [in]  mask            Specifies the optional mask.
 *                                  Only `VX_DF_IMAGE_U8` format is supported.
 *                                  The \p mask should have the same size as \p input image.
 * \param [in]  tracked_points  Specifies the optional tracked features list.
 *                                  If specified, it should have the same item type
 *                                  as \p output array.
 * \param [in]  type            Specifies the number of neighborhoods to test.
 *                                  Supported values : 9, 10, 11, 12.
 * \param [in]  threshold       Specifies the threshold on difference between
 *                                  intensity of the central pixel and pixels of
 *                                  a circle around this pixel.
 *                                  The \p threshold value should be less than 255.
 * \param [in]  cell_size       Specifies the size of cells for cell-based non-max suppression.
 *                                  The \p cell_size should be less than \p input image dimensions.
 * \param [out] num_corners     Specifies the total number of detected corners in image (optional).
 *                                  It should be `VX_TYPE_SIZE` scalar.
 *
 * \return A valid node reference or an error object (use `vxGetStatus`).
 */
NVX_C_API vx_node nvxFastTrackNode(vx_graph graph, vx_image input, vx_array output,
                                   vx_image mask, vx_array tracked_points,
                                   vx_uint32 type, vx_uint32 threshold, vx_uint32 cell_size,
                                   vx_scalar num_corners);

/**
 * \ingroup nvx_p_fast_track
 * \brief [Immediate] Detects and tracks corners using the FAST algorithm.
 *
 * \param [in]  context           Specifies the context.
 * \param [in]  input           Specifies the input image.
 *                                  Only `VX_DF_IMAGE_U8` format is supported.
 *                                  The image size must be not greater than \f$ 2^{32} \f$ pixels.
 * \param [out] output          Specifies the output list of corners.
 *                                  Only `VX_TYPE_KEYPOINT`, `NVX_TYPE_KEYPOINTF` and `NVX_TYPE_POINT2F`
 *                                  item types are supported.
 *                                  The array capacity must be explicitly provided, even for virtual arrays.
 * \param [in]  mask            Specifies the optional mask.
 *                                  Only `VX_DF_IMAGE_U8` format is supported.
 *                                  The \p mask should have the same size as \p input image.
 * \param [in]  tracked_points  Specifies the optional tracked features list.
 *                                  If specified, it should have the same item type
 *                                  as \p output array.
 * \param [in]  type            Specifies the number of neighborhoods to test.
 *                                  Supported values : 9, 10, 11, 12.
 * \param [in]  threshold       Specifies the threshold on difference between
 *                                  intensity of the central pixel and pixels of
 *                                  a circle around this pixel.
 *                                  The \p threshold value should be less than 255.
 * \param [in]  cell_size       Specifies the size of cells for cell-based non-max suppression.
 *                                  The \p cell_size should be less than \p input image dimensions.
 * \param [out] num_corners     Specifies the total number of detected corners in image (optional).
 *                                  It should be `VX_TYPE_SIZE` scalar.
 *
 * \return A `vx_status` enumerator.
 * \retval VX_SUCCESS                       No errors.
 * \retval VX_ERROR_INVALID_REFERENCE       Supplied parameters are not a valid references.
 * \retval VX_ERROR_INVALID_PARAMETERS      Supplied parameters are not valid.
 * \retval VX_ERROR_INVALID_SCOPE           Supplied parameters are virtual objects,
 *                                              which can't be used in immediate mode.
 * \retval VX_FAILURE                       Internal error in primitive implementation,
 *                                              check log for detailed information
 *                                              (\ref group_log).
 */
NVX_C_API vx_status nvxuFastTrack(vx_context context, vx_image input, vx_array output,
                                  vx_image mask, vx_array tracked_points,
                                  vx_uint32 type, vx_uint32 threshold, vx_uint32 cell_size,
                                  vx_scalar num_corners);

//----------------------------------------------------------------------------
// Primitive : Semi-Global Matching
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_p_semiGlobalMatching
 * \brief Defines scan line's directions used during cost aggregation step.
 */
enum nvx_scanline_e {
    NVX_SCANLINE_LEFT_RIGHT            = 1 << 0,    /**< \brief aggregate cost from left to right horizontally. */
    NVX_SCANLINE_TOP_LEFT_BOTTOM_RIGHT = 1 << 1,    /**< \brief aggregate cost from left to right diagonally starting from the top. */
    NVX_SCANLINE_TOP_BOTTOM            = 1 << 2,    /**< \brief aggregate cost from top to bottom vertically. */
    NVX_SCANLINE_TOP_RIGHT_BOTTOM_LEFT = 1 << 3,    /**< \brief aggregate cost from right to left diagonally starting from the top. */

    NVX_SCANLINE_RIGHT_LEFT            = 1 << 4,    /**< \brief aggregate cost from right to left horizontally. */
    NVX_SCANLINE_BOTTOM_RIGHT_TOP_LEFT = 1 << 5,    /**< \brief aggregate cost from right to left diagonally starting from the bottom. */
    NVX_SCANLINE_BOTTOM_TOP            = 1 << 6,    /**< \brief aggregate cost from bottom to top vertically. */
    NVX_SCANLINE_BOTTOM_LEFT_TOP_RIGHT = 1 << 7,    /**< \brief aggregate cost from left to right diagonally starting from the bottom. */

    /** \brief Aggregate cost from four directions forming a cross. Recommended option for automotive use cases. */
    NVX_SCANLINE_CROSS = NVX_SCANLINE_LEFT_RIGHT |
                         NVX_SCANLINE_RIGHT_LEFT |
                         NVX_SCANLINE_TOP_BOTTOM |
                         NVX_SCANLINE_BOTTOM_TOP,

    NVX_SCANLINE_ALL                   = 0xFF       /**< \brief aggregate cost over all scan lines. */
};

/**
 * \ingroup nvx_p_semiGlobalMatching
 * \brief Defines extra flags for SGM algorithm.
 */
enum nvx_sgm_flags_e {
    NVX_SGM_FILTER_TOP_AREA            = 1 << 0,    /**< \brief Filter cost at top image area with low gradients. */
    NVX_SGM_PYRAMIDAL_STEREO           = 1 << 1     /**< \brief Use pyramidal scheme: lower resolution imagery for nearby objects and
                                                    the full resolution for far-away objects. */
};

/**
 * \ingroup nvx_p_semiGlobalMatching
 * \brief [Graph] evaluate disparity given 2 stereo images using the SGM algorithm.
 *
 * \param [in]  graph             Specifies the graph.
 * \param [in]  left              Left stereo image
 *                                    Only `VX_DF_IMAGE_U8` format is supported.
 *                                    Width must be divisible by 4
 * \param [in]  right             Right stereo image
 *                                    The \p right image must have the same size and type as \p left image.
 * \param [out] disparity         Resulting "disparity" map. It contains values from minD-1 to maxD (exclusive)
 *                                represented in Q11.4 fixed point format.
 *                                    Only `VX_DF_IMAGE_S16` format is supported.
 *                                    \p disparity must have the same size as \p left image.
 * \param [in]  minD              The minimum disparity value.
 * \param [in]  maxD              The maximum disparity value.
 * \param [in]  P1                Smoothness penalty.
 * \param [in]  P2                Discontiguous penalty.
 * \param [in]  sad               Specifies the average window size for sum of absolute differences (set to 1 for original SGM).
 * \param [in]  ct_win_size       Specifies the census transform window size.
 * \param [in]  hc_win_size       Specifies the hamming cost window size.
 * \param [in]  clip              Clip value for cost (used to preserve overflow in cost function)
 * \param [in]  max_diff          Maximum allowed difference (in integer pixel units) in the left-right disparity check.
 * \param [in]  uniqueness        Margin in percentage by which the best (minimum) computed cost function value
 *                                should “win” the second best value to consider the found match correct.
 * \param [in]  scanlines_mask    Scan line directions. Any bit-OR of nvx_scanline_e values is suitable.
 * \param [in]  flags             Extra flags. It must be a bitwise OR combination of nvx_sgm_flags_e values.
 *                                `0` for default behavior.
 */
NVX_C_API vx_node nvxSemiGlobalMatchingNode(vx_graph graph,
                                            vx_image left,
                                            vx_image right,
                                            vx_image disparity,
                                            vx_int32 minD,
                                            vx_int32 maxD,
                                            vx_int32 P1,
                                            vx_int32 P2,
                                            vx_int32 sad,
                                            vx_int32 ct_win_size,
                                            vx_int32 hc_win_size,
                                            vx_int32 clip,
                                            vx_int32 max_diff,
                                            vx_int32 uniqueness,
                                            vx_enum  scanlines_mask,
                                            vx_enum  flags);

/**
 * \ingroup nvx_p_semiGlobalMatching
 * \brief [Immediate] evaluate disparity given 2 stereo images using the SGM algorithm.
 *
 * \param [in]  context           Specifies the context.
 * \param [in]  left              Left stereo image
 *                                    Only `VX_DF_IMAGE_U8` format is supported.
 * \param [in]  right             Right stereo image
 *                                    The \p right image must have the same size and type as \p left image.
 * \param [out] disparity         Resulting "disparity" map. It contains values from minD-1 to maxD (exclusive)
 *                                represented in Q11.4 fixed point format.
 *                                    Only `VX_DF_IMAGE_S16` format is supported.
 *                                    \p disparity must  have the same size as \p left image.
 * \param [in]  minD              The minimum disparity value.
 * \param [in]  maxD              The maximum disparity value.
 * \param [in]  P1                Smoothness penalty.
 * \param [in]  P2                Discontiguous penalty.
 * \param [in]  sad               Specifies the average window size for sum of absolute differences (set to 1 for original SGM).
 * \param [in]  ct_win_size       Specifies the census transform window size.
 * \param [in]  hc_win_size       Specifies the hamming cost window size.
 * \param [in]  clip              Clip value for cost (used to preserve overflow in cost function)
 * \param [in]  max_diff           Maximum allowed difference (in integer pixel units) in the left-right disparity check.
 * \param [in]  uniqueness        Margin in percentage by which the best (minimum) computed cost function value
 *                                should “win” the second best value to consider the found match correct.
 * \param [in]  scanlines_mask    Scan line directions. Any bit-OR of nvx_scanline_e values is suitable.
 * \param [in]  flags             Extra flags. It must be a bitwise OR combination of nvx_sgm_flags_e values
 *                                or `0` for default behavior.
 *  */
NVX_C_API vx_status nvxuSemiGlobalMatching(vx_context context,
                                           vx_image left,
                                           vx_image right,
                                           vx_image disparity,
                                           vx_int32 minD,
                                           vx_int32 maxD,
                                           vx_int32 P1,
                                           vx_int32 P2,
                                           vx_int32 sad,
                                           vx_int32 ct_win_size,
                                           vx_int32 hc_win_size,
                                           vx_int32 clip,
                                           vx_int32 max_diff,
                                           vx_int32 uniqueness,
                                           vx_enum  scanlines_mask,
                                           vx_enum  flags);

/**
 * \ingroup nvx_p_semiGlobalMatching
 * \brief [Graph] compute Birchfield-Tomasi cost function.
 *
 * \param [in]  graph             Specifies the graph.
 * \param [in]  left              Specifies the left stereo image.
 *                                    Only `VX_DF_IMAGE_U8` format is supported.
 *                                    Width must be divisible by 4
 * \param [in]  right             Specifies the right stereo image.
 *                                    The \p right image must have the same size and type as \p left image.
 * \param [out] cost              Specifies the resulting cost.
 *                                    Only `VX_DF_IMAGE_U8` format is supported.
 *                                    The size of the \p cost image must be W*D x H,
 *                                    where W and H are the width and height of the
 *                                    \p left image, and D = maxD - minD.
 * \param [in]  minD              Specifies the minimum disparity value.
 * \param [in]  maxD              SPecifies the maximum disparity value.
 * \param [in]  clip              Specifies the clipping factor for gradient component of the cost values.
 */
NVX_C_API vx_node nvxComputeCostBTNode(vx_graph graph, vx_image left, vx_image right, vx_image cost,
                                       vx_int32 minD, vx_int32 maxD, vx_int32 clip);

/**
 * \ingroup nvx_p_semiGlobalMatching
 * \brief [Immediate] compute the Birchfield-Tomasi cost function.
 *
 * \param [in]  context           Specifies the context.
 * \param [in]  left              Specifies the left stereo image.
 *                                    Only `VX_DF_IMAGE_U8` format is supported.
 *                                    Width must be divisible by 4
 * \param [in]  right             Specifies the right stereo image.
 *                                    The \p right image must have the same size and type as \p left image.
 * \param [out] cost              Specifies the resulting cost.
 *                                    Only `VX_DF_IMAGE_U8` format is supported.
 *                                    The size of the \p cost image must be W*D x H,
 *                                    where W and H are the width and height of the
 *                                    \p left image, and D = maxD - minD.
 * \param [in]  minD              Specifies the minimum disparity value.
 * \param [in]  maxD              Specifies the maximum disparity value.
 * \param [in]  clip              Clipping factor for gradient component of the cost values.
 */
NVX_C_API vx_status nvxuComputeCostBT(vx_context context, vx_image left, vx_image right, vx_image cost,
                                      vx_int32 minD, vx_int32 maxD, vx_int32 clip);

/**
 * \ingroup nvx_p_semiGlobalMatching
 * \brief [Graph] convolve cost function before cost aggregation step.
 *
 * \param [in]  graph             Specifies the graph.
 * \param [in]  pixel_cost        Input cost volume.
 *                                    Only `VX_DF_IMAGE_U8` format is supported.
 *                                    Width must be divisible by \p D
 * \param [out] block_cost        Resulting cost volume.
 *                                    The \p block_cost image should have the same size and type as \p pixel_cost image.
 * \param [in]  D                 Number of disparities in cost volume.
 * \param [in]  win_size          Convolution window size.
 */
NVX_C_API vx_node nvxConvolveCostNode(vx_graph graph, vx_image pixel_cost, vx_image block_cost,
                                      vx_int32 D, vx_int32 win_size);

/**
 * \ingroup nvx_p_semiGlobalMatching
 * \brief [Immediate] convolve cost function before cost aggregation step.
 *
 * \param [in]  context           Specifies the context.
 * \param [in]  pixel_cost        Specifies the input cost volume.
 *                                    Only `VX_DF_IMAGE_U8` format is supported.
 *                                    Width must be divisible by \p D
 * \param [out] block_cost        Specifies the resulting cost volume.
 *                                    The \p block_cost image must have the same size and type as \p pixel_cost image.
 * \param [in]  D                 Specifies the number of disparities in cost volume.
 * \param [in]  win_size          Specifies the onvolution window size.
 */
NVX_C_API vx_status nvxuConvolveCost(vx_context context, vx_image pixel_cost, vx_image block_cost,
                                     vx_int32 D, vx_int32 win_size);

/**
 * \ingroup nvx_p_semiGlobalMatching
 * \brief [Graph] extra filter cost function after cost convolution step and before cost aggregation step.
 *
 * \param [in]  graph             Specifies the graph.
 * \param [in]  img               Specifies the left input image from the stereo pair.
 *                                    Only `VX_DF_IMAGE_U8` format is supported.
 *                                    Width must be divisible by 4
 * \param [inout] cost            Specifies the output cost volume.
 *                                    Only `VX_DF_IMAGE_U8` format is supported.
 *                                    Width must be divisible by \p D
 * \param [in]  D                 Specifies the number of disparities in cost volume.
 * \param [in]  P2                Specifies the discontiguous penalty.
 * \param [in]  flags             Specifies the extra flags. It must be a bitwise combination of nvx_sgm_flags_e values.
 *                                `0` for default behavior.
 */
NVX_C_API vx_node nvxFilterCostNode(vx_graph graph, vx_image img, vx_image cost,
                                    vx_int32 D, vx_int32 P2, vx_enum flags);

/**
 * \ingroup nvx_p_semiGlobalMatching
 * \brief [Immediate] extra filter cost function after cost convolution step and before cost aggregation step.
 *
 * \param [in]  context           Specifies the context.
 * \param [in]  img               Specifies the left input image from the stereo pair.
 *                                    Only `VX_DF_IMAGE_U8` format is supported.
 *                                    Width must be divisible by 4
 * \param [inout] cost            Specifies the output cost volume.
 *                                    Only `VX_DF_IMAGE_U8` format is supported.
 *                                    Width must be divisible by \p D
 * \param [in]  D                 Specifies the number of disparities in cost volume.
 * \param [in]  P2                Specifies the discontiguous penalty.
 * \param [in]  flags             Specifies the extra flags. It must be a bitwise combination of nvx_sgm_flags_e values.

 *                                `0` for default behavior.
 */
NVX_C_API vx_status nvxuFilterCost(vx_context context, vx_image img, vx_image cost,
                                   vx_int32 D, vx_int32 P2, vx_enum flags);

/**
 * \ingroup nvx_p_semiGlobalMatching
 * \brief [Graph] aggregate cost volume over multiple scan lines.
 *
 * \param [in]  graph             Specifies the graph.
 * \param [in]  input             Specifies the input cost volume.
 *                                    Only `VX_DF_IMAGE_U8` format is supported.
 *                                    Width must be divisible by \p D
 * \param [out] output            Specifies the resulting aggregated cost volume.
 *                                    Only `VX_DF_IMAGE_S16` format is supported.
 *                                    The \p output image must have the same size as \p input image.
 * \param [in]  D                 Specifies the number of disparities in cost volume.
 * \param [in]  P1                Specifies the smoothness penalty.
 * \param [in]  P2                Specifies the discontiguous penalty.
 * \param [in]  directions        Specifies the scan line directions. Any bit-OR of nvx_scanline_e values is suitable.
 */
NVX_C_API vx_node nvxAggregateCostScanlinesNode(vx_graph graph, vx_image input, vx_image output,
                                                vx_int32 D, vx_int32 P1, vx_int32 P2, vx_enum directions);

/**
 * \ingroup nvx_p_semiGlobalMatching
 * \brief [Immediate] aggregate cost volume over multiple scan lines.
 *
 * \param [in]  context           Specifies the context.
 * \param [in]  input             Specifies the input cost volume.
 *                                    Only `VX_DF_IMAGE_U8` format is supported.
 *                                    Width must be divisible by \p D
 * \param [out] output            Specifies the resulting aggregated cost volume.
 *                                    Only `VX_DF_IMAGE_S16` format is supported.
 *                                    The \p output image must have the same size as \p input image.
 * \param [in]  D                 Specifies the number of disparities in cost volume.
 * \param [in]  P1                Specifies the smoothness penalty.
 * \param [in]  P2                Specifies the discontiguous penalty.
 * \param [in]  directions        Specifies the scan line directions. Any bit-OR of nvx_scanline_e values is suitable.
 */
NVX_C_API vx_status nvxuAggregateCostScanlines(vx_context context, vx_image input, vx_image output,
                                               vx_int32 D, vx_int32 P1, vx_int32 P2, vx_enum directions);

/**
 * \ingroup nvx_p_semiGlobalMatching
 * \brief [Graph] compute disparity image given the aggregated cost
 *
 * \param [in]  graph             Specifies the graph.
 * \param [in]  cost              Specifies the input cost volume.
 *                                    Only `VX_DF_IMAGE_S16` format is supported.
 * \param [out] disparity         Specifies the resulting disparity map. It contains values from minD-1 to maxD (exclusive)
 *                                represented in Q11.4 format.
 *                                    Only `VX_DF_IMAGE_S16` format is supported.
 *                                    The \p disparity image must have the
 *                                    size of WxH if (W*D)xH is the size of the
 *                                    \p cost image (D = maxD - minD).
 * \param [in]  minD              Specifies the minimum disparity value.
 * \param [in]  maxD              Specifies the maximum disparity value.
 * \param [in]  uniqueness        Specifies the ,argin in percentage by which the best (minimum) computed cost function value
 *                                should “win” the second best value to consider the found match correct..
 * \param [in]  maxDiff           Specifies the maximum allowed difference (in integer pixel units) in the left-right disparity check.
 */
NVX_C_API vx_node nvxComputeDisparityNode(vx_graph graph, vx_image cost, vx_image disparity,
                                          vx_int32 minD, vx_int32 maxD, vx_int32 uniqueness, vx_int32 maxDiff);

/**
 * \ingroup nvx_p_semiGlobalMatching
 * \brief [Immediate] compute disparity image given the aggregated cost
 *
 * \param [in]  context           Specifies the context.
 * \param [in]  cost              Specifies the input cost volume.
 *                                    Only `VX_DF_IMAGE_S16` format is supported.
 * \param [out] disparity         Specifies the resulting disparity map. It contains values from minD-1 to maxD (exclusive)
 *                                represented in Q11.4 format.
 *                                    Only `VX_DF_IMAGE_S16` format is supported.
 *                                    The \p disparity image must have the
 *                                    size of WxH if (W*D)xH is the size of the
 *                                    \p cost image (D = maxD - minD).
 * \param [in]  minD              Specifies the minimum disparity value.
 * \param [in]  maxD              Specifies the maximum disparity value.
 * \param [in]  uniqueness        Specifies the margin in percentage by which the best (minimum) computed cost function value
 *                                should “win” the second best value to consider the found match correct..
 * \param [in]  maxDiff           Specifies the maximum allowed difference (in integer pixel units) in the left-right disparity check.
 */
NVX_C_API vx_status nvxuComputeDisparity(vx_context context, vx_image cost, vx_image disparity,
                                         vx_int32 minD, vx_int32 maxD, vx_int32 uniqueness, vx_int32 maxDiff);

/**
 * \ingroup nvx_p_semiGlobalMatching
 * \brief [Graph] Modified Birchfield Tomasi cost function is computed on Sobel
 * inputs instead of intensity information.
 *
 * \param [in]  graph             Specifies the graph.
 * \param [in]  left              Specifies the left stereo image.
 *                                    Only `VX_DF_IMAGE_U8` format is supported.
 *                                    Width must be divisible by 4
 * \param [in]  right             Specifies the right stereo image.
 *                                    The \p right image must have the same size and type as \p left image.
 * \param [out] cost              Specifies the resulting cost.
 *                                    The size of the \p cost image must be W*D x H,
 *                                    where W and H are the width and height of the
 *                                    \p left image, and D = maxD - minD.
 * \param [in]  minD              Specifies the minimum disparity value.
 * \param [in]  maxD              Specifies the maximum disparity value.
 * \param [in]  clip              Specifies the clipping factor for gradient component of the cost values.
 */

NVX_C_API vx_node nvxComputeModifiedCostBTNode(vx_graph graph, vx_image left, vx_image right, vx_image cost,
                                               vx_int32 minD, vx_int32 maxD, vx_int32 clip);

/**
 * \ingroup nvx_p_semiGlobalMatching
 * \brief [Graph] Modified Birchfield Tomasi cost function is computed on Sobel
 * inputs instead of intensity information.
 *
 * \param [in]  context           Specifies the context.
 * \param [in]  left              Specifies the left stereo image.
 *                                    Only `VX_DF_IMAGE_U8` format is supported.
 *                                    Width must be divisible by 4
 * \param [in]  right             Specifies the right stereo image.
 *                                    The \p right image must have the same size and type as \p left image.
 * \param [out] cost              Specifies the resulting cost.
 *                                    The size of the \p cost image must be W*D x H,
 *                                    where W and H are the width and height of the
 *                                    \p left image, and D = maxD - minD.
 * \param [in]  minD              Specifies the minimum disparity value.
 * \param [in]  maxD              Specifies the maximum disparity value.
 * \param [in]  clip              Specifies the clipping factor for gradient component of the cost values.
 */
NVX_C_API vx_status nvxuComputeModifiedCostBT(vx_context context, vx_image left, vx_image right, vx_image cost,
                                              vx_int32 minD, vx_int32 maxD, vx_int32 clip);

/**
 * \ingroup nvx_p_semiGlobalMatching
 * \brief [Graph] Sets the cost of the maximum disparity value to zero if this
 *                (or larger) value was established on a lower-resolution
 *                level. This gives a strong prior in the higher resolution SGM
 *                result towards the subsampled SGM result for large
 *                disparities.
 *
 * \param [in]  graph             Specifies the graph.
 * \param [in]  prev              Specifies the disparity image from the previous pyramid level.
 *                                    Only `VX_DF_IMAGE_S16` format is supported.
 *                                    Width must be divisible by 4
 * \param [inout] cost            Specifies the cost volume to update.
 *                                    Only `VX_DF_IMAGE_U8` format is supported.
 *                                    The size of the \p cost image must be 2*W*D x 2*H,
 *                                    where W and H are the width and height of the
 *                                    \p prev image.
 * \param [in]  D                 Specifies the number of disparities in cost volume.
 */
NVX_C_API vx_node nvxPSGMCostPriorNode(vx_graph graph, vx_image prev, vx_image cost,
                                       vx_int32 D);

/**
 * \ingroup nvx_p_semiGlobalMatching
 * \brief [Immediate] Sets the cost of the maximum disparity value to zero if this
 *                    (or larger) value was established on a lower-resolution
 *                    level. This gives a strong prior in the higher resolution SGM
 *                    result towards the subsampled SGM result for large
 *                    disparities.
 *
 * \param [in]  context           Specifies the context.
 * \param [in]  prev              Specifies the disparity image from the previous pyramid level.
 *                                    Only `VX_DF_IMAGE_S16` format is supported.
 *                                    Width must be divisible by 4
 * \param [inout] cost            Specifies the cost volume to update.
 *                                    Only `VX_DF_IMAGE_U8` format is supported.
 *                                    The size of the \p cost image must be 2*W*D x 2*H,
 *                                    where W and H are the width and height of the
 *                                    \p prev image.
 * \param [in]  D                 Specifies the number of disparities in cost volume.
 */
NVX_C_API vx_status nvxuPSGMCostPrior(vx_context context, vx_image prev, vx_image cost,
                                      vx_int32 D);

/**
 * \ingroup nvx_p_semiGlobalMatching
 * \brief [Graph] Merges the disparity from previous level of pyramid to the current
 *                level. If the disparity on the current level is closer than 1px to
 *                maximum, the disparity from the previous level is taken. Thus, small
 *                disparity values are taken from higher resolution images.
 *
 * \param [in]  graph             Specifies the graph.
 * \param [in]  prev              Specifies the disparity image from the previous pyramid level.
 *                                    Only `VX_DF_IMAGE_S16` format is supported.
 *                                    Width must be divisible by 4
 * \param [inout] curr            Specifies the disparity image from the current pyramid level.
 *                                    The \p curr image should have the same type as \p prev image.
 *                                    The \p curr image should have the size 2*Wx2*H,
 *                                    where WxH is the size of \p prev.
 * \param [in]  D                 Specifies the number of disparities in cost volume.
 */
NVX_C_API vx_node nvxPSGMDisparityMergeNode(vx_graph graph, vx_image prev, vx_image curr,
                                            vx_int32 D);

/**
 * \ingroup nvx_p_semiGlobalMatching
 * \brief [Immediate] Merges the disparity from previous level of pyramid to the current
 *                    level. If the disparity on the current level is closer than 1px to
 *                    maximum, the disparity from the previous level is taken. Thus, small
 *                    disparity values are taken from higher resolution images.
 *
 * \param [in]  context           Specifies the context.
 * \param [in]  prev              Specifies the disparity image from the previous pyramid level.
 *                                    Only `VX_DF_IMAGE_S16` format is supported.
 *                                    Width must be divisible by 4
 * \param [inout] curr            Specifies the disparity image from the current pyramid level.
 *                                    The \p curr image should have the same type as \p prev image.
 *                                    The \p curr image should have the size 2*Wx2*H,
 *                                    where WxH is the size of \p prev
 * \param [in]  D                 Specifies the number of disparities in cost volume.
 */
NVX_C_API vx_status nvxuPSGMDisparityMerge(vx_context context, vx_image prev, vx_image curr,
                                           vx_int32 D);

/**
 * \ingroup nvx_p_semiGlobalMatching
 * \brief [Graph] Applies Census Transform to an image
 *
 * \param [in]  graph             Specifies the graph.
 * \param [in]  src               Specifies the source image (grayscale).
 *                                    Only `VX_DF_IMAGE_U8` format is supported.
 *                                    Width must be divisible by 4
 * \param [out] dst               Specifies the destination image.
 *                                    Only `VX_DF_IMAGE_U32` format is supported.
 *                                    The \p dst image must have the same size as \p left image.
 * \param [in]  win_size          Specifies the window size of the transform.
 *                                    Must be an odd positive integer.
 */

NVX_C_API vx_node nvxCensusTransformNode(vx_graph graph,
                                         vx_image src,
                                         vx_image dst,
                                         vx_int32 win_size);

/**
 * \ingroup nvx_p_semiGlobalMatching
 * \brief [Immediate] Applies Census Transform to an image.
 *
 * \param [in]  context             Specifies the context.
 * \param [in]  src               Specifies the source image (grayscale).
 *                                    Only `VX_DF_IMAGE_U8` format is supported.
 *                                    Width must be divisible by 4
 * \param [out] dst               Specifies the destination image.
 *                                    Only `VX_DF_IMAGE_U32` format is supported.
 *                                    The \p dst image must have the same size as \p left image.
 * \param [in]  win_size          Specifies the window size of the transform.
 *                                    Must be an odd positive integer.
 */

NVX_C_API vx_status nvxuCensusTransform(vx_context context,
                                        vx_image src,
                                        vx_image dst,
                                        vx_int32 win_size);

/**
 * \ingroup nvx_p_semiGlobalMatching
 * \brief [Graph] Hamming cost function.
 *
 * \param [in]  graph             Specifies the graph.
 * \param [in]  left              Specifies the lLeft stereo image.
 *                                    Only `VX_DF_IMAGE_U32` format is supported.
 *                                    Width must be divisible by 4
 * \param [in]  right             Specifies the right stereo image.
 *                                    The \p right image must have the same size and type as \p left image.
 * \param [out] cost              Specifies the resulting cost.
 *                                    The size of the \p cost image must be W*D x H,
 *                                    where W and H are the width and height of the
 *                                    \p left image, and D = maxD - minD.
 * \param [in]  minD              Specifies the minimum disparity value.
 * \param [in]  maxD              Specifies the maximum disparity value.
 * \param [in]  win_size          Specifies the window size of the cost function.
 */

NVX_C_API vx_node nvxComputeCostHammingNode(vx_graph graph,
                                            vx_image left,
                                            vx_image right,
                                            vx_image cost,
                                            vx_int32 minD,
                                            vx_int32 maxD,
                                            vx_int32 win_size);

/**
 * \ingroup nvx_p_semiGlobalMatching
 * \brief [Immediate] Hamming cost function.
 *
 * \param [in]  context             Specifies the context.
 * \param [in]  left              Specifies the left stereo image.
 *                                    Only `VX_DF_IMAGE_U32` format is supported.
 *                                    Width must be divisible by 4
 * \param [in]  right             Specifies the right stereo image.
 *                                    The \p right image must have the same size and type as \p left image.
 * \param [out] cost              Specifies the resulting cost.
 *                                    The size of the \p cost image must be W*D x H,
 *                                    where W and H are the width and height of the
 *                                    \p left image, and D = maxD - minD.
 * \param [in]  minD              Specifies the minimum disparity value.
 * \param [in]  maxD              Specifies the maximum disparity value.
 * \param [in]  win_size          Specifies the window size of the cost function.
 */

NVX_C_API vx_status nvxuComputeCostHamming(vx_context context,
                                           vx_image left,
                                           vx_image right,
                                           vx_image cost,
                                           vx_int32 minD,
                                           vx_int32 maxD,
                                           vx_int32 win_size);

//----------------------------------------------------------------------------
// Primitive : Copy Image
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_p_copy_image
 * \brief [Graph] Copies data from one image to another.
 *
 * \param [in]  graph       Specifies the graph.
 * \param [in]  src         Specifies the input image.
 *                              The primitive supports all image formats.
 * \param [out] dst         Specifies the output image.
 *                              It should have the same size and format as the input image.
 *                              Output size and format can be automatically determined
 *                              for virtual images.
 *
 * \return A valid node reference or an error object (use `vxGetStatus`).
 */
NVX_C_API vx_node nvxCopyImageNode(vx_graph graph,
                                   vx_image src,
                                   vx_image dst);

/**
 * \ingroup nvx_p_copy_image
 * \brief [Immediate] Copies data from one image to another.
 *
 * \param [in]  context     Specifies the context.
 * \param [in]  src         Specifies the input image.
 *                              The primitive supports all image formats.
 * \param [out] dst         Specifies the output image.
 *                              It should have the same size and format as the input image.
 *
 * \return A `vx_status` enumerator.
 * \retval VX_SUCCESS                       No errors.
 * \retval VX_ERROR_INVALID_REFERENCE       Supplied parameters are not a valid references.
 * \retval VX_ERROR_INVALID_PARAMETERS      Supplied parameters are not valid.
 * \retval VX_ERROR_INVALID_SCOPE           Supplied parameters are virtual objects,
 *                                              which can't be used in immediate mode.
 * \retval VX_FAILURE                       Internal error in primitive implementation,
 *                                              check log for detailed information
 *                                              (\ref group_log).
 */
NVX_C_API vx_status nvxuCopyImage(vx_context context,
                                  vx_image src,
                                  vx_image dst);

//----------------------------------------------------------------------------
// Primitive : Flip Image
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_p_flip_image
 * \brief Defines modes for flip image operation.
 */
enum nvx_flip_mode_e
{
    NVX_FLIP_HORIZONTAL,    /**< \brief Horizontal flipping of the image. */
    NVX_FLIP_VERTICAL,      /**< \brief Vertical flipping of the image. */
    NVX_FLIP_BOTH           /**< \brief Simultaneous horizontal and vertical flipping of the image. */
};

/**
 * \ingroup nvx_p_flip_image
 * \brief [Graph] Flips the input image.
 *
 * \param [in]  graph           Specifies the graph.
 * \param [in]  input           Specifies the input image.
 *                                  Supported formats: `VX_DF_IMAGE_U8`, `VX_DF_IMAGE_RGB`, `VX_DF_IMAGE_RGBX`.
 * \param [out] output          Specifies the output image.
 *                                  It should have the same size and format as the input image.
 *                                  Output size and format can be automatically determined
 *                                  for virtual images.
 * \param [in]  flip_mode       The flipping mode (see \ref nvx_flip_mode_e).
 *
 * \return A valid node reference or an error object (use `vxGetStatus`).
 */
NVX_C_API vx_node nvxFlipImageNode(vx_graph graph, vx_image input, vx_image output, vx_enum flip_mode);

/**
 * \ingroup nvx_p_flip_image
 * \brief [Immediate] Flips the input image.
 *
 * \param [in]  context           Specifies the context.
 * \param [in]  input           Specifies the input image.
 *                                  Supported formats: `VX_DF_IMAGE_U8`, `VX_DF_IMAGE_RGB`, `VX_DF_IMAGE_RGBX`.
 * \param [out] output          Specifies the output image.
 *                                  It should have the same size and format as the input image.
 * \param [in]  flip_mode       The flipping mode (see \ref nvx_flip_mode_e).
 *
 * \return A `vx_status` enumerator.
 * \retval VX_SUCCESS                       No errors.
 * \retval VX_ERROR_INVALID_REFERENCE       Supplied parameters are not a valid references.
 * \retval VX_ERROR_INVALID_PARAMETERS      Supplied parameters are not valid.
 * \retval VX_ERROR_INVALID_SCOPE           Supplied parameters are virtual objects,
 *                                              which can't be used in immediate mode.
 * \retval VX_FAILURE                       Internal error in primitive implementation,
 *                                              check log for detailed information
 *                                              (\ref group_log).
 */
NVX_C_API vx_status nvxuFlipImage(vx_context context, vx_image input, vx_image output, vx_enum flip_mode);

//----------------------------------------------------------------------------
// Primitive : Hough Circles
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_p_hough_circles
 * \brief [Graph] Detects circles in a binary image.
 *
 * \param [in]  graph               Specifies the graph.
 * \param [in]  edges               Specifies the input binary image with edges
 *                                      (for example, output from \ref group_vision_function_canny).
 *                                      Only `VX_DF_IMAGE_U8` format is supported.
 * \param [in]  dx                  Specifies the input image with horizontal derivatives
 *                                      (for example, output from \ref group_vision_function_sobel3x3).
 *                                      Only `VX_DF_IMAGE_S16` format is supported.
 *                                      It must have the same size as \a edges image.
 * \param [in]  dy                  Specifies the input image with vertical derivatives
 *                                      (for example, output from \ref group_vision_function_sobel3x3).
 *                                      Only `VX_DF_IMAGE_S16` format is supported.
 *                                      It must have the same size as \a edges image.
 * \param [out] circles             Specifies the output array with detected circles.
 *                                      Each circle is encoded as a \ref nvx_point3f_t (x, y, radius).
 *                                      The array capacity must be explicitly provided, even for virtual arrays.
 * \param [out] s_num_detections    Optional output scalar that holds the total number of detected circles.
 *                                      Can be used to check if \a circles has enough capacity
 *                                      to hold all the detected circles.
 *                                      Must be a `VX_TYPE_UINT32` scalar.
 * \param [in]  dp                  Inverse ratio of the accumulator resolution to the image resolution.
 *                                      For example, if dp=1, the accumulator has the same resolution as the input image.
 *                                      If dp=2, the accumulator has the width and height twice as small as the input image.
 *                                      It must be greater or equal than 1.
 * \param [in]  minDist             Minimum distance between the centers of the detected circles.
 *                                      If the parameter is too small, multiple neighbor circles may be falsely detected
 *                                      in addition to a true one.
 *                                      If it is too large, some circles may be missed.
 *                                      It must be a positive value.
 * \param [in]  minRadius           Minimum circle radius.
 * \param [in]  maxRadius           Maximum circle radius.
 *                                      It must not be less than \a minRadius.
 * \param [in]  acc_threshold       The accumulator threshold for the circle centers at the detection stage.
 *                                      The smaller the threshold is, the more false circles may be detected.
 *                                      Circles corresponding to the larger accumulator values are returned first.
 *
 * \return A valid node reference or an error object (use `vxGetStatus`).
 *
 * \see nvx_p_hough_circles
 */
NVX_C_API vx_node nvxHoughCirclesNode(vx_graph graph,
                                      vx_image edges, vx_image dx, vx_image dy,
                                      vx_array circles, vx_scalar s_num_detections,
                                      vx_float32 dp, vx_float32 minDist,
                                      vx_uint32 minRadius, vx_uint32 maxRadius,
                                      vx_uint32 acc_threshold);

/**
 * \ingroup nvx_p_hough_circles
 * \brief [Immediate] Detects circles in a binary image.
 *
 * \param [in]  context             Specifies the context.
 * \param [in]  edges               Specifies the input binary image with edges
 *                                      (for example, output from \ref group_vision_function_canny).
 *                                      Only `VX_DF_IMAGE_U8` format is supported.
 * \param [in]  dx                  Specifies the input image with horizontal derivatives
 *                                      (for example, output from \ref group_vision_function_sobel3x3).
 *                                      Only `VX_DF_IMAGE_S16` format is supported.
 *                                      It must have the same size as \a edges image.
 * \param [in]  dy                  Specifies the input image with vertical derivatives
 *                                      (for example, output from \ref group_vision_function_sobel3x3).
 *                                      Only `VX_DF_IMAGE_S16` format is supported.
 *                                      It must have the same size as \a edges image.
 * \param [out] circles             Specifies the output array with detected circles.
 *                                      Each circle is encoded as a \ref nvx_point3f_t (x, y, radius).
 *                                      The array capacity must be explicitly provided, even for virtual arrays.
 * \param [out] s_num_detections    Optional output scalar that holds the total number of detected circles.
 *                                      Can be used to check if \a circles has enough capacity
 *                                      to hold all the detected circles.
 *                                      It must be a `VX_TYPE_UINT32` scalar.
 * \param [in]  dp                  Inverse ratio of the accumulator resolution to the image resolution.
 *                                      For example, if dp=1, the accumulator has the same resolution as the input image.
 *                                      If dp=2, the accumulator has the width and height twice as small as the input image.
 *                                      It must be greater or equal than 1.
 * \param [in]  minDist             Minimum distance between the centers of the detected circles.
 *                                      If the parameter is too small, multiple neighbor circles may be falsely detected
 *                                      in addition to a true one.
 *                                      If it is too large, some circles may be missed.
 *                                      It must be a positive value.
 * \param [in]  minRadius           Minimum circle radius.
 * \param [in]  maxRadius           Maximum circle radius.
 *                                      It must not be less than \a minRadius.
 * \param [in]  acc_threshold       The accumulator threshold for the circle centers at the detection stage.
 *                                      The smaller the threshold is, the more false circles may be detected.
 *                                      Circles corresponding to the larger accumulator values are returned first.
 *
 * \return A `vx_status` enumerator.
 * \retval VX_SUCCESS                       No errors.
 * \retval VX_ERROR_INVALID_REFERENCE       Supplied parameters are not a valid references.
 * \retval VX_ERROR_INVALID_PARAMETERS      Supplied parameters are not valid.
 * \retval VX_ERROR_INVALID_SCOPE           Supplied parameters are virtual objects,
 *                                              that cannot be used in immediate mode.
 * \retval VX_FAILURE                       Internal error in primitive implementation;
 *                                              check the log for detailed information.
 *                                              (\ref group_log).
 *
 * \see nvx_p_hough_circles
 */
NVX_C_API vx_status nvxuHoughCircles(vx_context context,
                                     vx_image edges, vx_image dx, vx_image dy,
                                     vx_array circles, vx_scalar s_num_detections,
                                     vx_float32 dp, vx_float32 minDist,
                                     vx_uint32 minRadius, vx_uint32 maxRadius,
                                     vx_uint32 acc_threshold);

//----------------------------------------------------------------------------
// Primitive : Hough Lines
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_p_hough_lines
 * \brief [Graph] Finds lines on image using standard Hough transform.
 *
 * \param [in]  graph       Specifies the graph.
 * \param [in]  input       Specifies the input image.
 *                              Only `VX_DF_IMAGE_U8` format is supported.
 *                              The image width and height must be less than \f$ 2^{16} \f$.
 * \param [out] output      Specifies the output lines list.
 *                              Only `NVX_TYPE_POINT3F` item type is supported.
 *                              The array capacity must be explicitly provided, even for virtual arrays.
 * \param [in]  rho         Specifies the distance resolution of the accumulator in pixels.
 *                              It must be a positive value.
 * \param [in]  theta       Specifies the angle resolution of the accumulator in radians.
 *                              It must be in range \f$ (0, \pi] \f$.
 * \param [in]  threshold   Specifies the accumulator threshold parameter.
 *                              Only lines that get enough votes (> \a threshold) are returned.
 * \param [out] num_lines   Specifies the total number of detected lines in image (optional).
 *                              It must be a `VX_TYPE_UINT32` scalar.
 *
 * \return A valid node reference or an error object (use `vxGetStatus`).
 *
 * \see nvx_p_hough_lines
 */
NVX_C_API vx_node nvxHoughLinesNode(vx_graph graph, vx_image input, vx_array output,
                                    vx_float32 rho, vx_float32 theta, vx_uint32 threshold,
                                    vx_scalar num_lines);

/**
 * \ingroup nvx_p_hough_lines
 * \brief [Immediate] Finds lines on image using standard Hough transform.
 *
 * \param [in]  context     Specifies the context.
 * \param [in]  input       Specifies the input image (8-bit grayscale).
 *                              Only `VX_DF_IMAGE_U8` format is supported.
 *                              The image width and height must be less than \f$ 2^{16} \f$.
 * \param [out] output      Specifies the output lines list.
 *                              Only `NVX_TYPE_POINT3F` item type is supported.
 *                              The array capacity must be explicitly provided, even for virtual arrays.
 * \param [in]  rho         Specifies the distance resolution of the accumulator in pixels.
 *                              It must be a positive value.
 * \param [in]  theta       Specifies the angle resolution of the accumulator in radians.
 *                              It must be in range \f$ (0, \pi] \f$.
 * \param [in]  threshold   Specifies the accumulator threshold parameter.
 *                              Only those lines are returned that get enough votes (> \a threshold).
 * \param [out] num_lines   Specifies the total number of detected lines in image (optional).
 *                              It should be `VX_TYPE_UINT32` scalar.
 *
 * \return A `vx_status` enumerator.
 * \retval VX_SUCCESS                       No errors.
 * \retval VX_ERROR_INVALID_REFERENCE       Supplied parameters are not a valid references.
 * \retval VX_ERROR_INVALID_PARAMETERS      Supplied parameters are not valid.
 * \retval VX_ERROR_INVALID_SCOPE           Supplied parameters are virtual objects,
 *                                              that cannot be used in immediate mode.
 * \retval VX_FAILURE                       Internal error in primitive implementation;
 *                                              check the log for detailed information
 *                                              (\ref group_log).
 *
 * \see nvx_p_hough_lines
 */
NVX_C_API vx_status nvxuHoughLines(vx_context context, vx_image input, vx_array output,
                                   vx_float32 rho, vx_float32 theta, vx_uint32 threshold,
                                   vx_scalar num_lines);

/**
 * \ingroup nvx_p_hough_lines
 * \brief [Graph] Finds line segments in a binary image using the probabilistic
 *          Hough transform.
 *
 * \param [in]  graph           Specifies the graph.
 * \param [in]  input           Specifies the input image (8-bit grayscale).
 *                                  Only `VX_DF_IMAGE_U8` format is supported.
 *                                  The image width and height must be less than \f$ 2^{16} \f$.
 * \param [out] output          Specifies the output lines list.
 *                                  Only `NVX_TYPE_POINT4F` item type is supported.
 *                                  The array capacity must be explicitly provided, even for virtual arrays.
 * \param [in]  rho             Specifies the distance resolution of the accumulator in pixels.
 *                                  It must be a positive value.
 * \param [in]  theta           Specifies the angle resolution of the accumulator in radians.
 *                                  It must be in range \f$ (0, \pi] \f$.
 * \param [in]  threshold       Specifies the accumulator threshold parameter.
 *                                  Only lines that get enough votes (> \a threshold) are returned.
 * \param [in]  minLineLength   Specifies the minimum line length. Shorter segments are rejected.
 * \param [in]  maxLineGap      Specifies the maximum allowed gap between points on the same line to link them.
 * \param [out] num_segments    Specifies the total number of detected segments in image (optional).
 *                                  It should be `VX_TYPE_UINT32` scalar.
 *
 * \return A valid node reference or an error object (use `vxGetStatus`).
 *
 * \see nvx_p_hough_lines
 */
NVX_C_API vx_node nvxHoughSegmentsNode(vx_graph graph, vx_image input, vx_array output,
                                       vx_float32 rho, vx_float32 theta, vx_uint32 threshold, vx_uint32 minLineLength, vx_uint32 maxLineGap,
                                       vx_scalar num_segments);

/**
 * \ingroup nvx_p_hough_lines
 * \brief [Immediate] Finds line segments in a binary image using the probabilistic
 *          Hough transform.
 *
 * \param [in]  context         Specifies the context.
 * \param [in]  input           Specifies the input image (8-bit grayscale).
 *                                  Only `VX_DF_IMAGE_U8` format is supported.
 *                                  The image width and height must be less than \f$ 2^{16} \f$.
 * \param [out] output          Specifies the output lines list.
 *                                  Only `NVX_TYPE_POINT4F` item type is supported.
 *                                  The array capacity must be explicitly provided, even for virtual arrays.
 * \param [in]  rho             Specifies the distance resolution of the accumulator in pixels.
 *                                  It must be a positive value.
 * \param [in]  theta           Specifies the angle resolution of the accumulator in radians.
 *                                  It must be in range \f$ (0, \pi] \f$.
 * \param [in]  threshold       Specifies the accumulator threshold parameter.
 *                                  Only lines that get enough votes (> \a threshold) are returned.
 * \param [in]  minLineLength   Specifies the minimum line length. Shorter segments are rejected.
 * \param [in]  maxLineGap      Specifies the maximum allowed gap between points on the same line to link them.
 * \param [out] num_segments    Specifies the total number of detected segments in image (optional).
 *                                  It should be `VX_TYPE_UINT32` scalar.
 *
 * \return A `vx_status` enumerator.
 * \retval VX_SUCCESS                       No errors.
 * \retval VX_ERROR_INVALID_REFERENCE       Supplied parameters are not a valid references.
 * \retval VX_ERROR_INVALID_PARAMETERS      Supplied parameters are not valid.
 * \retval VX_ERROR_INVALID_SCOPE           Supplied parameters are virtual objects,
 *                                              that cannot be used in immediate mode.
 * \retval VX_FAILURE                       Internal error in primitive implementation,
 *                                              check log for detailed information
 *                                              (\ref group_log).
 *
 * \see nvx_p_hough_lines
 */
NVX_C_API vx_status nvxuHoughSegments(vx_context context, vx_image input, vx_array output,
                                      vx_float32 rho, vx_float32 theta, vx_uint32 threshold, vx_uint32 minLineLength, vx_uint32 maxLineGap,
                                      vx_scalar num_segments);

//----------------------------------------------------------------------------
// Primitive : Scharr3x3
//----------------------------------------------------------------------------

/**
 * \ingroup vx_p_scharr
 * \brief [Graph] Applies Scharr 3 x 3 operator.
 *
 * \param [in]  graph   Specifies the graph.
 * \param [in]  input   Specifies the input image. Only `VX_DF_IMAGE_U8` format is supported.
 * \param [out] grad_x  [optional] Specifies the output gradient in the x direction.
 *                                     Only `VX_DF_IMAGE_S16` format is supported.
 * \param [out] grad_y  [optional] Specifies the output gradient in the y direction.
 *                                     Only `VX_DF_IMAGE_S16` format is supported.
 *
 * @note At least one output parameter (\p grad_x or \p grad_y) must be provided.
 *
 * \return A valid node reference or an error object (use `vxGetStatus`).
 *
 * \see vx_p_scharr
 */
NVX_C_API vx_node nvxScharr3x3Node(vx_graph graph, vx_image input, vx_image grad_x, vx_image grad_y);

/**
 * \ingroup vx_p_scharr
 * \brief [Immediate] Applies Scharr 3 x 3 operator.
 *
 * \param [in]  context Specifies the context.
 * \param [in]  input   Specifies the input image. Only `VX_DF_IMAGE_U8` format is supported.
 * \param [out] grad_x  [optional] Specifies the output gradient in the x direction.
 *                                     Only `VX_DF_IMAGE_S16` format is supported.
 * \param [out] grad_y  [optional] Specifies the output gradient in the y direction.
 *                                     Only `VX_DF_IMAGE_S16` format is supported.
 *
 * @note At least one output parameter (\p grad_x or \p grad_y) must be provided.
 *
 * \return A `vx_status` enumerator.
 * \retval VX_SUCCESS                       No errors.
 * \retval VX_ERROR_INVALID_REFERENCE       Supplied parameters are not a valid references.
 * \retval VX_ERROR_INVALID_PARAMETERS      Supplied parameters are not valid.
 * \retval VX_ERROR_INVALID_SCOPE           Supplied parameters are virtual objects,
 *                                              that cannot be used in immediate mode.
 * \retval VX_FAILURE                       Internal error in primitive implementation,
 *                                              check log for detailed information
 *                                              (\ref group_log).
 *
 * \see vx_p_scharr
 */
NVX_C_API vx_status nvxuScharr3x3(vx_context context, vx_image input, vx_image grad_x, vx_image grad_y);

//----------------------------------------------------------------------------
// Primitive : Laplacian
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_p_laplacian
 * \brief [Graph] Creates a Laplacian filter node.
 *
 * \param [in]  graph             Specifies the graph.
 * \param [in]  input             Specifies the input image. Only `VX_DF_IMAGE_U8` format is supported.
 * \param [out] output            Specifies the output image. Only `VX_DF_IMAGE_U8` format is supported.
 *
 * \return A valid node reference or an error object (use `vxGetStatus`).
 *
 * \see nvx_p_laplacian
 */
NVX_C_API vx_node nvxLaplacian3x3Node(vx_graph graph, vx_image input, vx_image output);

/**
 * \ingroup nvx_p_laplacian
 * \brief [Immediate] Applies a Laplacian operator to the input image.
 *
 * \param [in]  context           Specifies the context.
 * \param [in]  input             Specifies the input image. Only `VX_DF_IMAGE_U8` format is supported.
 * \param [out] output            Specifies the output image. Only `VX_DF_IMAGE_U8` format is supported.
 *
 * \return A `vx_status` enumerator.
 * \retval VX_SUCCESS                       No errors.
 * \retval VX_ERROR_INVALID_REFERENCE       Supplied parameters are not a valid references.
 * \retval VX_ERROR_INVALID_PARAMETERS      Supplied parameters are not valid.
 * \retval VX_ERROR_INVALID_SCOPE           Supplied parameters are virtual objects,
 *                                              that cannot be used in immediate mode.
 * \retval VX_FAILURE                       Internal error in primitive implementation,
 *                                              check log for detailed information
 *                                              (\ref group_log).
 *
 * \see nvx_p_laplacian
 */
NVX_C_API vx_status nvxuLaplacian3x3(vx_context context, vx_image input, vx_image output);

//----------------------------------------------------------------------------
// Primitive : Median Flow
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_p_medianflow
 * \brief [Graph] Computes median flow.
 *
 * \param [in]  graph               Specifies the graph.
 * \param [in]  prev_pts            Specifies the input previous points list.
 *                                      Only `VX_TYPE_KEYPOINT` and `NVX_TYPE_POINT2F` item types are supported.
 * \param [in]  next_pts            Specifies the input next points list.
 *                                      It must have the same item type and number of items as \a prev_pts.
 * \param [in]  pts_fb              [optional] Specifies the backward points list.
 *                                      It must have the same item type and number of items as \a prev_pts.
 * \param [out] out                 Specifies the output median flow. It is a one element `NVX_TYPE_POINT3F` array.
 *                                      \a x and \a y fields of the first element represent estimated displacement,
 *                                      \a z field represents estimated scale change.
 *                                      In case of estimation failure \f$ (0, 0, -1) \f$ is returned.
 * \param [in]  estimate_scale      Specifies whether to estimate scale change.
 * \param [in]  filter_flow_by_err  Specifies whether to filter out points with a high error value.
 * \param [in]  error_fb_thresh     [optional] Specifies the threshold for forward-backward errors.
 *                                      Pass a nonpositive value to disable forward-backward filtering.
 *
 * \return A valid node reference or an error object (use `vxGetStatus`).
 *
 * \see nvx_p_medianflow
 */
NVX_C_API vx_node nvxMedianFlowNode(vx_graph graph, vx_array prev_pts, vx_array next_pts, vx_array pts_fb, vx_array out,
                                    vx_bool estimate_scale, vx_bool filter_flow_by_err, vx_float32 error_fb_thresh);

/**
 * \ingroup nvx_p_medianflow
 * \brief [Immediate] Computes median flow.
 *
 * \param [in]  context             Specifies the context.
 * \param [in]  prev_pts            Specifies the input previous points list.
 *                                      Only `VX_TYPE_KEYPOINT` and `NVX_TYPE_POINT2F` item types are supported.
 * \param [in]  next_pts            Specifies the input next points list.
 *                                      It must have the same item type and number of items as \a prev_pts.
 * \param [in]  pts_fb              [optional] Specifies the backward points list.
 *                                      It must have the same item type and number of items as \a prev_pts.
 * \param [out] out                 Specifies the output median flow. It is a one element `NVX_TYPE_POINT3F` array.
 *                                      \a x and \a y fields of the first element represent estimated displacement,
 *                                      \a z field represents estimated scale change.
 *                                      In case of estimation failure \f$ (0, 0, -1) \f$ is returned.
 * \param [in]  estimate_scale      Specifies whether to estimate scale change.
 * \param [in]  filter_flow_by_err  Specifies whether to filter out points with a high error value.
 * \param [in]  error_fb_thresh     [optional] Specifies the threshold for forward-backward errors.
 *                                      Pass a nonpositive value to disable forward-backward filtering.
 *
 * \return A `vx_status` enumerator.
 * \retval VX_SUCCESS                       No errors.
 * \retval VX_ERROR_INVALID_REFERENCE       Supplied parameters are not a valid references.
 * \retval VX_ERROR_INVALID_PARAMETERS      Supplied parameters are not valid.
 * \retval VX_ERROR_INVALID_SCOPE           Supplied parameters are virtual objects,
 *                                              which can't be used in immediate mode.
 * \retval VX_FAILURE                       Internal error in primitive implementation,
 *                                              check log for detailed information
 *                                              (\ref group_log).
 *
 * \see nvx_p_medianflow
 */
NVX_C_API vx_status nvxuMedianFlow(vx_context context, vx_array prev_pts, vx_array next_pts, vx_array pts_fb, vx_array out,
                                   vx_bool estimate_scale, vx_bool filter_flow_by_err, vx_float32 error_fb_thresh);
//----------------------------------------------------------------------------
// Primitive : Stereo Block Matching
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_p_stereobm
 * \brief [Graph] This primitive computes a dense disparity map for a given stereo
 *         pair.
 *
 * \param [in]  graph           Specifies the graph.
 * \param [in]  left            Specifies the left image. Only `VX_DF_IMAGE_U8` format is supported.
 * \param [in]  right           Specifies the right image. It must have the same size and format as \a left.
 * \param [out] disp            Specifies the output disparity. Only `VX_DF_IMAGE_U8` format is supported.
 *                                  It must have the same size as \a left.
 * \param [in]  winSize         Specifies the average window size for sum of absolute differences (SAD).
 *                                  It must be an odd integer in range \f$ [3, 31] \f$.
 * \param [in]  maxDisparity    Specifies the maximum possible disparity that is considered.
 *                                  It must be a positive integer not greater than 256 and divisible by 8.
 *
 * \return A valid node reference or an error object (use `vxGetStatus`).
 *
 * \see nvx_p_stereobm
 */
NVX_C_API vx_node nvxStereoBlockMatchingNode(vx_graph graph, vx_image left, vx_image right, vx_image disp,
                                             vx_uint32 winSize, vx_uint32 maxDisparity);

/**
 * \ingroup nvx_p_stereobm
 * \brief [Immediate] This primitive computes a dense disparity map for a given stereo
 *         pair.
 *
 * \param [in]  context         Specifies the context.
 * \param [in]  left            Specifies the left image. Only `VX_DF_IMAGE_U8` format is supported.
 * \param [in]  right           Specifies the right image. It must have the same size and format as \a left.
 * \param [out] disp            Specifies the output disparity. Only `VX_DF_IMAGE_U8` format is supported.
 *                                  It must have the same size as \a left.
 * \param [in]  winSize         Specifies the average window size for sum of absolute differences (SAD).
 *                                  It must be an odd integer in range \f$ [3, 31] \f$.
 * \param [in]  maxDisparity    Specifies the maximum possible disparity that is considered.
 *                                  It must be a positive integer not greater than 256 and divisible by 8.
 *
 * \return A `vx_status` enumerator.
 * \retval VX_SUCCESS                       No errors.
 * \retval VX_ERROR_INVALID_REFERENCE       Supplied parameters are not a valid references.
 * \retval VX_ERROR_INVALID_PARAMETERS      Supplied parameters are not valid.
 * \retval VX_ERROR_INVALID_SCOPE           Supplied parameters are virtual objects
 *                                              that cannot be used in immediate mode.
 * \retval VX_FAILURE                       Internal error in primitive implementation;
 *                                              check the log for detailed information.
 *                                              (\ref group_log).
 *
 * \see nvx_p_stereobm
 */
NVX_C_API vx_status nvxuStereoBlockMatching(vx_context context, vx_image left, vx_image right, vx_image disp,
                                            vx_uint32 winSize, vx_uint32 maxDisparity);

//----------------------------------------------------------------------------
// Primitive : Find Homography
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_p_findhomography
 * \brief Method used to compute a homography matrix.
 */
enum nvx_find_homography_method_e {
    /** \brief A regular method using all the points. */
    NVX_FIND_HOMOGRAPHY_METHOD_USE_ALL_POINTS = 0x0,
    /** \brief RANSAC-based robust method. */
    NVX_FIND_HOMOGRAPHY_METHOD_RANSAC = 0x1,
    /** \brief Least-Median robust method. */
    NVX_FIND_HOMOGRAPHY_METHOD_LMEDS = 0x2,
};

/**
 * \ingroup nvx_p_findhomography
 * \brief [Graph] Computes homography matrix.
 *
 * \param [in]  graph                   Specifies the graph.
 * \param [in]  srcPoints               Specifies the coordinates of the points in the original plane (array of `vx_keypoint_t`,
 *                                          `nvx_keypointf_t` or `nvx_point2f_t` structs, number of the points must be >= 4).
 *                                          For `vx_keypoint_t` and `nvx_keypointf_t` types, the method uses points only with
 *                                          non-zero `tracking_status`.
 * \param [in]  dstPoints               Specifies the coordinates of the points in the target plane
 *                                          (it must have the same number of elements and type as \a srcPoints).
 *                                          For `vx_keypoint_t` and `nvx_keypointf_t` types, the method uses points only with
 *                                          non-zero `tracking_status`.
 *                                          The correspondence is between points with the same indexes in arrays.
 * \param [out] homography              Specifies the output homography matrix (`VX_TYPE_FLOAT32` 3x3 matrix).
 * \param [in]  method                  Specifies the method used to compute a homography matrix (see \ref nvx_find_homography_method_e).
 * \param [in]  threshold               Specifies the maximum allowed reprojection error to treat a point pair as an inlier,
 *                                          if \a RANSAC method is chosen. If \a srcPoints and \a dstPoints are measured in pixels,
 *                                          it usually makes sense to set this parameter somewhere in the range of 1 to 10.
 *                                          Default value is 3.
 * \param [in]  maxEstimateIters        Specifies the maximum allowed number of estimation iterations
 *                                          for robust methods (\a RANSAC and \a LMeDS).
 *                                          Default value is 2000.
 * \param [in]  maxRefineIters          Specifies the maximum allowed number of refinement iterations
 *                                          for robust methods (\a RANSAC and \a LMeDS).
 *                                          Default value is 10.
 * \param [in]  confidence              Specifies the confidence level for robust methods (\a RANSAC and \a LMeDS).
 *                                          It must be a value between 0 and 1.
 *                                          Default value is 0.995.
 * \param [in]  outlierRatio            Specifies the outlier ratio if \a LMeDS method is chosen.
 *                                          Default value is 0.45.
 * \param [out] inliers                 Specifies the optional inliers/outliers output mask.
 *                                          The `inliers[i]` value is set to 0 if corresponding points pair `srcPoints[i]` and
 *                                          `dstPoints[i]` is marked as outlier by the method.
 *                                          It must be a `VX_TYPE_UINT8` array with capacity greater than or equal
 *                                          to the capacity of \a srcPoints.
 *
 * \return vx_node
 */
NVX_C_API vx_node nvxFindHomographyNode(vx_graph graph, vx_array srcPoints, vx_array dstPoints, vx_matrix homography,
                                        vx_enum method, vx_float32 threshold,
                                        vx_int32 maxEstimateIters, vx_int32 maxRefineIters,
                                        vx_float32 confidence, vx_float32 outlierRatio,
                                        vx_array inliers);

/**
 * \ingroup nvx_p_findhomography
 * \brief [Immediate] Computes homography matrix.
 *
 * \param [in]  context                 Specifies the context.
 * \param [in]  srcPoints               Specifies the coordinates of the points in the original plane (array of `vx_keypoint_t`,
 *                                          `nvx_keypointf_t` or `nvx_point2f_t` structs, number of the points must be >= 4).
 *                                          For `vx_keypoint_t` and `nvx_keypointf_t` types, the method uses points only with
 *                                          non-zero `tracking_status`.
 * \param [in]  dstPoints               Specifies the coordinates of the points in the target plane
 *                                          (it must have the same number of elements and type as \a srcPoints).
 *                                          For `vx_keypoint_t` and `nvx_keypointf_t` types, the method uses points only with
 *                                          non-zero `tracking_status`.
 *                                          The correspondence is between points with the same indexes in arrays.
 * \param [out] homography              Specifies the output homography matrix (`VX_TYPE_FLOAT32` 3x3 matrix).
 * \param [in]  method                  Specifies the method used to compute a homography matrix (see \ref nvx_find_homography_method_e)
 *                                          (optional, \ref  NVX_FIND_HOMOGRAPHY_METHOD_USE_ALL_POINTS by default).
 * \param [in]  threshold               Specifies the maximum allowed reprojection error to treat a point pair as an inlier,
 *                                          if \a RANSAC method is chosen. If \a srcPoints and \a dstPoints are measured in pixels,
 *                                          it usually makes sense to set this parameter somewhere in the range of 1 to 10.
 *                                          Default value is 3.
 * \param [in]  maxEstimateIters        Specifies the maximum allowed number of estimation iterations
 *                                          for robust methods (\a RANSAC and \a LMeDS).
 *                                          Default value is 2000.
 * \param [in]  maxRefineIters          Specifies the maximum allowed number of refinement iterations
 *                                          for robust methods (\a RANSAC and \a LMeDS).
 *                                          Default value is 10.
 * \param [in]  confidence              Specifies the confidence level for robust methods (\a RANSAC and \a LMeDS).
 *                                          It should be a value between 0 and 1.
 *                                          Default value is 0.995.
 * \param [in]  outlierRatio            Specifies the outlier ratio if \a LMeDS method is chosen.
 *                                          Default value is 0.45.
 * \param [out] inliers                 Specifies the optional inliers/outliers output mask.
 *                                          The `inliers[i]` value is set to 0 if corresponding points pair `srcPoints[i]` and
 *                                          `dstPoints[i]` is marked as outlier by the method.
 *                                          It must be a `VX_TYPE_UINT8` array with capacity greater than or equal
 *                                          to the capacity of \a srcPoints.
 *
 * \return vx_status
 */
NVX_C_API vx_status nvxuFindHomography(vx_context context, vx_array srcPoints, vx_array dstPoints, vx_matrix homography,
                                       vx_enum method, vx_float32 threshold,
                                       vx_int32 maxEstimateIters,  vx_int32 maxRefineIters,
                                       vx_float32 confidence, vx_float32 outlierRatio,
                                       vx_array inliers);

//----------------------------------------------------------------------------
// Primitive : Create Motion Field
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_p_create_motion_field
 * \brief [Graph] Creates initial motion field from a current image into reference image.
 *
 * \param [in]  graph               Specifies the graph.
 * \param [in]  ref_image           Specifies the reference image (8-bit grayscale).
 * \param [in]  cur_image           Specifies the current image (8-bit grayscale).
 *                                      It must have the same size as \p ref_image.
 * \param [in]  anchor              Specifies the optional anchor field.
 *                                      It must have \f$ [W / B, H / B] \f$ size, where
 *                                      \f$ W \times H \f$ - \p ref_image size and \f$ B \f$ - block size.
 *                                      For each \f$ B \times B \f$ block on \p ref_image the \p anchor image
 *                                      contains an offset of search window on \p cur_image in Q14.2 format (\ref NVX_DF_IMAGE_2S16).
 *                                      If the \p anchor parameter is missed, it is assumed that
 *                                      the offset is zero for all blocks.
 * \param [in]  bias                Specifies the optional bias field.
 *                                      It must have \f$ [W / B, H / B] \f$ size, where
 *                                      \f$ W \times H \f$ - \p ref_image size and \f$ B \f$ - block size.
 *                                      For each \f$ B \times B \f$ block on \p ref_image the \p bias image
 *                                      contains a bias vector for cost calculation in Q14.2 format (\ref NVX_DF_IMAGE_2S16).
 *                                      If the \p bias parameter is missed, it is assumed that
 *                                      the bias vector is zero for all blocks.
 * \param [out] best_mv0            Specifies the output image of the best motion vectors.
 *                                      It must have \f$ [W / B, H / B] \f$ size, where
 *                                      \f$ W \times H \f$ - \p ref_image size and \f$ B \f$ - block size.
 *                                      The motion vectors will be stored in Q14.2 format (\ref NVX_DF_IMAGE_2S16).
 *                                      Can be NULL if the primitive is used for SAD table calculation only.
 * \param [out] best_mv1            Specifies the output image of the second best motion vectors.
 *                                      It must have \f$ [W / B, H / B] \f$ size, where
 *                                      \f$ W \times H \f$ - \p ref_image size and \f$ B \f$ - block size.
 *                                      The motion vectors will be stored in Q14.2 format (\ref NVX_DF_IMAGE_2S16).
 *                                      Can be NULL if the primitive is used for SAD table calculation only.
 * \param [out] sad_table           Specifies the optional output image with SAD table.
 *                                      It must have \f$ [W / B * SW * SH, H / B] \f$ size, where
 *                                      \f$ W \times H \f$ - \p ref_image size,  \f$ SW \times SH \f$ - search window size,
 *                                      and \f$ B \f$ - block size.
 *                                      For each \f$ B \times B \f$ block on \p ref_image and for each position in search window
 *                                      the \p sad_table image contains SAD (sum of absolute diferences) value
 *                                      for corresponding blocks in U32 format (\ref VX_DF_IMAGE_U32).
 *                                      The values are stored contiguously, i.e., first \f$ SW * SH \f$ values
 *                                      corresponds to the first block. Search window is treated in row major order started from
 *                                      top left corner.
 * \param [in]  blockSize           Specifies the block size.
 * \param [in]  searchWindowWidth   Specifies the search window width.
 * \param [in]  searchWindowHeight  Specifies the search window height.
 *                                      Supported search window sizes: 16x16, 32x32, 64x64, 64x32, 32x16 and 48x32.
 * \param [in]  biasWeight          Specifies the weight of bias term in cost formula.
 * \param [in]  mvDivFactor         Specifies the best motion vectors diversity factor.
 *
 * \return A valid node reference or an error object (use \ref vxGetStatus).
 */
NVX_C_API vx_node nvxCreateMotionFieldNode(vx_graph graph,
                                           vx_image ref_image, vx_image cur_image,
                                           vx_image anchor, vx_image bias,
                                           vx_image best_mv0, vx_image best_mv1,
                                           vx_image sad_table,
                                           vx_int32 blockSize,
                                           vx_int32 searchWindowWidth, vx_int32 searchWindowHeight,
                                           vx_float32 biasWeight,
                                           vx_int32 mvDivFactor);

/**
 * \ingroup nvx_p_create_motion_field
 * \brief [Immediate] Creates initial motion field from a current image into reference image.
 *
 * \param [in]  context             Specifies the context.
 * \param [in]  ref_image           Specifies the reference image (8-bit grayscale).
 * \param [in]  cur_image           Specifies the current image (8-bit grayscale).
 *                                      It must have the same size as \p ref_image.
 * \param [in]  anchor              Specifies the optional anchor field.
 *                                      It must have \f$ [W / B, H / B] \f$ size, where
 *                                      \f$ W \times H \f$ - \p ref_image size and \f$ B \f$ - block size.
 *                                      For each \f$ B \times B \f$ block on \p ref_image the \p anchor image
 *                                      contains an offset of search window on \p cur_image in Q14.2 format (\ref NVX_DF_IMAGE_2S16).
 *                                      If the \p anchor parameter is missed, it is assumed that
 *                                      the offset is zero for all blocks.
 * \param [in]  bias                Specifies the optional bias field.
 *                                      It must have \f$ [W / B, H / B] \f$ size, where
 *                                      \f$ W \times H \f$ - \p ref_image size and \f$ B \f$ - block size.
 *                                      For each \f$ B \times B \f$ block on \p ref_image the \p bias image
 *                                      contains a bias vector for cost calculation in Q14.2 format (\ref NVX_DF_IMAGE_2S16).
 *                                      If the \p bias parameter is missed, it is assumed that
 *                                      the bias vector is zero for all blocks.
 * \param [out] best_mv0            Specifies the output image of the best motion vectors.
 *                                      It must have \f$ [W / B, H / B] \f$ size, where
 *                                      \f$ W \times H \f$ - \p ref_image size and \f$ B \f$ - block size.
 *                                      The motion vectors will be stored in Q14.2 format (\ref NVX_DF_IMAGE_2S16).
 *                                      Can be NULL if the primitive is used for SAD table calculation only.
 * \param [out] best_mv1            Specifies the output image of the second best motion vectors.
 *                                      It must have \f$ [W / B, H / B] \f$ size, where
 *                                      \f$ W \times H \f$ - \p ref_image size and \f$ B \f$ - block size.
 *                                      The motion vectors will be stored in Q14.2 format (\ref NVX_DF_IMAGE_2S16).
 *                                      Can be NULL if the primitive is used for SAD table calculation only.
 * \param [out] sad_table           Specifies the optional output image with SAD table.
 *                                      It must have \f$ [W / B * SW * SH, H / B] \f$ size, where
 *                                      \f$ W \times H \f$ - \p ref_image size,  \f$ SW \times SH \f$ - search window size,
 *                                      and \f$ B \f$ - block size.
 *                                      For each \f$ B \times B \f$ block on \p ref_image and for each position in search window
 *                                      the \p sad_table image contains SAD (sum of absolute diferences) value
 *                                      for corresponding blocks in U32 format (\ref VX_DF_IMAGE_U32).
 *                                      The values are stored contiguously, i.e., first \f$ SW * SH \f$ values
 *                                      corresponds to the first block. Search window is treated in row major order started from
 *                                      top left corner.
 * \param [in]  blockSize           Specifies the block size.
 * \param [in]  searchWindowWidth   Specifies the search window width.
 * \param [in]  searchWindowHeight  Specifies the search window height.
 *                                      Supported search window sizes: 16x16, 32x32, 64x64, 64x32, 32x16 and 48x32.
 * \param [in]  biasWeight          Specifies the weight of bias term in cost formula.
 * \param [in]  mvDivFactor         Specifies the best motion vectors diversity factor.
 *
 * \return A \ref vx_status enumerator.
 * \retval VX_SUCCESS                       No errors.
 * \retval VX_ERROR_INVALID_REFERENCE       Supplied parameters are not a valid reference.
 * \retval VX_ERROR_INVALID_PARAMETERS      Supplied parameters are not valid.
 * \retval VX_ERROR_INVALID_SCOPE           Supplied parameters are virtual objects
 *                                              that cannot be used in immediate mode.
 * \retval VX_FAILURE                       Internal error in primitive implementation,
 *                                              check log for detailed information
 *                                              (\ref group_log).
 */
NVX_C_API vx_status nvxuCreateMotionField(vx_context context,
                                          vx_image ref_image, vx_image cur_image,
                                          vx_image anchor, vx_image bias,
                                          vx_image best_mv0, vx_image best_mv1,
                                          vx_image sad_table,
                                          vx_int32 blockSize,
                                          vx_int32 searchWindowWidth, vx_int32 searchWindowHeight,
                                          vx_float32 biasWeight,
                                          vx_int32 mvDivFactor);

//----------------------------------------------------------------------------
// Primitive : Refine Motion Field
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_p_refine_motion_field
 * \brief [Graph] Iteratively refines motion field by applying the motion vectors to a center block in a 3x3 block neighborhood.
 *
 * \param [in]  graph               Specifies the graph.
 * \param [in]  in_mv0              Specifies the input motion field (first motion vectors).
 *                                      The motion vectors are assumed to be stored in Q14.2 format (\ref NVX_DF_IMAGE_2S16).
 * \param [in]  in_mv1              Specifies the input motion field (second motion vectors).
 *                                      It must have the same size and format as \p in_mv0 image.
 * \param [in]  sad_table           Specifies the input image with SAD table.
 *                                      It must have \f$ [W * SW * SH, H] \f$ size, where
 *                                      \f$ W \times H \f$ - \p in_mv0 size and \f$ SW \times SH \f$ - search window size.
 *                                      The values are assumed to be stored in U32 format (\ref VX_DF_IMAGE_U32).
 *                                      The SAD table can be obtained via \ref nvx_p_create_motion_field primitive.
 * \param [out] out_mv0             Specifies the output motion field (first motion vectors).
 *                                      It must have the same size and format as \p in_mv0 image.
 * \param [out] out_mv1             Specifies the output motion field (second motion vectors).
 *                                      It must have the same size and format as \p in_mv0 image.
 * \param [in]  searchWindowWidth   Specifies the search window width.
 * \param [in]  searchWindowHeight  Specifies the search window height.
 * \param [in]  numIterations       Specifies the number of iterations.
 * \param [in]  smoothnessFactor    Specifies the smoothness factor in cost formula.
 * \param [in]  mvDivFactor         Specifies the best motion vectors diversity factor.
 *
 * \return A valid node reference or an error object (use \ref vxGetStatus).
 */
NVX_C_API vx_node nvxRefineMotionFieldNode(vx_graph graph,
                                           vx_image in_mv0, vx_image in_mv1,
                                           vx_image sad_table,
                                           vx_image out_mv0, vx_image out_mv1,
                                           vx_int32 searchWindowWidth, vx_int32 searchWindowHeight,
                                           vx_int32 numIterations,
                                           vx_float32 smoothnessFactor,
                                           vx_int32 mvDivFactor);

/**
 * \ingroup nvx_p_refine_motion_field
 * \brief [Immediate] Iteratively refines motion field by applying the motion vectors to a center block in a 3x3 block neighborhood.
 *
 * \param [in]  context             Specifies the context.
 * \param [in]  in_mv0              Specifies the input motion field (first motion vectors).
 *                                      The motion vectors are assumed to be stored in Q14.2 format (\ref NVX_DF_IMAGE_2S16).
 * \param [in]  in_mv1              Specifies the input motion field (second motion vectors).
 *                                      It must have the same size and format as \p in_mv0 image.
 * \param [in]  sad_table           Specifies the input image with SAD table.
 *                                      It must have \f$ [W * SW * SH, H] \f$ size, where
 *                                      \f$ W \times H \f$ - \p in_mv0 size and \f$ SW \times SH \f$ - search window size.
 *                                      The values are assumed to be stored in U32 format (\ref VX_DF_IMAGE_U32).
 *                                      The SAD table can be obtained via \ref nvx_p_create_motion_field primitive.
 * \param [out] out_mv0             Specifies the output motion field (first motion vectors).
 *                                      It must have the same size and format as \p in_mv0 image.
 * \param [out] out_mv1             Specifies the output motion field (second motion vectors).
 *                                      It must have the same size and format as \p in_mv0 image.
 * \param [in]  searchWindowWidth   Specifies the search window width.
 * \param [in]  searchWindowHeight  Specifies the search window height.
 * \param [in]  numIterations       Specifies the number of iterations.
 * \param [in]  smoothnessFactor    Specifies the smoothness factor in cost formula.
 * \param [in]  mvDivFactor         Specifies the best motion vectors diversity factor.
 *
 * \return A \ref vx_status enumerator.
 * \retval VX_SUCCESS                       No errors.
 * \retval VX_ERROR_INVALID_REFERENCE       Supplied parameters are not a valid references.
 * \retval VX_ERROR_INVALID_PARAMETERS      Supplied parameters are not valid.
 * \retval VX_ERROR_INVALID_SCOPE           Supplied parameters are virtual objects
 *                                              that cannot be used in immediate mode.
 * \retval VX_FAILURE                       Internal error in primitive implementation,
 *                                              check log for detailed information
 *                                              (\ref group_log).
 */
NVX_C_API vx_status nvxuRefineMotionField(vx_context context,
                                          vx_image in_mv0, vx_image in_mv1,
                                          vx_image sad_table,
                                          vx_image out_mv0, vx_image out_mv1,
                                          vx_int32 searchWindowWidth, vx_int32 searchWindowHeight,
                                          vx_int32 numIterations,
                                          vx_float32 smoothnessFactor,
                                          vx_int32 mvDivFactor);

//----------------------------------------------------------------------------
// Primitive : Partition Motion Field
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_p_partition_motion_field
 * \brief [Graph] Partitions motion vector field for blocks onto motion vector field into quarter sized blocks (half size in each dimension).
 *
 * \param [in]  graph               Specifies the graph.
 * \param [in]  ref_image           Specifies the reference image (8-bit grayscale).
 * \param [in]  cur_image           Specifies the current image (8-bit grayscale).
 *                                      It must have the same size as \p ref_image.
 * \param [in]  in_mv_0             Specifies the input motion field for bigger blocks (first motion vectors).
 *                                      The motion vectors are assumed to be stored in Q14.2 format (\ref NVX_DF_IMAGE_2S16).
 * \param [in]  in_mv_1             Specifies the input motion field for bigger blocks (second motion vectors).
 *                                      It must have the same size and format as \p in_mv_0 image.
 * \param [out] out_mv_0            Specifies the output motion field for smaller blocks (first motion vectors).
 *                                      It must have the same format as \p in_mv_0 image.
 *                                      It must have twice larger size in each dimension than \p in_mv_0 image.
 * \param [out] out_mv_1            Specifies the optional output motion field for smaller blocks (second motion vectors), optional.
 *                                      It must have the same size and format as \p out_mv_0 image.
 * \param [in]  smoothnessFactor    Specifies the smoothness factor in cost formula.
 * \param [in]  mvDivFactor         Specifies the best motion vectors diversity factor.
 *
 * \return A valid node reference or an error object (use \ref vxGetStatus).
 */
NVX_C_API vx_node nvxPartitionMotionFieldNode(vx_graph graph,
                                              vx_image ref_image, vx_image cur_image,
                                              vx_image in_mv_0, vx_image in_mv_1,
                                              vx_image out_mv_0, vx_image out_mv_1,
                                              vx_float32 smoothnessFactor,
                                              vx_int32 mvDivFactor);

/**
 * \ingroup nvx_p_partition_motion_field
 * \brief [Immediate] Partitions motion vector field for blocks onto motion vector field into quarter sized blocks (half size in each dimension).
 *
 * \param [in]  context             Specifies the context.
 * \param [in]  ref_image           Specifies the reference image (8-bit grayscale).
 * \param [in]  cur_image           Specifies the current image (8-bit grayscale).
 *                                      It must have the same size as \p ref_image.
 * \param [in]  in_mv_0             Specifies the input motion field for bigger blocks (first motion vectors).
 *                                      The motion vectors are assumed to be stored in Q14.2 format (\ref NVX_DF_IMAGE_2S16).
 * \param [in]  in_mv_1             Specifies the input motion field for bigger blocks (second motion vectors).
 *                                      It must have the same size and format as \p in_mv_0 image.
 * \param [out] out_mv_0            Specifies the output motion field for smaller blocks (first motion vectors).
 *                                      It must have the same format as \p in_mv_0 image.
 *                                      It must have twice larger size in each dimension than \p in_mv_0 image.
 * \param [out] out_mv_1            Specifies the optional output motion field for smaller blocks (second motion vectors), optional.
 *                                      It must have the same size and format as \p out_mv_0 image.
 * \param [in]  smoothnessFactor    Specifies the smoothness factor in cost formula.
 * \param [in]  mvDivFactor         Specifies the best motion vectors diversity factor.
 *
 * \return A \ref vx_status enumerator.
 * \retval VX_SUCCESS                       No errors.
 * \retval VX_ERROR_INVALID_REFERENCE       Supplied parameters are not a valid references.
 * \retval VX_ERROR_INVALID_PARAMETERS      Supplied parameters are not valid.
 * \retval VX_ERROR_INVALID_SCOPE           Supplied parameters are virtual objects
 *                                              that cannot be used in immediate mode.
 * \retval VX_FAILURE                       Internal error in primitive implementation,
 *                                              check log for detailed information
 *                                              (\ref group_log).
 */
NVX_C_API vx_status nvxuPartitionMotionField(vx_context context,
                                             vx_image ref_image, vx_image cur_image,
                                             vx_image in_mv_0, vx_image in_mv_1,
                                             vx_image out_mv_0, vx_image out_mv_1,
                                             vx_float32 smoothnessFactor,
                                             vx_int32 mvDivFactor);

//----------------------------------------------------------------------------
// Primitive : Multiply by Scalar
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_p_multiply_by_scalar
 * \brief [Graph] Multiplies an input image by scalar and optionally converts it to another data type.
 *
 * \param [in]  graph       Specifies the graph.
 * \param [in]  src         Specifies the input image.
 *                              It must have \ref NVX_DF_IMAGE_2S16 format.
 * \param [out] dst         Specifies the output image.
 *                              It must have the same size as input image and
 *                               \ref NVX_DF_IMAGE_2S16 or \ref NVX_DF_IMAGE_2F32 format.
 *                              If the output format is not specified for virtual image,
 *                              it will be set to the same format as input image.
 * \param [in]  alpha       Specifies the \f$ \alpha \f$ coefficient.
 *
 * \return A valid node reference or an error object (use \ref vxGetStatus).
 */
NVX_C_API vx_node nvxMultiplyByScalarNode(vx_graph graph,
                                          vx_image src, vx_image dst,
                                          vx_float32 alpha);

/**
 * \ingroup nvx_p_multiply_by_scalar
 * \brief [Immediate] Multiplies an input image by scalar and optionally converts it to another data type.
 *
 * \param [in]  context             Specifies the context.
 * \param [in]  src         Specifies the input image.
 *                              It must have \ref NVX_DF_IMAGE_2S16 format.
 * \param [out] dst         Specifies the output image.
 *                              It must have the same size as input image and
 *                               \ref NVX_DF_IMAGE_2S16 or \ref NVX_DF_IMAGE_2F32 format.
 * \param [in]  alpha       Specifies the \f$ \alpha \f$ coefficient.
 *
 * \return A \ref vx_status enumerator.
 * \retval VX_SUCCESS                       No errors.
 * \retval VX_ERROR_INVALID_REFERENCE       Supplied parameters are not a valid references.
 * \retval VX_ERROR_INVALID_PARAMETERS      Supplied parameters are not valid.
 * \retval VX_ERROR_INVALID_SCOPE           Supplied parameters are virtual objects
 *                                              that cannot be used in immediate mode.
 * \retval VX_FAILURE                       Internal error in primitive implementation,
 *                                              check log for detailed information
 *                                              (\ref group_log).
 */
NVX_C_API vx_status nvxuMultiplyByScalar(vx_context context,
                                         vx_image src, vx_image dst,
                                         vx_float32 alpha);

#endif
