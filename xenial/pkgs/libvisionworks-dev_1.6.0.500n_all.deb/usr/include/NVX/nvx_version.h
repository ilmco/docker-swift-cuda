/*
 * Copyright (c) 2012-2015, NVIDIA CORPORATION.  All rights reserved.
 *
 * NVIDIA Corporation and its licensors retain all intellectual property
 * and proprietary rights in and to this software, related documentation
 * and any modifications thereto.  Any use, reproduction, disclosure or
 * distribution of this software and related documentation without an express
 * license agreement from NVIDIA Corporation is strictly prohibited.
 */

#ifndef __NVX_VERSION_H__
#define __NVX_VERSION_H__

#define NVX_MAJOR_VERSION (1)
#define NVX_MINOR_VERSION (6)
#define NVX_PATCH_VERSION (0)
#define NVX_BUILD_VERSION "500n"
#define NVX_SUFFIX_VERSION ""
#define NVX_VERSION_STRING "1.6.0"

#endif
