/*
 * Copyright (c) 2016, NVIDIA CORPORATION.  All rights reserved.
 *
 * NVIDIA Corporation and its licensors retain all intellectual property
 * and proprietary rights in and to this software, related documentation
 * and any modifications thereto.  Any use, reproduction, disclosure or
 * distribution of this software and related documentation without an express
 * license agreement from NVIDIA Corporation is strictly prohibited.
 */

#ifndef NVX_API_MACROS_H
#define NVX_API_MACROS_H

#include "nvx_export.h"

#ifndef NVX_EXTERN_C
#   ifdef __cplusplus
#       define NVX_EXTERN_C extern "C"
#   else
#       define NVX_EXTERN_C
#   endif
#endif

#ifndef NVX_C_API
    #define NVX_C_API NVX_EXTERN_C NVX_EXPORT
#endif

#ifndef NVX_CXX_API
    #define NVX_CXX_API NVX_EXPORT
#endif

#endif
