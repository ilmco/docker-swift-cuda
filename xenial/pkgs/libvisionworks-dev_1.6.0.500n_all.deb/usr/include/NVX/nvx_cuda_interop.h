/*
 * Copyright (c) 2016, NVIDIA CORPORATION.  All rights reserved.
 *
 * NVIDIA Corporation and its licensors retain all intellectual property
 * and proprietary rights in and to this software, related documentation
 * and any modifications thereto.  Any use, reproduction, disclosure or
 * distribution of this software and related documentation without an express
 * license agreement from NVIDIA Corporation is strictly prohibited.
 */

/**
 * \file
 * \brief CUDA Interoperability API
 */

#ifndef NVX_CUDA_INTEROP_H
#define NVX_CUDA_INTEROP_H

//----------------------------------------------------------------------------
// Include
//----------------------------------------------------------------------------

#include <cuda_runtime_api.h>
#include <NVX/nvx.h>

//----------------------------------------------------------------------------
// Framework : Image Extensions
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_framework_image
 * \brief Defines a CUDA array handle to use with image map/unmap operations.
 */
typedef struct _nvx_cuarray_handle_2d_t {
    cudaArray_t array;          /*!< \brief Holds the mapped CUDA Array object. */
    vx_size offset_x;           /*!< \brief Holds the x offset in \p array buffer. */
    vx_size offset_y;           /*!< \brief Holds the y offset in \p array buffer. */
} nvx_cuarray_handle_2d_t;

#endif
