/*
 * Copyright (c) 2016, NVIDIA CORPORATION.  All rights reserved.
 *
 * NVIDIA Corporation and its licensors retain all intellectual property
 * and proprietary rights in and to this software, related documentation
 * and any modifications thereto.  Any use, reproduction, disclosure or
 * distribution of this software and related documentation without an express
 * license agreement from NVIDIA Corporation is strictly prohibited.
 */

/**
 * \file
 * \brief NVIDIA VisionWorks Framework and Primitives Deprecated Extension API
 */

#ifndef NVX_COMPATIBILITY_H
#define NVX_COMPATIBILITY_H

/**
 * \ingroup nvx_deprecated
 * \brief ID of the CUDA device that was selected as current prior to \ref vx_context object creation
 *        (use an <tt>int</tt> parameter).
 * \deprecated Use \ref NVX_CONTEXT_INITIAL_CUDA_DEVICE instead.
 */
#define NVX_CONTEXT_ATTRIBUTE_INITIAL_CUDA_DEVICE_ID NVX_CONTEXT_INITIAL_CUDA_DEVICE

/**
 * \ingroup nvx_deprecated
 * \brief Gets the CUDA stream object associated with the current node.
 * \deprecated Use \ref NVX_NODE_CUDA_STREAM instead.
 */
#define NVX_NODE_ATTRIBUTE_CUDA_STREAM NVX_NODE_CUDA_STREAM

/**
 * \ingroup nvx_deprecated
 * \brief Disables keypoint's error calculation by optical flow and similar primitives.
 * \deprecated Use \ref NVX_DIRECTIVE_DISABLE_KEYPOINT_ERROR instead.
 */
#define NVX_DIRECTIVE_KEYPOINT_ERROR_DISABLE NVX_DIRECTIVE_DISABLE_KEYPOINT_ERROR

/**
 * \ingroup nvx_deprecated
 * \brief Enables keypoint's error calculation by optical flow and similar primitives.
 * \deprecated Use \ref NVX_DIRECTIVE_ENABLE_KEYPOINT_ERROR instead.
 */
#define NVX_DIRECTIVE_KEYPOINT_ERROR_ENABLE NVX_DIRECTIVE_ENABLE_KEYPOINT_ERROR

/**
 * \ingroup nvx_deprecated
 * \brief Uses default behavior for keypoint's error calculation.
 * \deprecated Use \ref NVX_DIRECTIVE_DEFAULT_KEYPOINT_ERROR instead.
 */
#define NVX_DIRECTIVE_KEYPOINT_ERROR_DEFAULT NVX_DIRECTIVE_DEFAULT_KEYPOINT_ERROR

/**
 * \ingroup nvx_deprecated
 * \brief Disables performance measurement.
 * \deprecated Use \ref NVX_DIRECTIVE_DISABLE_PERFORMANCE instead.
 */
#define NVX_DIRECTIVE_PERFORMANCE_DISABLE NVX_DIRECTIVE_DISABLE_PERFORMANCE

/**
 * \ingroup nvx_deprecated
 * \brief Enables performance measurement.
 * \deprecated Use \ref NVX_DIRECTIVE_ENABLE_PERFORMANCE instead.
 */
#define NVX_DIRECTIVE_PERFORMANCE_ENABLE NVX_DIRECTIVE_ENABLE_PERFORMANCE

/**
 * \ingroup nvx_deprecated
 * \brief Use default behavior for performance measurement.
 * \deprecated Use \ref NVX_DIRECTIVE_DEFAULT_PERFORMANCE instead.
 */
#define NVX_DIRECTIVE_PERFORMANCE_DEFAULT NVX_DIRECTIVE_DEFAULT_PERFORMANCE

#endif // NVX_COMPATIBILITY_H
