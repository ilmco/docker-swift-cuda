/*
 * Copyright (c) 2016, NVIDIA CORPORATION.  All rights reserved.
 *
 * NVIDIA Corporation and its licensors retain all intellectual property
 * and proprietary rights in and to this software, related documentation
 * and any modifications thereto.  Any use, reproduction, disclosure or
 * distribution of this software and related documentation without an express
 * license agreement from NVIDIA Corporation is strictly prohibited.
 */

/**
 * \file
 * \brief NVIDIA VisionWorks-CUDA API
 */

#ifndef NVXCU_H
#define NVXCU_H

#include <stdint.h>
#include <cuda_runtime_api.h>
#include <NVX/nvx_api_macros.h>

//----------------------------------------------------------------------------
// Generic types
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_types
 * \brief Defines an error status code.
 */
typedef enum _nvxcu_error_status_e {
    NVXCU_ERROR_CUDA_FAILURE          = -1002,  /**< \brief Indicates internal CUDA failure. */
    NVXCU_ERROR_INVALID_PARAMETERS    = -10,    /**< \brief Indicates that current set of parameters is invalid. */
    NVXCU_ERROR_NOT_SUPPORTED         = -3,     /**< \brief Indicates that current set of parameters is not supported. */
    NVXCU_ERROR_NOT_IMPLEMENTED       = -2,     /**< \brief Indicates that requested operation is not implemented. */
    NVXCU_FAILURE                     = -1,     /**< \brief Indicates a generic error code. */
    NVXCU_SUCCESS                     =  0,     /**< \brief No error. */
} nvxcu_error_status_e;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Defines an array item type enumeration.
 */
typedef enum _nvxcu_array_item_type_e {
    NVXCU_TYPE_CHAR           = 0x001,      /**< \brief A \c char. */
    NVXCU_TYPE_INT8           = 0x002,      /**< \brief A \c int8_t. */
    NVXCU_TYPE_UINT8          = 0x003,      /**< \brief A \c uint8_t. */
    NVXCU_TYPE_INT16          = 0x004,      /**< \brief A \c int16_t. */
    NVXCU_TYPE_UINT16         = 0x005,      /**< \brief A \c uint16_t. */
    NVXCU_TYPE_INT32          = 0x006,      /**< \brief A \c int32_t. */
    NVXCU_TYPE_UINT32         = 0x007,      /**< \brief A \c uint32_t. */
    NVXCU_TYPE_INT64          = 0x008,      /**< \brief A \c int64_t. */
    NVXCU_TYPE_UINT64         = 0x009,      /**< \brief A \c uint64_t. */
    NVXCU_TYPE_FLOAT32        = 0x00A,      /**< \brief A \c float. */
    NVXCU_TYPE_FLOAT64        = 0x00B,      /**< \brief A \c double. */

    NVXCU_TYPE_RECTANGLE      = 0x020,      /**< \brief A \ref nvxcu_rectangle_t. */
    NVXCU_TYPE_KEYPOINT       = 0x021,      /**< \brief A \ref nvxcu_keypoint_t. */
    NVXCU_TYPE_COORDINATES2D  = 0x022,      /**< \brief A \ref nvxcu_coordinates2d_t. */
    NVXCU_TYPE_COORDINATES3D  = 0x023,      /**< \brief A \ref nvxcu_coordinates3d_t. */

    NVXCU_TYPE_POINT2F        = 0x400,      /**< \brief A \ref nvxcu_point2f_t. */
    NVXCU_TYPE_POINT3F        = 0x401,      /**< \brief A \ref nvxcu_point3f_t. */
    NVXCU_TYPE_POINT4F        = 0x402,      /**< \brief A \ref nvxcu_point4f_t. */
    NVXCU_TYPE_KEYPOINTF      = 0x403,      /**< \brief A \ref nvxcu_keypointf_t. */
} nvxcu_array_item_type_e;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Converts a set of four chars into a single `uint32_t` value.
 * \see \ref nvxcu_df_image_e
 */
#define NVXCU_DF_IMAGE(a, b, c, d) ((a) | (b << 8) | (c << 16) | (d << 24))

/**
 * \ingroup nvx_cuda_api_types
 * \brief Calculates the base value for a specific enumeration type.
 * \see \ref nvxcu_enum_e
 */
#define NVXCU_ENUM_BASE(v, id) (((v) << 20) | (id << 12))

/**
 * \ingroup nvx_cuda_api_types
 * \brief Defines an enumeration type code.
 * These values are used to create a final value for specific enumeration constants.
 */
typedef enum _nvxcu_enum_e {
    NVXCU_ENUM_INTERPOLATION  = 0x04,   /**< \brief A \ref nvxcu_interpolation_type_e. */
    NVXCU_ENUM_COLOR_SPACE    = 0x06,   /**< \brief A \ref nvxcu_color_space_e. */
    NVXCU_ENUM_COLOR_RANGE    = 0x07,   /**< \brief A \ref nvxcu_channel_range_e. */
    NVXCU_ENUM_CHANNEL        = 0x09,   /**< \brief A \ref nvxcu_channel_e. */
    NVXCU_ENUM_CONVERT_POLICY = 0x0A,   /**< \brief A \ref nvxcu_convert_policy_e. */
    NVXCU_ENUM_BORDER_MODE    = 0x0C,   /**< \brief A \ref nvxcu_border_mode_e. */
    NVXCU_ENUM_TERM_CRITERIA  = 0x0F,   /**< \brief A \ref nvxcu_termination_criteria_e. */
    NVXCU_ENUM_NORM_TYPE      = 0x10,   /**< \brief A \ref nvxcu_norm_type_e. */
    NVXCU_ENUM_ROUND_POLICY   = 0x12,   /**< \brief A \ref nvxcu_round_policy_e. */
    NVXCU_ENUM_NONLINEAR      = 0x16,   /**< \brief A \ref nvxcu_non_linear_filter_e. */
    NVXCU_ENUM_PATTERN        = 0x17,   /**< \brief A \ref nvxcu_pattern_e. */
} nvxcu_enum_e;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Defines a convertion policy enumeration.
 * \see \ref vx_convert_policy_e
 */
typedef enum _nvxcu_convert_policy_e {
    /** \brief Wrap convertion policy. */
    NVXCU_CONVERT_POLICY_WRAP = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_CONVERT_POLICY) + 0x0,
    /** \brief Saturate conversion policy. */
    NVXCU_CONVERT_POLICY_SATURATE = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_CONVERT_POLICY) + 0x1,
} nvxcu_convert_policy_e;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Defines an image format enumeration.
 * \see \ref vx_df_image_e
 */
typedef enum _nvxcu_df_image_e {
    /**
     * \brief A single 24-bit pixel plane of 3 interleaved 8-bit RGB units.
     */
    NVXCU_DF_IMAGE_RGB    = NVXCU_DF_IMAGE('R','G','B','2'),

    /**
     * \brief A single 32-bit pixel plane of 4 interleaved 8-bit RGBX units.
     */
    NVXCU_DF_IMAGE_RGBX   = NVXCU_DF_IMAGE('R','G','B','A'),

    /**
     * \brief A 2-plane YUV format of Luma (Y) and interleaved UV data at 4:2:0 sampling.
     */
    NVXCU_DF_IMAGE_NV12   = NVXCU_DF_IMAGE('N','V','1','2'),

    /**
     * \brief A 2-lane YUV format of Luma (Y) and interleaved VU data at 4:2:0 sampling.
     */
    NVXCU_DF_IMAGE_NV21   = NVXCU_DF_IMAGE('N','V','2','1'),

    /**
     * \brief A single plane of 32-bit macro pixel of U0, Y0, V0, Y1 bytes.
     */
    NVXCU_DF_IMAGE_UYVY   = NVXCU_DF_IMAGE('U','Y','V','Y'),

    /**
     * \brief A single plane of 32-bit macro pixel of Y0, U0, Y1, V0 bytes.
     */
    NVXCU_DF_IMAGE_YUYV   = NVXCU_DF_IMAGE('Y','U','Y','V'),

    /**
     * \brief A 3 plane of 8-bit 4:2:0 sampled Y, U, V planes.
     */
    NVXCU_DF_IMAGE_IYUV   = NVXCU_DF_IMAGE('I','Y','U','V'),

    /**
     * \brief A 3 plane of 8 bit 4:4:4 sampled Y, U, V planes.
     */
    NVXCU_DF_IMAGE_YUV4   = NVXCU_DF_IMAGE('Y','U','V','4'),

    /**
     * \brief A single plane of 8-bit unsigned integer data.
     */
    NVXCU_DF_IMAGE_U8     = NVXCU_DF_IMAGE('U','0','0','8'),

    /**
     * \brief A single plane of 16-bit unsigned integer data.
     */
    NVXCU_DF_IMAGE_U16    = NVXCU_DF_IMAGE('U','0','1','6'),

    /**
     * \brief A single plane of 16-bit signed integer data.
     */
    NVXCU_DF_IMAGE_S16    = NVXCU_DF_IMAGE('S','0','1','6'),

    /**
     * \brief A single plane of 32-bit unsigned integer data.
     */
    NVXCU_DF_IMAGE_U32    = NVXCU_DF_IMAGE('U','0','3','2'),

    /**
     * \brief A single plane of 32-bit signed integer data.
     */
    NVXCU_DF_IMAGE_S32    = NVXCU_DF_IMAGE('S','0','3','2'),

    /**
     * \brief A single plane of 32-bit float data.
     */
    NVXCU_DF_IMAGE_F32    = NVXCU_DF_IMAGE('F','0','3','2'),

    /**
     * \brief A single plane of float32_t[2] data (for example, motion fields).
     */
    NVXCU_DF_IMAGE_2F32   = NVXCU_DF_IMAGE('2','F','3','2'),

    /**
     * \brief A single plane of int16_t[2] data (for example, motion fields).
     */
    NVXCU_DF_IMAGE_2S16   = NVXCU_DF_IMAGE('2','S','1','6'),

    /**
     * \brief A single 48-bit pixel plane of 3 interleaved 16-bit RGB units.
     */
    NVXCU_DF_IMAGE_RGB16  = NVXCU_DF_IMAGE('S','3','1','6'),
} nvxcu_df_image_e;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Defines a channel enumeration for channel extract operation.
 * \see \ref vx_channel_e
 */
typedef enum _nvxcu_channel_e {
    /** \brief Used to extract the channel #0. */
    NVXCU_CHANNEL_0 = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_CHANNEL) + 0x0,
    /** \brief Used to extract the channel #1. */
    NVXCU_CHANNEL_1 = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_CHANNEL) + 0x1,
    /** \brief Used to extract the channel #2. */
    NVXCU_CHANNEL_2 = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_CHANNEL) + 0x2,
    /** \brief Used to extract the channel #3. */
    NVXCU_CHANNEL_3 = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_CHANNEL) + 0x3,

    /** \brief Used to extract the RED channel. */
    NVXCU_CHANNEL_R = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_CHANNEL) + 0x10,
    /** \brief Used to extract the GREEN channel. */
    NVXCU_CHANNEL_G = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_CHANNEL) + 0x11,
    /** \brief Used to extract the BLUE channel. */
    NVXCU_CHANNEL_B = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_CHANNEL) + 0x12,
    /** \brief Used to extract the ALPHA channel. */
    NVXCU_CHANNEL_A = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_CHANNEL) + 0x13,
    /** \brief Used to extract the LUMA channel. */
    NVXCU_CHANNEL_Y = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_CHANNEL) + 0x14,
    /** \brief Used to extract the Cb/U channel. */
    NVXCU_CHANNEL_U = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_CHANNEL) + 0x15,
    /** \brief Used to extract the Cr/V/Value channel. */
    NVXCU_CHANNEL_V = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_CHANNEL) + 0x16,
} nvxcu_channel_e;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Defines an interpolation type enumeration.
 * \see \ref vx_interpolation_type_e
 */
typedef enum _nvxcu_interpolation_type_e {
    /** \brief Nearest neighbor interpolation. */
    NVXCU_INTERPOLATION_TYPE_NEAREST_NEIGHBOR = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_INTERPOLATION) + 0x0,
    /** \brief Bilinear interpolation. */
    NVXCU_INTERPOLATION_TYPE_BILINEAR = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_INTERPOLATION) + 0x1,
    /** \brief Area interpolation. */
    NVXCU_INTERPOLATION_TYPE_AREA = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_INTERPOLATION) + 0x2,
} nvxcu_interpolation_type_e;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Defines an image color space enumeration.
 * \see \ref vx_color_space_e
 */
typedef enum _nvxcu_color_space_e {
    /** \brief No color space is used. */
    NVXCU_COLOR_SPACE_NONE = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_COLOR_SPACE) + 0x0,
    /** \brief The BT.601 coefficients and SMPTE C primaries. */
    NVXCU_COLOR_SPACE_BT601_525 = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_COLOR_SPACE) + 0x1,
    /** \brief The BT.601 coefficients and BTU primaries. */
    NVXCU_COLOR_SPACE_BT601_625 = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_COLOR_SPACE) + 0x2,
    /** \brief The BT.709 coefficients. */
    NVXCU_COLOR_SPACE_BT709 = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_COLOR_SPACE) + 0x3,
    /** \brief Default color space (BT.709). */
    NVXCU_COLOR_SPACE_DEFAULT = NVXCU_COLOR_SPACE_BT709,
} nvxcu_color_space_e;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Defines an image channel range enumeration.
 * \see \ref vx_channel_range_e
 */
typedef enum _nvxcu_channel_range_e {
    /** \brief Full range of the unit of the channel. */
    NVXCU_CHANNEL_RANGE_FULL = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_COLOR_RANGE) + 0x0,
    /** \brief Restricted range of the unit of the channel based on the space given. */
    NVXCU_CHANNEL_RANGE_RESTRICTED = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_COLOR_RANGE) + 0x1,
} nvxcu_channel_range_e;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Defines a border mode enumeration.
 * \see \ref vx_border_e
 */
typedef enum _nvxcu_border_mode_e {
    /** \brief No defined border mode behavior. */
    NVXCU_BORDER_MODE_UNDEFINED = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_BORDER_MODE) + 0x0,
    /** \brief Out-of-bound pixels are filled with constant value. */
    NVXCU_BORDER_MODE_CONSTANT = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_BORDER_MODE) + 0x1,
    /** \brief Out-of-bound pixels are replicated from the nearest edge pixels. */
    NVXCU_BORDER_MODE_REPLICATE = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_BORDER_MODE) + 0x2,
} nvxcu_border_mode_e;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Defines a termination criteria enumeration.
 * \see \ref vx_termination_criteria_e
 */
typedef enum _nvxcu_termination_criteria_e {
    /** \brief Termination by the number of iterations. */
    NVXCU_TERM_CRITERIA_ITERATIONS = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_TERM_CRITERIA) + 0x0,
    /** \brief Termination by matching the value against epsilon. */
    NVXCU_TERM_CRITERIA_EPSILON = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_TERM_CRITERIA) + 0x1,
    /** \brief A combination of iterations and epsilon. First match causes termination. */
    NVXCU_TERM_CRITERIA_BOTH = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_TERM_CRITERIA) + 0x2,
} nvxcu_termination_criteria_e;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Defines a normalization type enumeration.
 * \see \ref vx_norm_type_e
 */
typedef enum _nvxcu_norm_type_e {
    /** \brief L1 normalization. */
    NVXCU_NORM_L1 = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_NORM_TYPE) + 0x0,
    /** \brief L2 normalization. */
    NVXCU_NORM_L2 = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_NORM_TYPE) + 0x1,
} nvxcu_norm_type_e;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Defines a round policy enumeration.
 * \see \ref vx_round_policy_e
 */
typedef enum _nvxcu_round_policy_e {
    /** \brief Truncates the least significant values. */
    NVXCU_ROUND_POLICY_TO_ZERO = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_ROUND_POLICY) + 0x1,
    /** \brief Rounds to nearest even output value. */
    NVXCU_ROUND_POLICY_TO_NEAREST_EVEN = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_ROUND_POLICY) + 0x2,
} nvxcu_round_policy_e;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Defines modes for flip image operation.
 * \see \ref nvx_flip_mode_e
 */
typedef enum _nvxcu_flip_mode_e {
    NVXCU_FLIP_HORIZONTAL,  /**< \brief Horizontal flipping of the image. */
    NVXCU_FLIP_VERTICAL,    /**< \brief Vertical flipping of the image. */
    NVXCU_FLIP_BOTH         /**< \brief Simultaneous horizontal and vertical flipping of the image. */
} nvxcu_flip_mode_e;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Defines scan line's directions used during cost aggregation step.
 * \see \ref nvx_scanline_e
 */
typedef enum _nvxcu_scanline_e {
    NVXCU_SCANLINE_LEFT_RIGHT            = 1 << 0,  /**< \brief Aggregate cost from left to right horizontally. */
    NVXCU_SCANLINE_TOP_LEFT_BOTTOM_RIGHT = 1 << 1,  /**< \brief Aggregate cost from left to right diagonally starting from the top. */
    NVXCU_SCANLINE_TOP_BOTTOM            = 1 << 2,  /**< \brief Aggregate cost from top to bottom vertically. */
    NVXCU_SCANLINE_TOP_RIGHT_BOTTOM_LEFT = 1 << 3,  /**< \brief Aggregate cost from right to left diagonally starting from the top. */

    NVXCU_SCANLINE_RIGHT_LEFT            = 1 << 4,  /**< \brief Aggregate cost from right to left horizontally. */
    NVXCU_SCANLINE_BOTTOM_RIGHT_TOP_LEFT = 1 << 5,  /**< \brief Aggregate cost from right to left diagonally starting from the bottom. */
    NVXCU_SCANLINE_BOTTOM_TOP            = 1 << 6,  /**< \brief Aggregate cost from bottom to top vertically. */
    NVXCU_SCANLINE_BOTTOM_LEFT_TOP_RIGHT = 1 << 7,  /**< \brief Aggregate cost from left to right diagonally starting from the bottom. */

    /** \brief Aggregate cost from four directions forming a cross. Recommended option for automotive use cases. */
    NVXCU_SCANLINE_CROSS                 = NVXCU_SCANLINE_LEFT_RIGHT |
                                           NVXCU_SCANLINE_RIGHT_LEFT |
                                           NVXCU_SCANLINE_TOP_BOTTOM |
                                           NVXCU_SCANLINE_BOTTOM_TOP,

    NVXCU_SCANLINE_ALL                   = 0xFF     /**< \brief Aggregate cost over all scan lines. */
} nvxcu_scanline_e;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Defines extra flags for SGM algorithm.
 * \see \ref nvx_sgm_flags_e
 */
typedef enum _nvxcu_sgm_flags_e {
    NVXCU_SGM_FILTER_TOP_AREA            = 1 << 0,  /**< \brief Filter cost at top image area with low gradients. */
    NVXCU_SGM_PYRAMIDAL_STEREO           = 1 << 1   /**< \brief Use pyramidal scheme: lower resolution imagery for nearby objects and
                                                    the full resolution for far-away objects. */
} nvxcu_sgm_flags_e;

/**
 * \ingroup nvx_cuda_api_types
 * \brief An enumeration of non-linear filter functions.
 * \see \ref vx_non_linear_filter_e
 */
typedef enum _nvxcu_non_linear_filter_e {
    /*! \brief Nonlinear median filter. */
    NVXCU_NONLINEAR_FILTER_MEDIAN = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_NONLINEAR) + 0x0,
    /*! \brief Nonlinear Erode. */
    NVXCU_NONLINEAR_FILTER_MIN = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_NONLINEAR) + 0x1,
    /*! \brief Nonlinear Dilate. */
    NVXCU_NONLINEAR_FILTER_MAX = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_NONLINEAR) + 0x2,
} nvxcu_non_linear_filter_e;

/**
 * \ingroup nvx_cuda_api_types
 * \brief An enumeration of matrix patterns.
 * \see \ref vx_pattern_e
 */
typedef enum _nvxcu_pattern_e {
    /*! \brief Box pattern matrix */
    NVXCU_PATTERN_BOX = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_PATTERN) + 0x0,
    /*! \brief Cross pattern matrix */
    NVXCU_PATTERN_CROSS = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_PATTERN) + 0x1,
    /*! \brief Matrix with any pattern othern than above. */
    NVXCU_PATTERN_OTHER = NVXCU_ENUM_BASE(0x000, NVXCU_ENUM_PATTERN) + 0x3,
} nvxcu_pattern_e;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Half-scale pyramid.
 */
#define NVXCU_SCALE_PYRAMID_HALF    (0.5f)

/**
 * \ingroup nvx_cuda_api_types
 * \brief ORB scaled pyramid whose scaling factor is \f$ \frac{1}{\root 4 \of {2}} \f$.
 */
#define NVXCU_SCALE_PYRAMID_ORB     (0.8408964f)

/**
 * \ingroup nvx_cuda_api_types
 * \brief Defines the value of a pixel for any image format.
 * Use the field corresponding to the image format.
 */
typedef union _nvxcu_pixel_value_t {
    uint8_t     RGB[3];         /**< \brief \ref NVXCU_DF_IMAGE_RGB format in the R,G,B order. */
    uint16_t    RGB16[3];       /**< \brief \ref NVXCU_DF_IMAGE_RGB16 format in the R,G,B order. */
    uint8_t     RGBX[4];        /**< \brief \ref NVXCU_DF_IMAGE_RGBX format in the R,G,B,X order. */
    uint8_t     YUV[3];         /**< \brief All YUV formats in the Y,U,V order. */
    uint8_t     U8;             /**< \brief \ref NVXCU_DF_IMAGE_U8. */
    uint16_t    U16;            /**< \brief \ref NVXCU_DF_IMAGE_U16. */
    int16_t     S16;            /**< \brief \ref NVXCU_DF_IMAGE_S16. */
    int16_t     S16n[4];        /**< \brief \ref NVXCU_DF_IMAGE_2S16. */
    uint32_t    U32;            /**< \brief \ref NVXCU_DF_IMAGE_U32. */
    int32_t     S32;            /**< \brief \ref NVXCU_DF_IMAGE_S32. */
    float       F32;            /**< \brief \ref NVXCU_DF_IMAGE_F32. */
    float       F32n[4];        /**< \brief \ref NVXCU_DF_IMAGE_2F32. */
    uint8_t     reserved[16];   /**< \brief Reserved for future. */
} nvxcu_pixel_value_t;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Defines a border extrapolation behavior.
 * \see \ref group_borders
 */
typedef struct _nvxcu_border_t {
    nvxcu_border_mode_e mode;               /**< \brief Border mode. */
    nvxcu_pixel_value_t constant_value;     /**< \brief Border constant value for \ref NVXCU_BORDER_MODE_CONSTANT mode. */
} nvxcu_border_t;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Defines a keypoint data structure with integer coordinates.
 */
typedef struct _nvxcu_keypoint_t {
    int32_t x;                  /**< \brief The x coordinate. */
    int32_t y;                  /**< \brief The y coordinate. */
    float strength;             /**< \brief The strength of the keypoint. */
    float scale;                /**< \brief The scale of the keypoint. */
    float orientation;          /**< \brief The orientation of the keypoint. */
    int32_t tracking_status;    /**< \brief The tracking status of the keypoint. */
    float error;                /**< \brief The tracking method specific error. */
} nvxcu_keypoint_t;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Defines a keypoint data structure with float coordinates.
 */
typedef struct _nvxcu_keypointf_t {
    float x;                    /**< \brief The x coordinate. */
    float y;                    /**< \brief The y coordinate. */
    float strength;             /**< \brief The strength of the keypoint. */
    float scale;                /**< \brief The scale of the keypoint. */
    float orientation;          /**< \brief The orientation of the keypoint. */
    int32_t tracking_status;    /**< \brief The tracking status of the keypoint. */
    float error;                /**< \brief The tracking method specific error. */
} nvxcu_keypointf_t;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Defines a rectangle data structure.
 */
typedef struct _nvxcu_rectangle_t {
    uint32_t start_x;   /**< \brief The Start X coordinate. */
    uint32_t start_y;   /**< \brief The Start Y coordinate. */
    uint32_t end_x;     /**< \brief The End X coordinate. */
    uint32_t end_y;     /**< \brief The End Y coordinate. */
} nvxcu_rectangle_t;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Defines a 2D coordinates data structure.
 */
typedef struct _nvxcu_coordinates2d_t {
    uint32_t x; /**< \brief The X coordinate. */
    uint32_t y; /**< \brief The Y coordinate. */
} nvxcu_coordinates2d_t;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Defines a 3D coordinates data structure.
 */
typedef struct _nvxcu_coordinates3d_t {
    uint32_t x; /**< \brief The X coordinate. */
    uint32_t y; /**< \brief The Y coordinate. */
    uint32_t z; /**< \brief The Z coordinate. */
} nvxcu_coordinates3d_t;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Defines a 2D point data structure (float coordinates).
 */
typedef struct _nvxcu_point2f_t {
    float x;    /**< \brief The X coordinate. */
    float y;    /**< \brief The Y coordinate. */
} nvxcu_point2f_t;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Defines a 3D point data structure (float coordinates).
 */
typedef struct _nvxcu_point3f_t {
    float x;    /**< \brief The X coordinate. */
    float y;    /**< \brief The Y coordinate. */
    float z;    /**< \brief The Z coordinate. */
} nvxcu_point3f_t;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Defines a 4D point data structure (float coordinates).
 */
typedef struct _nvxcu_point4f_t {
    float x;    /**< \brief The X coordinate. */
    float y;    /**< \brief The Y coordinate. */
    float z;    /**< \brief The Z coordinate. */
    float w;    /**< \brief The W coordinate. */
} nvxcu_point4f_t;

//----------------------------------------------------------------------------
// Temporary buffer wrapper
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_types
 * \brief Defines the size of temporary buffers.
 *
 * Some primitives internally used temporary buffers.
 * For such cases, the primitive provides a companion function that calculates the required buffer size.
 * This struct determines the size of CUDA device and HOST memory that must be passed to such primitives.
 * If either `dev_buf_size` or `host_buf_size` is 0, it means that no buffer of that type is needed
 * and the corresponding pointer in \ref nvxcu_tmp_buf_t may be set to `NULL`.
 *
 * \see \ref nvxcu_tmp_buf_t
 */
typedef struct _nvxcu_tmp_buf_size_t {
    size_t dev_buf_size;    /**< \brief The size of DEVICE temporary buffer. */
    size_t host_buf_size;   /**< \brief The size of HOST temporary buffer. */
} nvxcu_tmp_buf_size_t;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Defines a pointers to temporary buffers.
 *
 * It must be a plain CUDA device and pinned HOST memory.
 * For example, respectively allocated via `cudaMalloc` and `cudaMallocHost`.
 * The CUDA device memory must be aligned by `cudaDeviceProp::textureAlignment`.
 *
 * \see \ref nvxcu_tmp_buf_size_t
 */
typedef struct _nvxcu_tmp_buf_t {
    void *dev_ptr;      /**< \brief CUDA Device memory buffer. */
    void *host_ptr;     /**< \brief HOST memory buffer. */
} nvxcu_tmp_buf_t;

//----------------------------------------------------------------------------
// Image wrapper
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_types
 * \brief Defines the maximum number of planes in an image object.
 */
#define NVXCU_NB_MAX_PLANES     (4u)

/**
 * \ingroup nvx_cuda_api_types
 * \brief Defines the image object type ID.
 */
typedef enum _nvxcu_image_type_e {
    NVXCU_PITCH_LINEAR_IMAGE,   /**< \brief \ref nvxcu_pitch_linear_image_t object. */
    NVXCU_UNIFORM_IMAGE         /**< \brief \ref nvxcu_uniform_image_t object. */
} nvxcu_image_type_e;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Base structure for image object.
 * \see \ref nvxcu_pitch_linear_image_t
 * \see \ref nvxcu_uniform_image_t
 */
typedef struct _nvxcu_image_t {
    nvxcu_image_type_e image_type;  /**< \brief Object type ID. */
    nvxcu_df_image_e format;        /**< \brief Image format. */
    uint32_t width;                 /**< \brief Image width. */
    uint32_t height;                /**< \brief Image height. */
} nvxcu_image_t;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Image object represented as pitch linear CUDA buffer.
 * \note The CUDA buffer pointer and pitch must be aligned by `cudaDeviceProp::textureAlignment`.
 * \note `base.image_type` must be initialized with \ref NVXCU_PITCH_LINEAR_IMAGE.
 */
typedef struct _nvxcu_pitch_linear_image_t {
    nvxcu_image_t base;             /**< \brief Base image structure. */
    struct {
        void *dev_ptr;              /**< \brief CUDA device pointer. */
        int32_t pitch_in_bytes;     /**< \brief Pitch in bytes between two consequent rows. */
    } planes[NVXCU_NB_MAX_PLANES];  /**< \brief Image planes. */
} nvxcu_pitch_linear_image_t;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Image object filled with uniform value.
 * \note `base.image_type` must be initialized with \ref NVXCU_UNIFORM_IMAGE.
 */
typedef struct _nvxcu_uniform_image_t {
    nvxcu_image_t base;                 /**< \brief Base image structure. */
    nvxcu_pixel_value_t uniform_value;  /**< \brief Uniform value. */
} nvxcu_uniform_image_t;

//----------------------------------------------------------------------------
// Array wrapper
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_types
 * \brief Defines the array object type ID.
 */
typedef enum _nvxcu_array_type_e {
    NVXCU_PLAIN_ARRAY,  /**< \brief \ref nvxcu_plain_array_t object. */
} nvxcu_array_type_e;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Base structure for array object.
 * \see \ref nvxcu_plain_array_t
 */
typedef struct _nvxcu_array_t {
    nvxcu_array_type_e array_type;      /**< \brief Object type ID. */
    nvxcu_array_item_type_e item_type;  /**< \brief Array items type. */
    uint32_t capacity;                  /**< \brief Capacity of the array buffer (in elements). */
} nvxcu_array_t;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Array object represented as plain CUDA device memory.
 * \note `base.array_type` must be initialized with \ref NVXCU_PLAIN_ARRAY.
 */
typedef struct _nvxcu_plain_array_t {
    nvxcu_array_t base;             /**< \brief Base array structure. */
    void *dev_ptr;                  /**< \brief CUDA device pointer to the items. */
    uint32_t *num_items_dev_ptr;    /**< \brief CUDA device pointer to the number of items. */
} nvxcu_plain_array_t;

//----------------------------------------------------------------------------
// Pyramid wrapper
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_types
 * \brief Defines the pyramid object type ID.
 */
typedef enum _nvxcu_pyramid_type_e {
    NVXCU_PITCH_LINEAR_PYRAMID,     /**< \brief \ref nvxcu_pitch_linear_pyramid_t object. */
} nvxcu_pyramid_type_e;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Base structure for pyramid object.
 * \see \ref nvxcu_pitch_linear_pyramid_t
 */
typedef struct _nvxcu_pyramid_t {
    nvxcu_pyramid_type_e pyramid_type;  /**< \brief Object type ID. */
    uint32_t num_levels;                /**< \brief The number of pyramid levels. */
    float scale;                        /**< \brief The pyramid scale factor. */
} nvxcu_pyramid_t;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Pitch linear pyramid object.
 * \note `base.pyramid_type` must be initialized with \ref NVXCU_PITCH_LINEAR_PYRAMID.
 */
typedef struct _nvxcu_pitch_linear_pyramid_t {
    nvxcu_pyramid_t base;                   /**< \brief Base pyramid structure. */
    nvxcu_pitch_linear_image_t *levels;     /**< \brief The pyramid levels. */
} nvxcu_pitch_linear_pyramid_t;

//----------------------------------------------------------------------------
// Execution target
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_types
 * \brief Defines the execution target object type ID.
 */
typedef enum _nvxcu_exec_target_type_e {
    NVXCU_STREAM_EXEC_TARGET,   /**< \brief \ref nvxcu_stream_exec_target_t object. */
} nvxcu_exec_target_type_e;

/**
 * \ingroup nvx_cuda_api_types
 * \brief Base structure for execution target.
 * \see \ref nvxcu_stream_exec_target_t
 */
typedef struct _nvxcu_exec_target_t {
    nvxcu_exec_target_type_e exec_target_type;  /**< \brief Object type ID. */
} nvxcu_exec_target_t;

/**
 * \ingroup nvx_cuda_api_types
 * \brief CUDA stream execution target.
 * \note `base.exec_target_type` must be initialized with \ref NVXCU_STREAM_EXEC_TARGET.
 */
typedef struct _nvxcu_stream_exec_target_t {
    nvxcu_exec_target_t base;           /**< \brief Base execution target structure. */
    cudaStream_t stream;                /**< \brief CUDA stream to launch primitive in. */
    struct cudaDeviceProp dev_prop;     /**< \brief CUDA device properties for current active device. */
} nvxcu_stream_exec_target_t;

//----------------------------------------------------------------------------
// ChannelExtract
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \details This kernel extracts a single channel image <tt>\ref NVXCU_DF_IMAGE_U8</tt> from
 * a multi-channel image format defined by <tt>\ref  nvxcu_df_image_e</tt>.
 *
 * \param [in]  input           Specifies the input image.
 *                                  It must have a multi-channel format defined by \ref nvxcu_df_image_e.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  channel         Specifies the channel to extract.
 * \param [out] output          Specifies the output image.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuChannelExtract(const nvxcu_image_t* input,
                                                   nvxcu_channel_e channel,
                                                   const nvxcu_image_t* output,
                                                   const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// ChannelCombine
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \details This kernel combines multiple planes, each with format <tt>\ref NVXCU_DF_IMAGE_U8</tt>, into
 * a single multi-channel image format defined by <tt>\ref nvxcu_df_image_e</tt>.
 *
 * \param [in]  plane0          Specifies the input plane for channel #0.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  plane1          Specifies the input plane for channel #1.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  plane2          Specifies the input plane for channel #2.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  plane3          [optional] Specifies the input plane for channel #3.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] output          Specifies the output image.
 *                                  It must have a multi-channel format defined by \ref nvxcu_df_image_e.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuChannelCombine(const nvxcu_image_t* plane0,
                                                   const nvxcu_image_t* plane1,
                                                   const nvxcu_image_t* plane2,
                                                   const nvxcu_image_t* plane3,
                                                   const nvxcu_image_t* output,
                                                   const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// AbsDiff
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \details This kernel calculates the pixel by pixel absolute difference between two images.
 * The absolute difference at pixel location (y,x) is defined by
 *
 * out(y, x) = abs(in1(y, x) - in2(y, x)).
 *
 * If both inputs are type S16, the result is conceptually calculated as follows:
 *
 * uint16 uresult = (uint16) abs((int32) (a) - (int32) (b));
 *
 * int16 result = (uresult > 32767) ? 32767 : ((int16) uresult);
 *
 * \param [in]  in1             Specifies the first input image.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 or \ref NVXCU_DF_IMAGE_S16 format.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  in2             Specifies the second input image.
 *                                  It must have the same size and format as \p in1.
 *                                  \ref nvxcu_pitch_linear_image_t and \ref nvxcu_uniform_image_t are supported.
 * \param [out] out             Specifies the output image.
 *                                  It must have the same size and format as \p in1.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuAbsDiff(const nvxcu_image_t* in1,
                                            const nvxcu_image_t* in2,
                                            const nvxcu_image_t* out,
                                            const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// Phase
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \details This kernel computes the gradient orientations. It takes two gradients of x and y
 * directions in <tt>\ref NVXCU_DF_IMAGE_S16</tt> format, computes the gradient orientation
 * for each pixel, and stores the result in a <tt>\ref NVXCU_DF_IMAGE_U8</tt> image.
 \f[
 orientation = \arctan{\frac{grad_y(x,y)}{grad_x(x,y)}}
 \f]
 * where orientation is calucalated in the range of \f$ [0 \  {2}\pi) \f$, and then mapped to the
 * range of \f$ [0 \  255] \f$.

 *
 * \param [in]  grad_x          Specifies the input x image.
 *                                  It must have \ref NVXCU_DF_IMAGE_S16 format.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  grad_y          Specifies the input y image.
 *                                  It must have the same size and format as \p grad_x.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] orientation     Specifies the output phase image.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                  It must have the same size as \p grad_x.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuPhase(const nvxcu_image_t* grad_x,
                                          const nvxcu_image_t* grad_y,
                                          const nvxcu_image_t* orientation,
                                          const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// Magnitude
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \details This kernel computes the gradient magnitudes. It takes two gradients of x and y
 * directions in <tt>\ref NVXCU_DF_IMAGE_S16</tt> format and computes the magnitude
 * <tt>\ref NVXCU_DF_IMAGE_S16</tt> as:
 \f[
 mag(x,y) = \sqrt{grad_x(x,y)^2 + grad_y(x,y)^2}
 \f]
 The description of overflow is conceptually given by:

 uint16 m = uint16( sqrt( double( uint32( int32(x) * int32(x) ) + uint32( int32(y) * int32(y) ) ) ) + 0.5);

 int16 mag = m > 32767 ? 32767 : m;
 *
 * \param [in]  grad_x          Specifies the input x image.
 *                                  It must have \ref NVXCU_DF_IMAGE_S16 format.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  grad_y          Specifies the input y image.
 *                                  It must have the same size and format as \p grad_x.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] mag             Specifies the output magnitude image.
 *                                  It must have \ref NVXCU_DF_IMAGE_S16 format.
 *                                  It must have the same size as \p grad_x.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuMagnitude(const nvxcu_image_t* grad_x,
                                              const nvxcu_image_t* grad_y,
                                              const nvxcu_image_t* mag,
                                              const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// Threshold
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \details Thresholds an input image and produces a binary output image.
 * The output is determined by:
 * \f[
 * ouput(x,y) = \begin{cases}
 * true\ value & \text{if } input(x,y) > threshold \cr
 * false\ value & \text{otherwise }
 * \end{cases}
 * \f]
 *
 * \param [in]  input           Specifies the input image.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  thresh_value    Specifies the threshold value.
 * \param [in]  true_value      Specifies the "TRUE" value.
 * \param [in]  false_value     Specifies the "FALSE" value.
 * \param [out] output          Specifies the output image.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                  It must have the same size as \p input.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuThresholdBinary(const nvxcu_image_t* input,
                                                    nvxcu_pixel_value_t thresh_value,
                                                    nvxcu_pixel_value_t true_value,
                                                    nvxcu_pixel_value_t false_value,
                                                    const nvxcu_image_t* output,
                                                    const nvxcu_exec_target_t* exec_target);

/**
 * \ingroup nvx_cuda_api_primitives
 * \details Thresholds an input image and produces a binary output image.
 * The output is determined by:
 * \f[
 * output(x,y) = \begin{cases}
 * false\ value & \text{if } input(x,y) > upper \cr
 * false\ value  & \text{if } input(x,y) < lower \cr
 * true\ value  & \text{otherwise }
 * \end{cases}
 * \f]
 *
 * \param [in]  input                   Specifies the input image.
 *                                          It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                          Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  thresh_lower_value      Specifies the lower threshold value.
 * \param [in]  thresh_upper_value      Specifies the upper threshold value.
 * \param [in]  true_value              Specifies the "TRUE" value.
 * \param [in]  false_value             Specifies the "FALSE" value.
 * \param [out] output                  Specifies the output image.
 *                                          It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                          It must have the same size as \p input.
 *                                          Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  exec_target             Specifies the execution target.
 *                                          Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuThresholdRange(const nvxcu_image_t* input,
                                                   nvxcu_pixel_value_t thresh_lower_value,
                                                   nvxcu_pixel_value_t thresh_upper_value,
                                                   nvxcu_pixel_value_t true_value,
                                                   nvxcu_pixel_value_t false_value,
                                                   const nvxcu_image_t* output,
                                                   const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// AccumulateImage
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \details Accumulates an input image into output image, computed by:
 * \f[
 * accum(x,y) = accum(x,y) + input(x,y)
 * \f]
 * The overflow policy is <tt>\ref NVXCU_CONVERT_POLICY_SATURATE</tt>.
 * \see \ref group_vision_function_accumulate
 *
 * \param [in]     input            Specifies the input image.
 *                                      It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                      Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in,out] accum            Specifies the accumulation image.
 *                                      It must have \ref NVXCU_DF_IMAGE_S16 format.
 *                                      It must have the same size as \p input.
 *                                      Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]     exec_target      Specifies the execution target.
 *                                      Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuAccumulateImage(const nvxcu_image_t* input,
                                                    const nvxcu_image_t* accum,
                                                    const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// AccumulateWeighted
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \details Accumulates a weighted value from an input image to an output image, computed by:
 * \f[
 * accum(x,y) = (1 - \alpha)*accum(x,y) + \alpha*input(x,y)
 * \f]
 * where \f$ 0 \le \alpha \le 1 \f$.
 * Rounding is conceptually defined as:
 * \f[
 * output(x,y)= uint8( (1 - \alpha) * float32( int32( output(x,y) ) ) + \alpha * float32( int32( input(x,y) ) ) )
 * \f]
 *
 * \param [in]     input            Specifies the input image.
 *                                      It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                      Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]     alpha            Specifies the weight scalar.
 * \param [in,out] accum            Specifies the accumulation image.
 *                                      It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                      It must have the same size as \p input.
 *                                      Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]     exec_target      Specifies the execution target.
 *                                      Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuAccumulateWeighted(const nvxcu_image_t* input,
                                                       float alpha,
                                                       const nvxcu_image_t* accum,
                                                       const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// AccumulateSquare
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \details Accumulates a squared value from an input image to an output image, computed by:
 * \f[
 * accum(x,y) =  (uint16) accum(x,y) + (((uint16)(input(x,y)^2)) >> (shift))
 * \f]
 * where \f$ 0 \le shift \le 15 \f$.
 * The overflow policy is <tt>\ref NVXCU_CONVERT_POLICY_SATURATE</tt>.
 *
 * \param [in]     input            Specifies the input image.
 *                                      It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                      Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]     shift            Specifies the shift scalar.
 * \param [in,out] accum            Specifies the accumulation image.
 *                                      It must have \ref NVXCU_DF_IMAGE_S16 format.
 *                                      It must have the same size as \p input.
 *                                      Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]     exec_target      Specifies the execution target.
 *                                      Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuAccumulateSquare(const nvxcu_image_t* input,
                                                     uint32_t shift,
                                                     const nvxcu_image_t* accum,
                                                     const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// And
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \details Performs a `bitwise AND` operation on pixels between two <tt>\ref NVXCU_DF_IMAGE_U8</tt> images.
 * For each pixel, the `bitwise AND` is computed by:
 * \f[
 * out(x,y) = in1(x,y) \wedge in2(x,y)
 * \f]
 * The equavalent C code is:
 * \code
 * out(x,y) = in1(x,y) & in2(x,y)
 * \endcode
 *
 * \param [in]  in1             Specifies the first input image.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  in2             Specifies the second input image.
 *                                  It must have the same size and format as \p in1.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] out             Specifies the output image.
 *                                  It must have the same size and format as \p in1.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuBitwiseAnd(const nvxcu_image_t* in1,
                                               const nvxcu_image_t* in2,
                                               const nvxcu_image_t* out,
                                               const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// Or
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \details Performs a `bitwise OR` operation on pixels between two <tt>\ref NVXCU_DF_IMAGE_U8</tt> images.
 * For each pixel, the `bitwise OR` is computed by:
 * \f[
 * out(x,y) = in1(x,y) \vee in2(x,y)
 * \f]
 * The equavalent C code is:
 * \code
 * out(x,y) = in1(x,y) | in2(x,y)
 * \endcode
 *
 * \param [in]  in1             Specifies the first input image.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  in2             Specifies the second input image.
 *                                  It must have the same size and format as \p in1.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] out             Specifies the output image.
 *                                  It must have the same size and format as \p in1.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuBitwiseOr(const nvxcu_image_t* in1,
                                              const nvxcu_image_t* in2,
                                              const nvxcu_image_t* out,
                                              const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// Xor
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \details Performs a `bitwise XOR` operation on pixels between two <tt>\ref NVXCU_DF_IMAGE_U8</tt> images.
 * For each pixel, the `bitwise XOR` is computed by:
 * \f[
 * out(x,y) = in1(x,y) \oplus in2(x,y)
 * \f]
 * The equavalent C code is:
 * \code
 * out(x,y) = in1(x,y) ^ in2(x,y)
 * \endcode
 *
 * \param [in]  in1             Specifies the first input image.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  in2             Specifies the second input image.
 *                                  It must have the same size and format as \p in1.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] out             Specifies the output image.
 *                                  It must have the same size and format as \p in1.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuBitwiseXor(const nvxcu_image_t* in1,
                                               const nvxcu_image_t* in2,
                                               const nvxcu_image_t* out,
                                               const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// Not
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \details Performs a `bitwise NOT` operation on a <tt>\ref NVXCU_DF_IMAGE_U8</tt> input image.
 * For each pixel, the `bitwise NOT` is computed by:
 * \f[
 * output(x,y) = \overline{input(x,y)}
 * \f]
 * The equavalent C code is:
 * \code
 * output(x,y) = ~input(x,y)
 * \endcode
 *
 * \param [in]  input           Specifies the input image.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] output          Specifies the output image.
 *                                  It must have the same size and format as \p input.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuBitwiseNot(const nvxcu_image_t* input,
                                               const nvxcu_image_t* output,
                                               const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// Add
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Performs addition between two images.
 * \details Arithmetic addition is operated on pixels in two
 * <tt>\ref NVXCU_DF_IMAGE_U8</tt> or <tt>\ref NVXCU_DF_IMAGE_S16</tt> images. The output image can
 * be <tt>\ref NVXCU_DF_IMAGE_U8</tt> only if both input images are <tt>\ref NVXCU_DF_IMAGE_U8</tt> and
 * the output image is explicitly set to <tt>\ref NVXCU_DF_IMAGE_U8</tt>. It is otherwise
 * <tt>\ref NVXCU_DF_IMAGE_S16</tt>. If one of the input images is of type <tt>\ref NVXCU_DF_IMAGE_S16</tt>,
 * all values are converted to <tt>\ref NVXCU_DF_IMAGE_S16</tt>. The overflow is
 * controlled by a conversion policy parameter. Addition is computed on pixels in the two input
 * images as:
 * \f[
 * out(x,y) = in1(x,y) + in2(x,y)
 * \f]
 *
 * \param [in]  in1             Specifies the first input image.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 or \ref NVXCU_DF_IMAGE_S16 format.
 *                                  \ref nvxcu_pitch_linear_image_t and \ref nvxcu_uniform_image_t are supported.
 * \param [in]  in2             Specifies the second input image.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 or \ref NVXCU_DF_IMAGE_S16 format.
 *                                  It must have the same size as \p in1.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  policy          Specifies the conversion policy.
 * \param [out] out             Specifies the output image.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 or \ref NVXCU_DF_IMAGE_S16 format.
 *                                  It must have the same size as \p in1.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuAdd(const nvxcu_image_t* in1,
                                        const nvxcu_image_t* in2,
                                        nvxcu_convert_policy_e policy,
                                        const nvxcu_image_t* out,
                                        const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// Subtract
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Performs subtraction between two images.
 * \details Arithmetic subtraction is operated on pixels in two <tt>\ref NVXCU_DF_IMAGE_U8</tt>
 or two <tt>\ref NVXCU_DF_IMAGE_S16</tt> images. The output image can be
 <tt>\ref NVXCU_DF_IMAGE_U8</tt> only if both source images are <tt>\ref NVXCU_DF_IMAGE_U8</tt>
 and the output image is explicitly set to <tt>\ref NVXCU_DF_IMAGE_U8</tt>. It is otherwise
 <tt>\ref NVXCU_DF_IMAGE_S16</tt>. If one of the input images is of type
 <tt>\ref NVXCU_DF_IMAGE_S16</tt>, all values are converted to <tt>\ref NVXCU_DF_IMAGE_S16</tt>.
 The overflow handling is controlled by a \e policy input parameter. Subtraction is computed on
 pixels in the two input images as:
 \f[
 out(x,y) = in1(x,y) - in2(x,y)
 \f]
 *
 * \param [in]  in1             Specifies the input minuend image.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 or \ref NVXCU_DF_IMAGE_S16 format.
 *                                  \ref nvxcu_pitch_linear_image_t and \ref nvxcu_uniform_image_t are supported.
 * \param [in]  in2             Specifies the input subtrahend image.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 or \ref NVXCU_DF_IMAGE_S16 format.
 *                                  It must have the same size as \p in1.
 *                                  \ref nvxcu_pitch_linear_image_t and \ref nvxcu_uniform_image_t are supported.
 * \param [in]  policy          Specifies the conversion policy.
 * \param [out] out             Specifies the output image.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 or \ref NVXCU_DF_IMAGE_S16 format.
 *                                  It must have the same size as \p in1.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuSubtract(const nvxcu_image_t* in1,
                                             const nvxcu_image_t* in2,
                                             nvxcu_convert_policy_e policy,
                                             const nvxcu_image_t* out,
                                             const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// Multiply
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Computes element-wise multiplication between two images and a scalar value.
 * \details Pixel-wise multiplication is computed between two
 * <tt>\ref NVXCU_DF_IMAGE_U8</tt> or <tt>\ref NVXCU_DF_IMAGE_S16</tt> images and a scalar
 * floating-point number \e scale. The output image can be <tt>\ref NVXCU_DF_IMAGE_U8</tt>
 * only if both input images are <tt>\ref NVXCU_DF_IMAGE_U8</tt> and the output image is
 * explicitly set to <tt>\ref NVXCU_DF_IMAGE_U8</tt>. It is otherwise
 * <tt>\ref NVXCU_DF_IMAGE_S16</tt>. If one of the input images is of type
 * <tt>\ref NVXCU_DF_IMAGE_S16</tt>, all values are converted to <tt>\ref NVXCU_DF_IMAGE_S16</tt>.
 *
 * The rounding is controlled by a \e rounding_policy input
 * parameter. The rounding policy <tt>\ref NVXCU_ROUND_POLICY_TO_ZERO</tt> for this function is defined as:
 * \f[
 * out(x,y,scale) = round\_to\_zero(((int32_t)in1(x,y)) * ((int32_t)in2(x,y)) * (double)scale)
 * \f]
 * The rounding policy <tt>\ref NVXCU_ROUND_POLICY_TO_NEAREST_EVEN</tt> for this function is defined as:
 * \f[
 * out(x,y,scale) = round\_to\_nearest\_even(((int32_t)in1(x,y)) * ((int32_t)in2(x,y)) * (double)scale)
 * \f]
 *
 * The overflow handling is controlled by a \e overflow_policy input
 * parameter. For each pixel value in the two input images:
 * \f[
 * out(x,y) = in_1(x,y) in_2(x,y) scale
 * \f]
 *
 * \param [in]  in1                 Specifies the first input image.
 *                                      It must have \ref NVXCU_DF_IMAGE_U8 or \ref NVXCU_DF_IMAGE_S16 or \ref NVXCU_DF_IMAGE_F32 format.
 *                                      Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  in2                 Specifies the second input image.
 *                                      It must have \ref NVXCU_DF_IMAGE_U8 or \ref NVXCU_DF_IMAGE_S16 or \ref NVXCU_DF_IMAGE_F32 format.
 *                                      It must have the same size as \p in1.
 *                                      \ref nvxcu_pitch_linear_image_t and \ref nvxcu_uniform_image_t are supported.
 * \param [in]  scale               Specifies a non-negative scalar multiplied to each product before overflow handling.
 * \param [in]  overflow_policy     Specifies an overflow policy.
 * \param [in]  rounding_policy     Specifies a rounding policy.
 * \param [out] out                 Specifies the output image.
 *                                      It must have \ref NVXCU_DF_IMAGE_U8 or \ref NVXCU_DF_IMAGE_S16 or \ref NVXCU_DF_IMAGE_F32 format.
 *                                      It must have the same size as \p in1.
 *                                      Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  exec_target         Specifies the execution target.
 *                                      Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuMultiply(const nvxcu_image_t* in1,
                                             const nvxcu_image_t* in2,
                                             float scale,
                                             nvxcu_convert_policy_e overflow_policy,
                                             nvxcu_round_policy_e rounding_policy,
                                             const nvxcu_image_t* out,
                                             const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// ConvertDepth
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Converts image bit depth.
 * \details This kernel takes an input image and converts its bit-depth to
 * another bit-depth as shown in the table below. The columns show the
 * output types and the rows show the input types. Logical shift (zero padding) is used
 * for unsigned input pixel values and arithmetic shift is used for signed input pixel values.
 * The API version
 * on which conversion is supported is also listed. (An \e N denotes an invalid operation.)
 *
 * | I/O |  U8 | U16 | S16 | U32 | S32 |
 * |:----|:---:|:---:|:---:|:---:|:---:|
 * | U8  |  N  |     | 1.0 |     |     |
 * | U16 |     |  N  |  N  |     |     |
 * | S16 | 1.0 |  N  |  N  |     |     |
 * | U32 |     |     |     |  N  |  N  |
 * | S32 |     |     |     |  N  |  N  |
 *
 * <H3> Conversion Type </H3>
 * The table below identifies the conversion types for the allowed bith depth conversions.
 *
 *
 * | From| To  |Conversion Type |
 * |:----|:---:|:--------------:|
 * | U8  | S16 | Up-conversion  |
 * | S16 | U8  | Down-conversion|
 *
 *
 * <H3> Convert Policy </H3>
 * Down-conversions with <tt>\ref NVXCU_CONVERT_POLICY_WRAP</tt> \e policy is defined by:
 * \code
 * output(x,y) = ((uint8)(input(x,y) >> shift));
 * \endcode
 * Down-conversions with <tt>\ref NVXCU_CONVERT_POLICY_SATURATE</tt> \e policy is defined by:
 * \code
 * int16 value = input(x,y) >> shift;
 * value = value < 0 ? 0 : value;
 * value = value > 255 ? 255 : value;
 * output(x,y) = (uint8)value;
 * \endcode
 * Up-conversions ignore the \e policy and perform this operation:
 * \code
 * output(x,y) = ((int16)input(x,y)) << shift;
 * \endcode
 * The range of \e shift is defined as below, all other values produce undefined result.
 * \code
 * 0 <= shift < 8;
 * \endcode
 *
 * \param [in]  input           Specifies the input image.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] output          Specifies the output image.
 *                                  It must have the same size as \p input.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  policy          Specifies the conversion policy.
 * \param [in]  shift           Specifies the shift value.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuConvertDepth(const nvxcu_image_t* input,
                                                 const nvxcu_image_t* output,
                                                 nvxcu_convert_policy_e policy,
                                                 int32_t shift,
                                                 const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// ColorConvert
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Converts image from one color format to another.
 * \details This kernel converts a <tt>\ref nvxcu_image_t</tt> image from one designated
 * format to another. The image format is defined in <tt>\ref nvxcu_df_image_e</tt> and the
 * valid combinations are listed in the below table, where the columns are output types and
 * the rows are input types.
 *
 * | I/O  | RGB  | RGBX | NV12 | NV21 | UYVY | YUYV | IYUV | YUV4 |
 * |:-----|:----:|:----:|:----:|:----:|:----:|:----:|:----:|:----:|
 * | RGB  |      |  Y   |  Y   |      |      |      |  Y   |  Y   |
 * | RGBX |  Y   |      |  Y   |      |      |      |  Y   |  Y   |
 * | NV12 |  Y   |  Y   |      |      |      |      |  Y   |  Y   |
 * | NV21 |  Y   |  Y   |      |      |      |      |  Y   |  Y   |
 * | UYVY |  Y   |  Y   |  Y   |      |      |      |  Y   |      |
 * | YUYV |  Y   |  Y   |  Y   |      |      |      |  Y   |      |
 * | IYUV |  Y   |  Y   |  Y   |      |      |      |      |  Y   |
 * | YUV4 |      |      |      |      |      |      |      |      |
 *
 * The <tt>\ref nvxcu_df_image_e</tt> encoding, held in the <tt>\ref nvxcu_image_t</tt>,
 * describes the data layout.
 * The interpretation of the colors is determined by <tt>\ref nvxcu_color_space_e</tt> and
 * <tt>\ref nvxcu_channel_range_e</tt> input parameters.
 *
 * If the channel range is defined as <tt>\ref NVXCU_CHANNEL_RANGE_FULL</tt>,
 * the conversion between the real number and integer quantizations of
 * color channels is defined for red, green, blue, and Y as:

 * \f[
 *  value_{real} = \frac{value_{integer}}{256.0}
 * \f]
 * \f[
 *  value_{integer} = max(0, min(255, floor(value_{real} * 256.0)))
 * \f]
 *
 *  For the U and V channels, the conversion between real number and integer quantizations is:
 *
 * \f[
 *  value_{real} = \frac{(value_{integer} - 128.0)}{256.0}
 * \f]
 * \f[
 *  value_{integer} = max(0, min(255, floor((value_{real} * 256.0) + 128)))
 * \f]

 * If the channel range is defined as <tt>\ref NVXCU_CHANNEL_RANGE_RESTRICTED</tt>,
 * the conversion between the integer quantizations of color channels and
 * the continuous representations is defined for red, green, blue, and Y as:

 * \f[
 *  value_{real} = \frac{(value_{integer} - 16.0)}{219.0}
 * \f]
 * \f[
 *  value_{integer} = max(0, min(255, floor((value_{real} * 219.0) + 16.5)))
 * \f]

 * For the U and V channels, the conversion between real number and
 * integer quantizations is:

 * \f[
 *  value_{real} = \frac{(value_{integer} - 128.0)}{224.0}
 * \f]
 * \f[
 *  value_{integer} = max(0, min(255, floor((value_{real} * 224.0) + 128.5)))
 * \f]

 * The conversions between nonlinear-intensity Y&apos;PbPr and R&apos;G&apos;B&apos; real numbers are:

 * \f[
 * R\prime = Y\prime + 2(1-K_r)Pr
 * \f]
 * \f[
 * B\prime = Y\prime + 2(1-K_b)Pb
 * \f]
 * \f[
 * G\prime = Y\prime - \frac{2(K_r(1-K_r)Pr + K_b(1-K_b)Pb)}{1-K_r-K_b}
 * \f]
 *
 * \f[
 * Y\prime = (K_r * R\prime) + (K_b * B\prime) + (1-K_r-K_b)G\prime
 * \f]
 * \f[
 * Pb = \frac{B\prime}{2} - \frac{(R\prime * K_r) + G\prime(1-K_r-K_b)}{2(1-K_b)}
 * \f]
 * \f[
 * Pr = \frac{R\prime}{2} - \frac{(B\prime * K_b) + G\prime(1-K_r-K_b)}{2(1-K_r)}
 * \f]

 * The means of reconstructing Pb and Pr values from chroma-downsampled formats
 * is implementation-defined.
 *
 * In <tt>\ref NVXCU_COLOR_SPACE_BT601_525</tt> or <tt>\ref NVXCU_COLOR_SPACE_BT601_625</tt>:

 * \f[
 * K_r = 0.299
 * \f]
 * \f[
 * K_b = 0.114
 * \f]
 *
 *  In <tt>\ref NVXCU_COLOR_SPACE_BT709</tt>:
 *
 * \f[
 * K_r = 0.2126
 * \f]
 * \f[
 * K_b = 0.0722
 * \f]

 * In all cases, for the purposes of conversion, these colour representations
 * are interpreted as nonlinear in intensity, as defined by the BT.601, BT.709,
 * and sRGB specifications. That is, the encoded colour channels are nonlinear
 * R&apos;, G&apos; and B&apos;, Y&apos;, Pb, and Pr.
 *
 * Each channel of the R&apos;G&apos;B&apos; representation can be converted to and from a
 * linear-intensity RGB channel by these formulae:

 * \f[
 * value_{nonlinear} = 1.099 * {value_{linear}}^{0.45} - 0.099 \;\;\; for \;\;\; 1 \geq value_{linear} \geq 0.018
 * \f]
 * \f[
 * value_{nonlinear} = 4.500 * value_{linear} \;\;\; for \;\;\; 0.018 > value_{linear} \geq 0
 * \f]
 *
 * \f[
 * value_{linear} = {\left(\frac{value_{nonlinear} + 0.099}{1.099}\right)}^\frac{1}{0.45} \;\;\; for \;\;\; 1 \geq value_{nonlinear} > 0.081
 * \f]
 * \f[
 * value_{linear} = \frac{value_{nonlinear}}{4.5} \;\;\; for \;\;\; 0.081 \geq value_{nonlinear} \geq 0
 * \f]
 *
 *  As the different color spaces have different RGB primaries, a conversion
 *  between them must transform the color coordinates into the new RGB space.
 *  Working with linear RGB values, the conversion formulae are:
 *
 * \f[
 * R_{BT601\_525} = R_{BT601\_625} * 1.112302 + G_{BT601\_625} * -0.102441 + B_{BT601\_625} * -0.009860
 * \f]
 * \f[
 * G_{BT601\_525} = R_{BT601\_625} * -0.020497 + G_{BT601\_625} * 1.037030 + B_{BT601\_625} * -0.016533
 * \f]
 * \f[
 * B_{BT601\_525} = R_{BT601\_625} * 0.001704 + G_{BT601\_625} * 0.016063 + B_{BT601\_625} * 0.982233
 * \f]
 *
 * \f[
 * R_{BT601\_525} = R_{BT709} * 1.065379 + G_{BT709} * -0.055401 + B_{BT709} * -0.009978
 * \f]
 * \f[
 * G_{BT601\_525} = R_{BT709} * -0.019633 + G_{BT709} * 1.036363 + B_{BT709} * -0.016731
 * \f]
 * \f[
 * B_{BT601\_525} = R_{BT709} * 0.001632 + G_{BT709} * 0.004412 + B_{BT709} * 0.993956
 * \f]
 *
 * \f[
 * R_{BT601\_625} = R_{BT601\_525} * 0.900657 + G_{BT601\_525} * 0.088807 + B_{BT601\_525} * 0.010536
 * \f]
 * \f[
 * G_{BT601\_625} = R_{BT601\_525} * 0.017772 + G_{BT601\_525} * 0.965793 + B_{BT601\_525} * 0.016435
 * \f]
 * \f[
 * B_{BT601\_625} = R_{BT601\_525} * -0.001853 + G_{BT601\_525} * -0.015948 + B_{BT601\_525} * 1.017801
 * \f]
 *
 * \f[
 * R_{BT601\_625} = R_{BT709} * 0.957815 + G_{BT709} * 0.042185
 * \f]
 * \f[
 * G_{BT601\_625} = G_{BT709}
 * \f]
 * \f[
 * B_{BT601\_625} = G_{BT709} * -0.011934 + B_{BT709} * 1.011934
 * \f]
 *
 * \f[
 * R_{BT709} = R_{BT601\_525} * 0.939542 + G_{BT601\_525} * 0.050181 + B_{BT601\_525} * 0.010277
 * \f]
 * \f[
 * G_{BT709} = R_{BT601\_525} * 0.017772 + G_{BT601\_525} * 0.965793 + B_{BT601\_525} * 0.016435
 * \f]
 * \f[
 * B_{BT709} = R_{BT601\_525} * -0.001622 + G_{BT601\_525} * -0.004370 + B_{BT601\_525} * 1.005991
 * \f]
 *
 * \f[
 * R_{BT709} = R_{BT601\_625} * 1.044043 + G_{BT601\_625} * -0.044043
 * \f]
 * \f[
 * G_{BT709} = G_{BT601\_625}
 * \f]
 * \f[
 * B_{BT709} = G_{BT601\_625} * 0.011793 + B_{BT601\_625} * 0.988207
 * \f]

 * A conversion between one YUV color space and another may therefore consist of the following transformations:

 * -# Convert quantized Y&apos;CbCr (&ldquo;YUV&rdquo;) to continuous, nonlinear Y&apos;PbPr.
 * -# Convert continuous Y&apos;PbPr to continuous, nonlinear R&apos;G&apos;B&apos;.
 * -# Convert nonlinear R&apos;G&apos;B&apos; to linear-intensity RGB (gamma-correction).
 * -# Convert linear RGB from the first color space to linear RGB in the second color space.
 * -# Convert linear RGB to nonlinear R&apos;G&apos;B&apos; (gamma-conversion).
 * -# Convert nonlinear R&apos;G&apos;B&apos; to Y&apos;PbPr.
 * -# Convert continuous Y&apos;PbPr to quantized Y&apos;CbCr (&ldquo;YUV&rdquo;).

 * The above formulae and constants are defined in the ITU
 * <a href="https://www.itu.int/rec/R-REC-BT.601/">BT.601</a>
 * and <a href="http://www.itu.int/rec/R-REC-BT.709/">BT.709</a>
 * specifications. The formulae for converting between RGB primaries
 * can be derived from the specified primary chromaticity values and
 * the specified white point by solving for the relative intensity
 * of the primaries.

 * In addition to standard formats for the Color Convert primitive,
 * The following conversions are also supported.
 *
 * - `U8` -> `RGB` (from grayscale)
 * - `U8` -> `RGBX` (from grayscale)
 * - `RGB` -> `U8` (to grayscale)
 * - `RGBX` -> `U8` (to grayscale)
 *
 *
 * \param [in]  input           Specifies the input image.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] output          Specifies the output image.
 *                                  It must have the same size as \p input.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  color_space     Specifies the input color space.
 * \param [in]  channel_range   Specifies the input channel range.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuColorConvert(const nvxcu_image_t* input,
                                                 const nvxcu_image_t* output,
                                                 nvxcu_color_space_e color_space,
                                                 nvxcu_channel_range_e channel_range,
                                                 const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// TableLookup
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Performs table lookup operation on an input image.
 * \details This kernel uses a LUT to map the pixels in an input image to pixels in the output image.
 * The image format of <tt>\ref NVXCU_DF_IMAGE_U8</tt> is supported.
 *
 * \param [in]  input           Specifies the input image.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  lut_dev_ptr     Specifies the CUDA device pointer to the LUT memory.
 * \param [in]  lut_count       Specifies the number of items in the LUT array.
 * \param [in]  lut_offset      Specifies the offset of the 0 item in the LUT array.
 * \param [out] output          Specifies the output image.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                  It must have the same size as \p input.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuTableLookup(const nvxcu_image_t* input,
                                                const void* lut_dev_ptr,
                                                uint32_t lut_count, uint32_t lut_offset,
                                                const nvxcu_image_t* output,
                                                const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// Sobel3x3
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Calculates derivatives from an input image using 3x3 Sobel operator.
 * \details This kernel uses two 3×3 Sobel Operators, convolved with the input image,
 * to produce two output images (one can be omitted) for the approximations of the X amd
 * Y derivatives. The Sobel Operators \f$ G_x, G_y \f$ are defined as:
 * \f[
 *      \mathbf{G}_x=\begin{vmatrix}
 *      -1 & 0 & +1\\
 *      -2 & 0 & +2\\
 *      -1 & 0 & +1
 *      \end{vmatrix}
 *      ,
 *      \mathbf{G}_y=\begin{vmatrix}
 *      -1 & -2 & -1 \\
 *        0 &  0 & 0  \\
 *      +1 & +2 & +1
 *      \end{vmatrix}
 * \f]
 *
 * \param [in]  input           Specifies the input image.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] output_x        [optional] Specifies the output gradient in the x direction.
 *                                  It must have \ref NVXCU_DF_IMAGE_S16 format.
 *                                  It must have the same size as \p input.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] output_y        [optional] Specifies the output gradient in the y direction.
 *                                  It must have \ref NVXCU_DF_IMAGE_S16 format.
 *                                  It must have the same size as \p input.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  border          Specifies the border extrapolation mode.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuSobel3x3(const nvxcu_image_t* input,
                                             const nvxcu_image_t* output_x,
                                             const nvxcu_image_t* output_y,
                                             const nvxcu_border_t* border,
                                             const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// Erode3x3
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Performs erosion operation on an input image.
 * \details The output is computed by selecting a local minimum over a 3x3 window in the
 * <tt>\ref NVXCU_DF_IMAGE_U8</tt> input image. The operation is defined by:
 * \f[
 * dst(x,y) = \min_{x-1 \le x\prime \le x+1,\ y-1 \le y\prime \le y+1} src(x\prime,y\prime)
 * \f]
 *
 * \param [in]  input           Specifies the input image.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] output          Specifies the output image.
 *                                  It must have the same size and format as \p input.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  border          Specifies the border extrapolation mode.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuErode3x3(const nvxcu_image_t* input,
                                             const nvxcu_image_t* output,
                                             const nvxcu_border_t* border,
                                             const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// Dilate3x3
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Performs dilation operation on an input image.
 * \brief Implements Dilation, which \e grows the white space in a <tt>\ref VX_DF_IMAGE_U8</tt> Boolean image.
 * \details The output is computed by selecting a local maximum over a 3x3 window in the
 * <tt>\ref NVXCU_DF_IMAGE_U8</tt> input image. The operation is defined by:
 * \f[
 * dst(x,y) = \max_{x-1 \le x\prime \le x+1,\ y-1 \le y\prime \le y+1} src(x\prime,y\prime)
 * \f]
 *
 * \param [in]  input           Specifies the input image.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] output          Specifies the output image.
 *                                  It must have the same size and format as \p input.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  border          Specifies the border extrapolation mode.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuDilate3x3(const nvxcu_image_t* input,
                                              const nvxcu_image_t* output,
                                              const nvxcu_border_t* border,
                                              const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// Median3x3
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Computes a median pixel value over a 3x3 window of the input image.
 * \details For an odd number of sorted array, the median is the middle indexed value .
 *
 * \param [in]  input           Specifies the input image.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] output          Specifies the output image.
 *                                  It must have the same size and format as \p input.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  border          Specifies the border extrapolation mode.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuMedian3x3(const nvxcu_image_t* input,
                                              const nvxcu_image_t* output,
                                              const nvxcu_border_t* border,
                                              const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// Box3x3
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Computes a Box filter over a 3x3 window of the input image.
 * \details This kernel computes the average over a 3x3 window of the input image.
 * The convolution matrix used by filtering is given by:
 * \f[
 * \mathbf{M}_{box} = \begin{vmatrix}
 *   1 & 1 & 1\\
 *   1 & 1 & 1\\
 *   1 & 1 & 1
 * \end{vmatrix} * \frac{1}{9}
 * \f]
 *
 * \param [in]  input           Specifies the input image.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] output          Specifies the output image.
 *                                  It must have the same size and format as \p input.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  border          Specifies the border extrapolation mode.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuBox3x3(const nvxcu_image_t* input,
                                           const nvxcu_image_t* output,
                                           const nvxcu_border_t* border,
                                           const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// Gaussian3x3
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Computes a Gaussian filter over a 3x3 window of the input image.
 * \details This kernel computes the Gaussian weighted average over a 3x3 window of
 * the input image. The convolution matrix used by filtering is given by:
 * \f[
 * \mathbf{M}_{gaussian} = \begin{vmatrix}
 *   1 & 2 & 1\\
 *   2 & 4 & 2\\
 *   1 & 2 & 1
 * \end{vmatrix} * \frac{1}{16}
 * \f]
 *
 * \param [in]  input           Specifies the input image.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] output          Specifies the output image.
 *                                  It must have the same size and format as \p input.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  border          Specifies the border extrapolation mode.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuGaussian3x3(const nvxcu_image_t* input,
                                                const nvxcu_image_t* output,
                                                const nvxcu_border_t* border,
                                                const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// Scharr3x3
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Calculates derivatives from an input image using 3x3 Scharr operator.
 * \details  This kernel uses two 3×3 Scharr Operators, convolved with the input image,
 * to produce two output images (one can be omitted) for the approximations of the X and Y
 * derivatives. The Scharr Operators \f$ G_x, G_y \f$ are defined as:
 *
 * @f[
 * \mathbf{G}_x=\begin{vmatrix}
 *    -3 & 0 &  +3 \\
 *   -10 & 0 & +10 \\
 *    -3 & 0 &  +3
 * \end{vmatrix}
 * ,
 * \mathbf{G}_y=\begin{vmatrix}
 *   -3 & -10 & -3 \\
 *    0 &   0 &  0 \\
 *   +3 & +10 & +3
 * \end{vmatrix}
 * @f]
 *
 * \param [in]  input           Specifies the input image.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] output_x        [optional] Specifies the output gradient in the x direction.
 *                                  It must have \ref NVXCU_DF_IMAGE_S16 format.
 *                                  It must have the same size as \p input.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] output_y        [optional] Specifies the output gradient in the y direction.
 *                                  It must have \ref NVXCU_DF_IMAGE_S16 format.
 *                                  It must have the same size as \p input.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  border          Specifies the border extrapolation mode.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuScharr3x3(const nvxcu_image_t* input,
                                              const nvxcu_image_t* output_x, // optional
                                              const nvxcu_image_t* output_y, // optional
                                              const nvxcu_border_t* border,
                                              const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// Laplacian3x3
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Applies a 3x3 Laplacian operator to the input image.
 *
 * \param [in]  input           Specifies the input image.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] output          Specifies the output image.
 *                                  It must have the same size and format as \p input.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  border          Specifies the border extrapolation mode.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuLaplacian3x3(const nvxcu_image_t* input,
                                                 const nvxcu_image_t* output,
                                                 const nvxcu_border_t* border,
                                                 const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// IntegralImage
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Computes the integral image of the input image.
 * \details The pixel value of the integral image at any location (x, y) is the sum of all the pixels
 * to the left of it and above it, including itself. It can be computed by the following recursive equation:
 * \f[
 * output(x,y) = input(x,y) + output(x-1,y) + output(x,y-1) - output(x-1,y-1)
 * \f]
 * where, for x>=0 and y>=0. Otherwise,
 * \f[
 * output(x,y) = 0
 * \f]
 * The overflow policy used is <tt>\ref NVXCU_CONVERT_POLICY_WRAP</tt>.
 *
 * \param [in]  input           Specifies the input image.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] output          Specifies the output image.
 *                                  It must have \ref NVXCU_DF_IMAGE_U32 format.
 *                                  It must have the same size as \p input.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuIntegralImage(const nvxcu_image_t* input,
                                                  const nvxcu_image_t* output,
                                                  const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// Histogram
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Determine the size of CUDA Device and HOST memory that must be passed to the \ref nvxcuHistogram primitive.
 *
 * \param [in] input_width      Specifies the input image width.
 * \param [in] input_height     Specifies the input image height.
 * \param [in] input_format     Specifies the input image format.
 * \param [in] offset           Specifies the start of the values to use (inclusive).
 * \param [in] range            Specifies the end value to use as the range.
 * \param [in] num_bins         Specifies the number of bins in the distribution array.
 * \param [in] prop             Specifies the CUDA device properties for current active device.
 *
 * \see \ref nvxcu_tmp_buf_size_t
 *
 * \return The size of temporary CUDA Device and HOST buffers.
 */
NVX_C_API nvxcu_tmp_buf_size_t nvxcuHistogram_GetBufSize(uint32_t input_width, uint32_t input_height,
                                                         nvxcu_df_image_e input_format,
                                                         uint32_t offset,
                                                         uint32_t range,
                                                         uint32_t num_bins,
                                                         const struct cudaDeviceProp* prop);

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Generates a distribution from an image.
 * \details This kernel partitions the distribution into a number of bins and counts the number of
 * occurrences of each pixel value within the bins. A pixel with intensity 'I' will result in
 * incrementing histogram bin 'i' where
 * \f[
 * i = (I - offset)*numBins/range
 * \f]
 * for
 * \f[
 * offset <= I < offset + range.
 * \f]
 * Pixels with values out of the range will have no effect on the histogram.
 *
 * \param [in]  input                   Specifies the input image.
 *                                          It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                          Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] distribution_dev_ptr    Specifies the CUDA device pointer to distribution array.
 * \param [in]  offset                  Specifies the start of the values to use (inclusive).
 * \param [in]  range                   Specifies the end value to use as the range.
 * \param [in]  num_bins                Specifies the number of bins in the distribution array.
 * \param [in]  tmp_buf                 Specifies the pointers to temporary buffers.
 *                                          Use \ref nvxcuHistogram_GetBufSize to get size of the buffers.
 * \param [in]  exec_target             Specifies the execution target.
 *                                          Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuHistogram(const nvxcu_image_t* input,
                                              uint32_t *distribution_dev_ptr,
                                              uint32_t offset,
                                              uint32_t range,
                                              uint32_t num_bins,
                                              const nvxcu_tmp_buf_t* tmp_buf,
                                              const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// EqualizeHist
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Determine the size of CUDA Device and HOST memory that must be passed to the \ref nvxcuEqualizeHist primitive.
 *
 * \param [in] input_width      Specifies the input image width.
 * \param [in] input_height     Specifies the input image height.
 * \param [in] input_format     Specifies the input image format.
 * \param [in] prop             Specifies the CUDA device properties for current active device.
 *
 * \see \ref nvxcu_tmp_buf_size_t
 *
 * \return The size of temporary CUDA Device and HOST buffers.
 */
NVX_C_API nvxcu_tmp_buf_size_t nvxcuEqualizeHist_GetBufSize(uint32_t input_width, uint32_t input_height,
                                                            nvxcu_df_image_e input_format,
                                                            const struct cudaDeviceProp* prop);

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Equalizes the histogram of a grayscale image.
 * \details This kernel uses Histogram Equalization to adjust the pixel values
 * of a grayscale image so that the histogram of the resulting image is approximately flat.
 *
 * \param [in]  input           Specifies the input image.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] output          Specifies the output image.
 *                                  It must have the same size and format as \p input.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  tmp_buf         Specifies the pointers to temporary buffers.
 *                                  Use \ref nvxcuEqualizeHist_GetBufSize to get size of the buffers.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuEqualizeHist(const nvxcu_image_t* input,
                                                 const nvxcu_image_t* output,
                                                 const nvxcu_tmp_buf_t* tmp_buf,
                                                 const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// ScaleImage
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Resizes an input image from source to the destination dimensions.
 * \details The supported interpolation modes are:
 * \arg <tt>\ref NVXCU_INTERPOLATION_TYPE_NEAREST_NEIGHBOR</tt>
 * \arg <tt>\ref NVXCU_INTERPOLATION_TYPE_AREA</tt>
 * \arg <tt>\ref NVXCU_INTERPOLATION_TYPE_BILINEAR</tt>
 *
 * For interpolation, the edge of a pixel is interpreted as being aligned to the edge of the image
 * and the the pixel value is evaluated at its center.
 * Therefore, the sample positions are computed by aligning the scaled outside edges
 * of the input image to the outside edges of the output image, and then the output pixel
 * values are calculated based on the computed sample positions.
 *
 * Because of the above interpolation step,  unless the scale is 1:1, the sample positions of
 * the top left pixels in the input and output images do not overlap exactly on each other.
 * They need to be computed by interpolation. In general, the corresponding sample positions
 * in the input and output images are computed by:
 *
 * \f[
 * x_{input} = \left((x_{output} + 0.5) * \frac{width_{input}}{width_{output}}\right) - 0.5
 * \f]
 * \f[
 * y_{input} = \left((y_{output} + 0.5) * \frac{height_{input}}{height_{output}}\right) - 0.5
 * \f]
 * \f[
 * x_{output} = \left((x_{input} + 0.5) * \frac{width_{output}}{width_{input}}\right) - 0.5
 * \f]
 * \f[
 * y_{output} = \left((y_{input} + 0.5) * \frac{height_{output}}{height_{input}}\right) - 0.5
 * \f]
 *
 *- For <tt>\ref NVXCU_INTERPOLATION_TYPE_NEAREST_NEIGHBOR</tt>, the output pixel value is
 *  that of the intput pixel whose centre is closest to the interpolated sample position.
 *
 *- For <tt>\ref NVXCU_INTERPOLATION_TYPE_BILINEAR</tt>, the output pixel value is
 *  a weighted average of the closest input pixels to the interpolated sample position. That is:
 *
 * \f[
 * x_{lower} = \lfloor x_{input}\rfloor
 * \f]
 * \f[
 * y_{lower} = \lfloor y_{input}\rfloor
 * \f]
 * \f[
 * s = x_{input} - x_{lower}
 * \f]
 * \f[
 * t = y_{input} - y_{lower}
 * \f]
 * \f[
 * output(x_{output},y_{output}) =
 * (1-s)(1-t) * input(x_{lower},y_{lower})
 * + s(1-t) * input(x_{lower}+1,y_{lower})
 * \f]
 * \f[
 * + (1-s)t * input(x_{lower},y_{lower}+1)
 * + s * t * input(x_{lower}+1,y_{lower}+1)
 * \f]
 *
 *- For <tt>\ref NVXCU_INTERPOLATION_TYPE_AREA</tt>, each output pixel is generated by sampling
 *  all the input pixels that are at
 *  least partly covered by the area bounded by:
 *
 * \f[
 * \left(x_{output} * \frac{width_{input}}{width_{output}}\right)-0.5,
 * \left(y_{output} * \frac{height_{input}}{height_{output}}\right)-0.5
 * \f]
 *
 * and
 *
 * \f[
 * \left((x_{output} + 1) * \frac{width_{input}}{width_{output}}\right)-0.5,
 * \left((y_{output} + 1) * \frac{height_{input}}{height_{output}}\right)-0.5
 * \f]
 *
 *
 * @image html samplingpatterns.png
 * @image latex samplingpatterns.eps
 *
 *
 * \details The above diagram shows three sampling methods used to shrink a 7x3 image to 3x1.
 *
 * The topmost image pair shows nearest-neighbor sampling, with crosses on the left image marking
 * the sample positions in the source that are used to generate the output image on the right.
 * As the pixel centre closest to the sample position is white in all cases, the resulting
 * 3x1 image is white.
 *
 * The middle image pair shows bilinear sampling, with black squares on the left image showing the
 * region in the source being sampled to generate each pixel on the destination image on the right.
 * This sample area is always the size of an input pixel. The outer destination pixels partly
 * sample from the outermost green pixels, so their resulting value is a weighted average of white
 * and green.
 *
 * The bottom image pair shows area sampling. The black rectangles in the source image on the left
 * show the bounds of the projection of the destination pixels onto the source. The destination pixels
 * on the right are formed by averaging at least those source pixels whose areas are wholly or partly
 * contained within those rectangles. The manner of this averaging is implementation-defined; the
 * example shown here weights the contribution of each source pixel by the amount of that pixel&apos;s
 * area contained within the black rectangle.
 *
 * In addition to standard formats for the Scale Image primitive,
 * VisionWorks supports the following input formats:
 *
 * - `RGB`
 * - `RGBX`
 * - `S16`
 *
 * \param [in]  src             Specifies the input image.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 or \ref NVXCU_DF_IMAGE_RGB
 *                                  or \ref NVXCU_DF_IMAGE_RGBX or \ref NVXCU_DF_IMAGE_S16 format.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] dst             Specifies the output image.
 *                                  It must have the same format as \p src.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  type            Specifies the interpolation mode.
 * \param [in]  border          Specifies the border extrapolation mode.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuScaleImage(const nvxcu_image_t* src,
                                               const nvxcu_image_t* dst,
                                               nvxcu_interpolation_type_e type,
                                               const nvxcu_border_t* border,
                                               const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// WarpAffine
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Performs an affine transform on an image.
 * \details This kernel performs an linear affine transform to map the coordinates between input
 * and output images. The transform is a 2x3 Matrix \f$ M \f$, and the mapping is defined by:
 * \f{eqnarray}{
 * x0 &=& M_{1,1}*x + M_{1,2}*y + M_{1,3} \\
 * y0 &=& M_{2,1}*x + M_{2,2}*y + M_{2,3} \\
 * output(x,y) &=& input(x0,y0)
 * \f}
 *
 * ### Supported Input Formats ###
 *
 * In addition to standard formats for the WarpAffine primitives,
 * VisionWorks supports the following input formats:
 *
 * - `RGBX`
 *
 * \param [in]  input               Specifies the input image.
 *                                      It must have \ref NVXCU_DF_IMAGE_U8 or \ref NVXCU_DF_IMAGE_RGBX format.
 *                                      Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  matrix_dev_ptr      Specifies the CUDA device pointer to transform matrix.
 * \param [in]  type                Specifies the interpolation mode.
 * \param [out] output              Specifies the output image.
 *                                      It must have the same format as \p src.
 *                                      Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  border              Specifies the border extrapolation mode.
 * \param [in]  exec_target         Specifies the execution target.
 *                                      Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuWarpAffine(const nvxcu_image_t* input,
                                               const float *matrix_dev_ptr,
                                               nvxcu_interpolation_type_e type,
                                               const nvxcu_image_t* output,
                                               const nvxcu_border_t* border,
                                               const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// WarpPerspective
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Performs an perspective transform on an image.
 * \details This kernel performs an perspective transform to map the coordinates between input
 * and output images. The transform is defined by a 3x3 Matrix \f$ M \f$:
 * \f{eqnarray}{
 * x0 &=& M_{1,1}*x + M_{1,2}*y + M_{1,3} \\
 * y0 &=& M_{2,1}*x + M_{2,2}*y + M_{2,3} \\
 * z0 &=& M_{3,1}*x + M_{3,2}*y + M_{3,3} \\
 * output(x,y) &=& input(\frac{x0}{z0},\frac{y0}{z0})
 * \f}
 *
 * ### Supported Input Formats ###
 *
 * In addition to standard formats for the WarpPerspective primitives,
 * VisionWorks supports the following input formats:
 *
 * - `RGBX`
 *
 * \param [in]  input               Specifies the input image.
 *                                      It must have \ref NVXCU_DF_IMAGE_U8 or \ref NVXCU_DF_IMAGE_RGBX format.
 *                                      Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  matrix_dev_ptr      Specifies the CUDA device pointer to transform matrix.
 * \param [in]  type                Specifies the interpolation mode.
 * \param [out] output              Specifies the output image.
 *                                      It must have the same format as \p src.
 *                                      Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  border              Specifies the border extrapolation mode.
 * \param [in]  exec_target         Specifies the execution target.
 *                                      Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuWarpPerspective(const nvxcu_image_t* input,
                                                    const float *matrix_dev_ptr,
                                                    nvxcu_interpolation_type_e type,
                                                    const nvxcu_image_t* output,
                                                    const nvxcu_border_t* border,
                                                    const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// Remap
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Maps pixel values in an output image from those in an input image.
 * \details This kernel takes a remap \e table object \ref nvxcu_image_t to map output pixel values from
 * pixel vaules in the input image. A remap is typically defined as:
 * \f[
 *   output(x,y)=input(mapx(x,y),mapy(x,y));
 * \f]
 * for every (x,y) in the destination image
 *
 * The mapping functions \e mapx and \e mapy are defined in the \e table \ref nvxcu_image_t object.
 *
 * \param [in]  input           Specifies the input image.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8, \ref NVXCU_DF_IMAGE_RGB or
 *                                  \ref NVXCU_DF_IMAGE_RGBX format.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  table           Specifies the input remap table.
 *                                  It must have \ref NVXCU_DF_IMAGE_2F32 format.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  policy          Specifies the interpolation mode.
 * \param [out] output          Specifies the output image.
 *                                  It must have the same format as \p src.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  border          Specifies the border extrapolation mode.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuRemap(const nvxcu_image_t* input,
                                          const nvxcu_image_t* table,
                                          nvxcu_interpolation_type_e policy,
                                          const nvxcu_image_t* output,
                                          const nvxcu_border_t* border,
                                          const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// MeanStdDev
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Determine the size of CUDA Device and HOST memory that must be passed to the \ref nvxcuMeanStdDev primitive.
 *
 * \param [in] input_width      Specifies the input image width.
 * \param [in] input_height     Specifies the input image height.
 * \param [in] input_format     Specifies the input image format.
 * \param [in] prop             Specifies the CUDA device properties for current active device.
 *
 * \see \ref nvxcu_tmp_buf_size_t
 *
 * \return The size of temporary CUDA Device and HOST buffers.
 */
NVX_C_API nvxcu_tmp_buf_size_t nvxcuMeanStdDev_GetBufSize(uint32_t input_width, uint32_t input_height,
                                                          nvxcu_df_image_e input_format,
                                                          const struct cudaDeviceProp* prop);

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Computes the mean and the standard deviation of the pixel values in the input image.
 * \details The mean pixel value is computed as:
 * \f[
 * \mu = \frac{\left(\sum_{y=0}^h \sum_{x=0}^w src(x,y) \right)} {(width * height)}
 * \f]
 * The standard deviation of the pixel vaules in the input image is computed as:
 * \f[
 * \sigma = \sqrt{\frac{\left(\sum_{y=0}^h \sum_{x=0}^w (\mu - src(x,y))^2 \right)} {(width * height)}}
 * \f]
 *
 * \param [in]  input               Specifies the input image.
 *                                      It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                      Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] mean_dev_ptr        Specifies the CUDA device pointer to the mean value scalar.
 * \param [out] stddev_dev_ptr      Specifies the CUDA device pointer to the standard deviation scalar.
 * \param [in]  tmp_buf             Specifies the pointers to temporary buffers.
 *                                      Use \ref nvxcuMeanStdDev_GetBufSize to get size of the buffers.
 * \param [in]  exec_target         Specifies the execution target.
 *                                      Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuMeanStdDev(const nvxcu_image_t* input,
                                               float *mean_dev_ptr,
                                               float *stddev_dev_ptr,
                                               const nvxcu_tmp_buf_t* tmp_buf,
                                               const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// MinMaxLoc
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Determine the size of CUDA Device and HOST memory that must be passed to the \ref nvxcuMinMaxLoc primitive.
 *
 * \param [in] input_width      Specifies the input image width.
 * \param [in] input_height     Specifies the input image height.
 * \param [in] input_format     Specifies the input image format.
 * \param [in] prop             Specifies the CUDA device properties for current active device.
 *
 * \see \ref nvxcu_tmp_buf_size_t
 *
 * \return The size of temporary CUDA Device and HOST buffers.
 */
NVX_C_API nvxcu_tmp_buf_size_t nvxcuMinMaxLoc_GetBufSize(uint32_t input_width, uint32_t input_height,
                                                         nvxcu_df_image_e input_format,
                                                         const struct cudaDeviceProp* prop);

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Finds the minimum and maximum values  and their locations in an input image.
 * \details If several minimums/maximums are found in the image, the kernel returns all the locations of them.
 * \f[
 * minVal = \min_{
 * \begin{array}{c}
 * 0 \le x\prime \le width \\
 * 0 \le y\prime \le height
 * \end{array}
 * } src(x\prime,y\prime)
 * \f]
 *
 * \f[
 * maxVal = \max_{
 * \begin{array}{c}
 * 0 \le x\prime \le width \\
 * 0 \le y\prime \le height
 * \end{array}
 * } src(x\prime,y\prime)
 * \f]
 *
 * \param [in]  input               Specifies the input image.
 *                                      It must have \ref NVXCU_DF_IMAGE_U8 or \ref NVXCU_DF_IMAGE_S16 or \ref NVXCU_DF_IMAGE_U16
 *                                      or \ref NVXCU_DF_IMAGE_S32 or \ref NVXCU_DF_IMAGE_U32 format.
 *                                      Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] min_val_dev_ptr     [optional] Specifies the CUDA device pointer to the output minimum value.
 *                                      The scalar's type must match image format (for example, `uint16_t` for \ref NVXCU_DF_IMAGE_U16).
 * \param [out] max_val_dev_ptr     [optional] Specifies the CUDA device pointer to the output maximum value.
 *                                      The scalar's type must match image format (for example, `uint16_t` for \ref NVXCU_DF_IMAGE_U16).
 * \param [out] min_loc             [optional] Specifies the output array of minimum locations.
 *                                      It must have \ref NVXCU_TYPE_COORDINATES2D item type.
 *                                      Only \ref nvxcu_plain_array_t is supported.
 * \param [out] max_loc             [optional] Specifies the output array of maximum locations.
 *                                      It must have \ref NVXCU_TYPE_COORDINATES2D item type.
 *                                      Only \ref nvxcu_plain_array_t is supported.
 * \param [out] min_count_dev_ptr   [optional] Specifies the CUDA device pointer to total number of detected minimums.
 * \param [out] max_count_dev_ptr   [optional] Specifies the CUDA device pointer to total number of detected maximums.
 * \param [in]  tmp_buf             Specifies the pointers to temporary buffers.
 *                                      Use \ref nvxcuMinMaxLoc_GetBufSize to get size of the buffers.
 * \param [in]  exec_target         Specifies the execution target.
 *                                      Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuMinMaxLoc(const nvxcu_image_t* input,
                                              void *min_val_dev_ptr,
                                              void *max_val_dev_ptr,
                                              const nvxcu_array_t* min_loc,
                                              const nvxcu_array_t* max_loc,
                                              uint32_t *min_count_dev_ptr,
                                              uint32_t *max_count_dev_ptr,
                                              const nvxcu_tmp_buf_t* tmp_buf,
                                              const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// Convolve
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Determine the size of CUDA Device and HOST memory that must be passed to the \ref nvxcuConvolve primitive.
 *
 * \see \ref nvxcu_tmp_buf_size_t
 *
 * \deprecated The function is planned to be removed in future releases.
 * Allocation of temporary buffers is only needed when \ref NVXCU_BORDER_MODE_CONSTANT mode of the API is used with non-zero border value.
 * Note that CUDA does not natively support non-zero constant border mode, therefore VisionWorks is creating a padding
 * in a temporary buffer to emulate this mode. Support for non-zero constant border mode is planned to be removed in future releases
 * as it brings additional complexity to the VisionWorks CUDA API.
 *
 * \param [in] width            Specifies the width of the input image.
 * \param [in] height           Specifies the height of the input image.
 * \param [in] input_format     Specifies the format of the input image.
 * \param [in] kernel_width     Specifies the convolution kernel width.
 * \param [in] kernel_height    Specifies the convolution kernel height.
 * \param [in] output_format    Specifies the format of the output image.
 * \param [in] border           Specifies the border extrapolation mode.
 * \param [in] prop             Specifies the CUDA device properties for current active device.
 *
 * \return The size of temporary CUDA Device and HOST buffers.
 */
NVX_C_API nvxcu_tmp_buf_size_t nvxcuConvolve_GetBufSize(uint32_t width, uint32_t height,
                                                        nvxcu_df_image_e input_format,
                                                        int32_t kernel_width, int32_t kernel_height,
                                                        nvxcu_df_image_e output_format,
                                                        const nvxcu_border_t* border,
                                                        const struct cudaDeviceProp* prop);

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Convolves the input with the client supplied convolution matrix.
 *
 * \details The convolution mask \f$ C_{m,n} \f$ with type int16_t is supplied by client. The output image will
 * be in the <tt>\ref NVXCU_DF_IMAGE_S16</tt> format unless a <tt>\ref NVXCU_DF_IMAGE_U8</tt> image is explicitly specified.
 * If <tt>\ref NVXCU_DF_IMAGE_U8</tt> is specified and computed pixel values are out
 * of range, the values are clamped to 0 or 255. An intermediate \e sum value is first computed by:
 * \f{eqnarray}{
 * k_0 &=& \frac{m}{2}  \\
 * l_0 &=& \frac{n}{2}  \\
 * sum &=& \sum_{k=0,l=0}^{k=m-1,l=n-1} input(x+k_0-k, y+l_0-l) C_{k,l}
 * \f}
 * @note The above equation for this function is different than an equivalent operation suggested
 * by the OpenCV Filter2D function.
 *
 * For <tt>\ref NVXCU_DF_IMAGE_U8</tt> format, the output is set by an additional clamping step:
 * \f[
 * output(x,y) = \begin{cases}  \cr
 * 0 & \text{if } sum < 0 \cr
 * 255 & \text{if } sum / scale > 255 \cr
 * sum / scale & \text{otherwise}
 * \end{cases}
 * \f]
 * For <tt>\ref NVXCU_DF_IMAGE_S16</tt> format, the output is set to \e sum directly.
 * \f[
 * output(x,y) = sum / scale
 * \f]
 * The overflow policy used is <tt>\ref NVXCU_CONVERT_POLICY_SATURATE</tt>.
 *
 * \param [in]  input               Specifies the input image.
 *                                      It must have \ref NVXCU_DF_IMAGE_U8 or \ref NVXCU_DF_IMAGE_S16 format.
 *                                      Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  kernel_dev_ptr      Specifies the CUDA device pointer to the convolution kernel coefficients.
 *                                      The coefficients must be stored in reverse order, ie.
 *                                      `kernel_dev_ptr[0]` must contain `kernel[H - 1][W - 1]` value.
 * \param [in]  kernel_div          Specifies the convolution kernel scale factor.
 * \param [in]  kernel_width        Specifies the convolution kernel width.
 * \param [in]  kernel_height       Specifies the convolution kernel height.
 * \param [out] output              Specifies the output image.
 *                                      It must have \ref NVXCU_DF_IMAGE_U8 or \ref NVXCU_DF_IMAGE_S16 format.
 *                                      It must have the same size as \p input.
 *                                      Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  border              Specifies the border extrapolation mode.
 *                                      Support for non-zero constant border mode is planned to be removed in future releases
 *                                      as it brings additional complexity to the VisionWorks CUDA API.
 * \param [in]  tmp_buf             Specifies the pointers to temporary buffers.
 *                                      Use \ref nvxcuConvolve_GetBufSize to get size of the buffers.
 *                                      The parameter is needed only for \ref NVXCU_BORDER_MODE_CONSTANT with non-zero border value.
 *                                      For all other modes is can be `NULL`.
 *                                      The parameter is planned to be removed in future releases.
 * \param [in]  exec_target         Specifies the execution target.
 *                                      Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuConvolve(const nvxcu_image_t* input,
                                             const int16_t *kernel_dev_ptr,
                                             uint32_t kernel_div,
                                             int32_t kernel_width, int32_t kernel_height,
                                             const nvxcu_image_t* output,
                                             const nvxcu_border_t* border,
                                             const nvxcu_tmp_buf_t* tmp_buf,
                                             const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// NonLinearFilter
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Applies non-linear filter to the input image.
 * \details The lowest width and height must be greater than 9.
 *
 * \param [in]  function            Specifies the non-linear filter function.
 *                                      See \ref nvxcu_non_linear_filter_e.
 * \param [in]  input               Specifies the input image.
 *                                      It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                      Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  mask_pattern        Specifies the mask pattern.
 *                                      See \ref nvxcu_pattern_e.
 *                                      For \ref NVXCU_PATTERN_OTHER non-NULL \p mask_dev_ptr must be supplied.
 * \param [in]  mask_dev_ptr        Specifies the CUDA device pointer to the mask values.
 * \param [in]  mask_width          Specifies the convolution mask width.
 *                                      It must be <= 9.
 * \param [in]  mask_height         Specifies the convolution mask height.
 *                                      It must be <= 9.
 * \param [out] output              Specifies the output image.
 *                                      It must have the same size and format as \p input.
 *                                      Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  border              Specifies the border extrapolation mode.
 *                                      Non-zero constant border mode is not supported.
 * \param [in]  exec_target         Specifies the execution target.
 *                                      Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuNonLinearFilter(nvxcu_non_linear_filter_e function,
                                                    const nvxcu_image_t* input,
                                                    nvxcu_pattern_e mask_pattern,
                                                    const uint8_t* mask_dev_ptr,
                                                    int32_t mask_width, int32_t mask_height,
                                                    const nvxcu_image_t* output,
                                                    const nvxcu_border_t* border,
                                                    const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// HalfScaleGaussian
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Performs a Gaussian Blur on an image then half-scales it.
 *
 * \see \ref nvxcuScaleImage
 *
 * \param [in]  input           Specifies the input image.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] output          Specifies the output image.
 *                                  It must have the same size and format as \p input.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  kernel_size     Specifies the Gaussian kernel size.
 *                                  It must be 1, 3 or 5.
 * \param [in]  border          Specifies the border extrapolation mode.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuHalfScaleGaussian(const nvxcu_image_t* input,
                                                      const nvxcu_image_t* output,
                                                      int32_t kernel_size,
                                                      const nvxcu_border_t* border,
                                                      const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// GaussianPyramid
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Determine the size of CUDA Device and HOST memory that must be passed to the \ref nvxcuGaussianPyramid primitive.
 *
 * \see \ref nvxcu_tmp_buf_size_t
 *
 * \param [in] width        Specifies the width of the first pyramid level.
 * \param [in] height       Specifies the height of the first pyramid level.
 * \param [in] num_levels   Specifies the number of levels in the output pyramid.
 * \param [in] scale        Specifies the pyramid's scale factor.
 * \param [in] border       Specifies the border extrapolation mode.
 * \param [in] prop         Specifies the CUDA device properties for current active device.
 *
 * \return The size of temporary CUDA Device and HOST buffers.
 */
NVX_C_API nvxcu_tmp_buf_size_t nvxcuGaussianPyramid_GetBufSize(uint32_t width, uint32_t height,
                                                               uint32_t num_levels,
                                                               float scale,
                                                               const nvxcu_border_t* border,
                                                               const struct cudaDeviceProp* prop);

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Computes a Gaussian image pyramid from its first level.
 *
 * \note The first level of the input pyramid must be initialized.
 *
 * \details This kernel creates the Gaussian image pyramid from the input image.
 * On each pyramid level, the specific 5x5 Gaussian Kernel \e G is used and then the image
 * is scaled to the next level using  <tt>\ref NVXCU_INTERPOLATION_TYPE_NEAREST_NEIGHBOR</tt>.
 * \f[
 *       \mathbf{G}=\frac{1}{256} * \begin{vmatrix}
 *       1 & 4  & 6  & 4  & 1 \\
 *       4 & 16 & 24 & 16 & 4 \\
 *       6 & 24 & 36 & 24 & 6 \\
 *       4 & 16 & 24 & 16 & 4 \\
 *       1 & 4  & 6  & 4  & 1 \\
 *       \end{vmatrix}
 * \f]
 * Level 0 must be the same as the input image.
 *
 * \param [in,out] pyr              Specifies the pyramid object.
 *                                      Only \ref nvxcu_pitch_linear_pyramid_t is supported.
 * \param [in]     tmp_buf          Specifies the pointers to temporary buffers.
 *                                      Use \ref nvxcuGaussianPyramid_GetBufSize to get size of the buffers.
 * \param [in]     border           Specifies the border extrapolation mode.
 *                                      Support for non-zero constant border mode is planned to be removed in future releases
 *                                      as it brings additional complexity to the VisionWorks CUDA API.
 * \param [in]     exec_target      Specifies the execution target.
 *                                      Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuGaussianPyramid(const nvxcu_pyramid_t* pyr,
                                                    const nvxcu_tmp_buf_t* tmp_buf,
                                                    const nvxcu_border_t* border,
                                                    const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// LaplacianPyramid
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Determine the size of CUDA Device and HOST memory that must be passed to the \ref nvxcuLaplacianPyramid primitive.
 *
 * \see \ref nvxcu_tmp_buf_size_t
 *
 * \param [in] width        Specifies the width of the input.
 * \param [in] height       Specifies the height of the input.
 * \param [in] num_levels   Specifies the number of levels in the output pyramid.
 * \param [in] border       Specifies the border extrapolation mode.
 * \param [in] prop         Specifies the CUDA device properties for current active device.
 *
 * \return The size of temporary CUDA Device and HOST buffers.
 */
NVX_C_API nvxcu_tmp_buf_size_t nvxcuLaplacianPyramid_GetBufSize(uint32_t width, uint32_t height,
                                                                uint32_t num_levels,
                                                                const nvxcu_border_t* border,
                                                                const struct cudaDeviceProp* prop);

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Computes a Laplacian image pyramid.
 * \details This kernel creates the Laplacian image pyramid from the input image using difference of Gaussian.
 * First, a Gaussian pyramid with <tt>\ref NVXCU_SCALE_PYRAMID_HALF</tt>
 * is created from the input image. Then, at each Gaussian pyramid level \f$i\f$, the corresponding image
 * \f$I_i\f$ is filtered by a 5x5 Gaussian kernel, and the difference between the two images
 * is the corresponding image \f$L_i\f$ at Laplacian pyramid level \f$i\f$:
 * \f[
 * L_i = I_i - Gaussian5x5(I_i).
 * \f]
 * Level 0 must be the same size as the input image.
 *
 * \param [in]  input               Specifies the input image.
 *                                      It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                      Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] laplacian           Specifies the output pyramid object.
 *                                      It must have \ref NVXCU_DF_IMAGE_S16 format.
 *                                      Only \ref nvxcu_pitch_linear_pyramid_t is supported.
 * \param [out] output              Specifies the output lowest resolution image.
 *                                      It must have \ref NVXCU_DF_IMAGE_S16 format.
 *                                      Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  tmp_buf             Specifies the pointers to temporary buffers.
 *                                      Use \ref nvxcuLaplacianPyramid_GetBufSize to get size of the buffers.
 * \param [in]  border              Specifies the border extrapolation mode.
 * \param [in]  exec_target         Specifies the execution target.
 *                                      Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuLaplacianPyramid(const nvxcu_image_t* input,
                                                     const nvxcu_pyramid_t* laplacian,
                                                     const nvxcu_image_t* output,
                                                     const nvxcu_tmp_buf_t* tmp_buf,
                                                     const nvxcu_border_t* border,
                                                     const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// LaplacianReconstruct
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Determine the size of CUDA Device and HOST memory that must be passed to the \ref nvxcuLaplacianReconstruct primitive.
 *
 * \see \ref nvxcu_tmp_buf_size_t
 *
 * \param [in] width        Specifies the width of the output.
 * \param [in] height       Specifies the height of the output.
 * \param [in] num_levels   Specifies the number of levels in the input pyramid.
 * \param [in] prop         Specifies the CUDA device properties for current active device.
 *
 * \return The size of temporary CUDA Device and HOST buffers.
 */
NVX_C_API nvxcu_tmp_buf_size_t nvxcuLaplacianReconstruct_GetBufSize(uint32_t width, uint32_t height,
                                                                    uint32_t num_levels,
                                                                    const struct cudaDeviceProp* prop);

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Reconstructs an image from a Laplacian Image pyramid.
 * \details This kernel reconstructs the image of the highest possible resolution from a Laplacian pyramid
 * and an input image with the lowest resolution. First, the input image is added to the last level of the
 * Laplacian pyramid \f$L_{n-1}\f$, the resulting image
 * is upsampled to the resolution of the next pyramid level:
 * \f[
 *     I_{n-2} = upsample(input + L_{n-1})
 * \f]
 * And then, for pyramid level \f$0< i <(n-1)\f$:
 * \f[
 *     I_{i-1} = upsample(I_i + L_i)
 * \f]
 * Finally, the output image is:
 * \f[
 *     output = I_0 + L_0
 * \f]
 *
 * \param [in]  laplacian           Specifies the input pyramid object.
 *                                      It must have \ref NVXCU_DF_IMAGE_S16 format.
 *                                      Only \ref nvxcu_pitch_linear_pyramid_t is supported.
 * \param [in]  input               Specifies the input lowest resolution image.
 *                                      It must have \ref NVXCU_DF_IMAGE_S16 format.
 *                                      Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] output              Specifies the output image.
 *                                      It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                      Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  tmp_buf             Specifies the pointers to temporary buffers.
 *                                      Use \ref nvxcuLaplacianReconstruct_GetBufSize to get size of the buffers.
 * \param [in]  exec_target         Specifies the execution target.
 *                                      Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuLaplacianReconstruct(const nvxcu_pyramid_t* laplacian,
                                                         const nvxcu_image_t* input,
                                                         const nvxcu_image_t* output,
                                                         const nvxcu_tmp_buf_t* tmp_buf,
                                                         const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// CannyEdgeDetector
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Determine the size of CUDA Device and HOST memory that must be passed to the \ref nvxcuCannyEdgeDetector primitive.
 *
 * \see \ref nvxcu_tmp_buf_size_t
 *
 * \param [in] width            Specifies the width of the input image.
 * \param [in] height           Specifies the height of the input image.
 * \param [in] format           Specifies the format of the input image.
 * \param [in] gradient_size    Specifies the gradient size for Sobel operator.
 * \param [in] prop             Specifies the CUDA device properties for current active device.
 *
 * \return The size of temporary CUDA Device and HOST buffers.
 */
NVX_C_API nvxcu_tmp_buf_size_t nvxcuCannyEdgeDetector_GetBufSize(uint32_t width, uint32_t height, nvxcu_df_image_e format,
                                                                 int32_t gradient_size,
                                                                 const struct cudaDeviceProp* prop);

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Applies Canny edge detector algorithm to the input image.
 * \details This kernel is a Canny edge detector with implementation algorithm similar to
 * \cite Canny1986. The main steps of the edge detector are:
 * \arg Gradient magnitude and orientation computation using the Sobel operator.
 * \arg Non-maximum suppression of gradient values except the local maximal.
 * \arg Edge tracking using hysteresis double thresholding to produce a binary result.
 *
 * The details of each of each step are described as below.
 *
 * \arg <b>Gradient Computation:</b>
 * Conceptually, vertical and horizontal Sobel kernels are used to convolve with
 * the input image to produce directional gradient images (\f$dx \f$ and
 * \f$ dy \f$). The size of the Sobel kernels is given by the \e gradient_size input
 * parameter. The Sobel kernels with different sizes are shown as below.
 * The computed directional gradient images (\f$dx \f$ and
 * \f$ dy \f$) are then used to compute a gradient magnitude image and a
 * gradient orientation image. The norm used to compute the gradient
 * magnitude is indicated by the \e norm_type parameter, which can be
 * <tt>\ref NVXCU_NORM_L1</tt> or <tt>\ref NVXCU_NORM_L2</tt>. The gradient orientations
 * are quantized to 0, 45, 90, and 135 degrees.
 * - For \e gradient_size = 3:
 * \f[
 * \mathbf{sobel}_{x}=
 * \begin{vmatrix}
 *   -1 & 0 & 1\\
 *   -2 & 0 & 2\\
 *   -1 & 0 & 1
 * \end{vmatrix}
 * \f]
 *
 * \f[
 * \mathbf{sobel}_{y}=({sobel}_{x})\prime=
 * \begin{vmatrix}
 *   -1 & -2 & -1\\
 *    0 & 0 & 0\\
 *    1 & 2 & 1
 * \end{vmatrix}
 * \f]
 * - For \e gradient_size = 5:
 * \f[
 * \mathbf{sobel}_{x}=
 * \begin{vmatrix}
 *   -1 & -2 &  0 & 2 &  1\\
 *   -4 & -8 &  0 & 8 &  4\\
 *   -6 & -12 & 0 & 12 & 6\\
 *   -4 & -8 &  0 & 8 &  4\\
 *   -1 & -2 &  0 & 2 &  1\\
 * \end{vmatrix}
 * \f]
 * \f[
 * \mathbf{sobel}_{y}=({sobel}_{x})\prime
 * \f]
 * - For \e gradient_size = 7:
 * \f[
 * \mathbf{sobel}_{x}=
 * \begin{vmatrix}
 *   -1  &  -4 & -5 &   0 &   5 &  4 &  1\\
 *   -6  & -24 & -30 &  0 &  30 & 24 &  6\\
 *   -15 & -60 & -75 &  0 &  75 & 60 & 15\\
 *   -20 & -80 & -100 & 0 & 100 & 80 & 20\\
 *   -15 & -60 & -75 &  0 &  75 & 60 & 15\\
 *   -6  & -24 & -30 &  0 &  30 & 24 &  6\\
 *   -1  &  -4 & -5 &   0 &   5 &  4 &  1\\
 * \end{vmatrix}
 * \f]
 * \f[
 * \mathbf{sobel}_{y}=({sobel}_{x})\prime*
 * \f]
 *
 * \arg <b>Non-Maximum Suppression:</b>
 * Non-Maximum suppression is applied to "thin" the edge.
 * A pixel is retained as a potential edge pixel if and only if its magnitude is
 * the local maximal in the direction perpendicular to its edge
 * orientation.  For example, if the pixel&apos;s edge orientation is 90 degrees,
 * it is only retained if its gradient magnitude is larger than that
 * of the pixels at 0 and 180 degrees to it. If a pixel is
 * suppressed via this condition, it must be set to \e false_value and not appear as an edge pixel
 * in the final output.
 * \arg <b>Edge Tracking with double thresholds:</b>
 * If the edge pixel’s gradient value is higher than \e upper_thresh,
 * they are marked as strong edge pixels. If the edge pixel’s gradient value is
 * smaller than \e upper_thresh and larger than \e lower_thresh,
 * they are marked as weak edge pixels. If the pixel value is smaller than \e lower_thresh,
 * it will be suppressed. The strong edge pixels are marked as edge
 * pixels (set to \e true_value) in the final output image.
 * The weak edge pixels are tracked and marked as edges (\e true_value) in the
 * output if they are connected to the strong edge pixels. This can be done by starting
 * at the known edge pixels and
 * moving in all eight directions recursively
 * until the gradient magnitude is less than or equal to the low threshold.
 * \arg <b>Caveats:</b>
 * The intermediate results described above may not exist in a specific implementation.
 * For example, an implementation may only produce the final binary edge image without
 * constructing the gradient images and non-maximum-suppressed images. The implementation
 * must make sure the final edge image match the result created by the algorithm described above.
 *
 * \param [in]  input           Specifies the input image.
 *                                  It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  lower_thresh    Specifies the lower threshold value for hysteresis.
 * \param [in]  upper_thresh    Specifies the upper threshold value for hysteresis.
 * \param [in]  true_value      Specifies the value to mark edge points.
 * \param [in]  false_value     Specifies the value to mark non edge points.
 * \param [in]  gradient_size   Specifies the gradient size for Sobel operator.
 *                                  It must be 3, 5 or 7.
 * \param [in]  norm_type       Specifies the norm used to compute the gradient.
 * \param [out] output          Specifies the output image.
 *                                  It must have the same size and format as \p input.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  tmp_buf         Specifies the pointers to temporary buffers.
 *                                  Use \ref nvxcuCannyEdgeDetector_GetBufSize to get size of the buffers.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuCannyEdgeDetector(const nvxcu_image_t* input,
                                                      int32_t lower_thresh, int32_t upper_thresh,
                                                      int8_t true_value, int8_t false_value,
                                                      int32_t gradient_size,
                                                      nvxcu_norm_type_e norm_type,
                                                      const nvxcu_image_t* output,
                                                      const nvxcu_tmp_buf_t* tmp_buf,
                                                      const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// HarrisCorners
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Determine the size of CUDA Device and HOST memory that must be passed to the \ref nvxcuHarrisCorners primitive.
 *
 * \see \ref nvxcu_tmp_buf_size_t
 *
 * \param [in] width            Specifies the width of the input image.
 * \param [in] height           Specifies the height of the input image.
 * \param [in] format           Specifies the format of the input image.
 * \param [in] min_distance     Specifies the radial Euclidean distance for non-maximum suppression.
 * \param [in] gradient_size    Specifies the gradient window size.
 *                                  It must be 3, 5 or 7.
 * \param [in] block_size       Specifies the block window size used to compute the Harris Corner score.
 *                                  It must be 3, 5 or 7.
 * \param [in] arr_type         Specifies the output array item type.
 * \param [in] arr_capacity     Specifies the output array capacity.
 * \param [in] border           Specifies the border extrapolation mode.
 * \param [in] prop             Specifies the CUDA device properties for current active device.
 *
 * \return The size of temporary CUDA Device and HOST buffers.
 */
NVX_C_API nvxcu_tmp_buf_size_t nvxcuHarrisCorners_GetBufSize(uint32_t width, uint32_t height,
                                                             nvxcu_df_image_e format,
                                                             float min_distance,
                                                             int32_t gradient_size,
                                                             int32_t block_size,
                                                             nvxcu_array_item_type_e arr_type, uint32_t arr_capacity,
                                                             const nvxcu_border_t* border,
                                                             const struct cudaDeviceProp* prop);

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Computes the Harris Corners of an image.
 *
 * \details The Harris Corners are computed with the following parameters
 * \f{eqnarray}{
 * I &=& \text{input} \\
 * T_c &=& \text{strength_thresh} \\
 * r &=& \text{min_distance} \\
 * k &=& \text{sensitivity} \\
 * w &=& \text{gradient_size} \\
 * b &=& \text{block_size} \\
 * \f}
 * The main computation steps to find the corner values are summarized as:
 * \f{eqnarray}{
 * G_x &=& Sobel_x(w, I) \\
 * G_y &=& Sobel_y(w, I) \\
 * A &=& window_{G_{x,y}}(x-b/2,y-b/2,x+b/2,y+b/2) \\
 * trace(A) &=& \sum^{A}{G_x^{2}} + \sum^{A}{G_y^{2}} \\
 * det(A) &=& \sum^{A}{G_x^{2}} \sum^{A}{G_y^{2}} - {\left(\sum^{A}{(G_x G_y)}\right)}^{2} \\
 * M_c(x,y) &=& det(A) - k*trace(A)^{2} \\
 * V_c(x,y) &=& \begin{cases}
 *                 M_c(x,y) \text{ if } M_c(x,y) > T_c \\
 *                 0 \text{ otherwise} \\
 *              \end{cases}
 * \f}
 * \f[
 * \text{where } V_c \text{ is the thresholded corner value}.
 * \f]
 * The normalized gradient Sobel kernels are:
 * \arg For \e gradient_size = 3:
 * \f[
 * \mathbf{Sobel}_{x}(Normalized)=
 * \frac{1}{4*255*b}*
 * \begin{vmatrix}
 *   -1 & 0 & 1\\
 *   -2 & 0 & 2\\
 *   -1 & 0 & 1
 * \end{vmatrix}
 * \f]
 * \f[
 * \mathbf{Sobel}_{y}(Normalized)=
 * \frac{1}{4*255*b}*({sobel}_{x})\prime=
 * \frac{1}{4*255*b}*
 * \begin{vmatrix}
 *   -1 & -2 & -1\\
 *    0 & 0 & 0\\
 *    1 & 2 & 1
 * \end{vmatrix}
 * \f]
 * \arg For \e gradient_size = 5:
 * \f[
 * \mathbf{Sobel}_{x}(Normalized)=
 * \frac{1}{16*255*b}*
 * \begin{vmatrix}
 *   -1 & -2 &  0 & 2 &  1\\
 *   -4 & -8 &  0 & 8 &  4\\
 *   -6 & -12 & 0 & 12 & 6\\
 *   -4 & -8 &  0 & 8 &  4\\
 *   -1 & -2 &  0 & 2 &  1\\
 * \end{vmatrix}
 * \f]
 *
 * \f[
 * \mathbf{Sobel}_{y}(Normalized)=
 * \frac{1}{16*255*b}*({sobel}_{x})\prime
 * \f]
 *
 * \arg For \e gradient_size = 7:
 * \f[
 * \mathbf{Sobel}_{x}(Normalized)=
 * \frac{1}{64*255*b}*
 * \begin{vmatrix}
 *   -1  &  -4 & -5 &   0 &   5 &  4 &  1\\
 *   -6  & -24 & -30 &  0 &  30 & 24 &  6\\
 *   -15 & -60 & -75 &  0 &  75 & 60 & 15\\
 *   -20 & -80 & -100 & 0 & 100 & 80 & 20\\
 *   -15 & -60 & -75 &  0 &  75 & 60 & 15\\
 *   -6  & -24 & -30 &  0 &  30 & 24 &  6\\
 *   -1  &  -4 & -5 &   0 &   5 &  4 &  1\\
 * \end{vmatrix}
 * \f]
 *
 * \f[
 * \mathbf{Sobel}_{y}(Normalized)=
 * \frac{1}{64*255*b}*({sobel}_{x})\prime
 * \f]
 *
 * \f$ V_c \f$ , the thresholded corner value, is then non-maximally suppressed using the following algorithm:
 * - Filter the features using the non-maximum suppression algorithm.
 * - Create an array of features sorted by \f$ V_c \f$ in descending order: \f$V_c(j) > V_c(j+1)\f$.
 * - Initialize an empty feature set \f$F = \{\}\f$
 * - For each feature \f$j\f$ in the sorted array, while \f$V_c(j) > T_c\f$:
 *    - If there is no feature i in \f$F\f$ such that the Euclidean distance between pixels i and j is less than \f$r\f$, add the feature \f$j\f$ to the feature set \f$F\f$.

 * An implementation shall support all values of Euclidean distance \f$ r \f$ that satisfy:
 * <pre> 0 <= r <= 30 </pre>
 * The feature set \f$F\f$, detected \e corners, is returned as a \ref NVXCU_TYPE_KEYPOINT or
 * \ref NVXCU_TYPE_KEYPOINTF or \ref NVXCU_TYPE_POINT2F item type.
 *
 * \param [in]  input                   Specifies the input image.
 *                                          It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                          Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  strength_thresh         Specifies the minimum threshold with which to eliminate Harris Corner scores
 *                                          (computed using the normalized Sobel kernel).
 * \param [in]  min_distance            Specifies the radial Euclidean distance for non-maximum suppression.
 * \param [in]  sensitivity             Specifies sensitivity threshold \f$ k \f$ from the Harris-Stephens equation.
 * \param [in]  gradient_size           Specifies the gradient window size.
 *                                          It must be 3, 5 or 7.
 * \param [in]  block_size              Specifies the block window size used to compute the Harris Corner score.
 *                                          It must be 3, 5 or 7.
 * \param [out] corners                 Specifies the output array.
 *                                          It must have \ref NVXCU_TYPE_KEYPOINT or \ref NVXCU_TYPE_KEYPOINTF or \ref NVXCU_TYPE_POINT2F item type.
 *                                          Only \ref nvxcu_plain_array_t is supported.
 * \param [out] num_corners_dev_ptr     Specifies CUDA device pointer to the total number of detected corners.
 * \param [in]  tmp_buf                 Specifies the pointers to temporary buffers.
 *                                          Use \ref nvxcuHarrisCorners_GetBufSize to get size of the buffers.
 * \param [in]  border                  Specifies the border extrapolation mode.
 *                                          Support for non-zero constant border mode is planned to be removed in future releases
 *                                          as it brings additional complexity to the VisionWorks CUDA API.
 * \param [in]  exec_target             Specifies the execution target.
 *                                          Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuHarrisCorners(const nvxcu_image_t* input,
                                                  float strength_thresh,
                                                  float min_distance,
                                                  float sensitivity,
                                                  int32_t gradient_size,
                                                  int32_t block_size,
                                                  const nvxcu_array_t* corners,
                                                  uint32_t *num_corners_dev_ptr,
                                                  const nvxcu_tmp_buf_t* tmp_buf,
                                                  const nvxcu_border_t* border,
                                                  const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// FastCorners
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Determine the size of CUDA Device and HOST memory that must be passed to the \ref nvxcuFastCorners primitive.
 *
 * \see \ref nvxcu_tmp_buf_size_t
 *
 * \param [in] width                Specifies the width of the input image.
 * \param [in] height               Specifies the height of the input image.
 * \param [in] format               Specifies the format of the input image.
 * \param [in] nonmax_suppression   Specifies boolean flag that indicates whether to apply non-maximum suppression.
 * \param [in] arr_type             Specifies the output array item type.
 * \param [in] arr_capacity         Specifies the output array capacity.
 * \param [in] border               Specifies the border extrapolation mode.
 * \param [in] prop                 Specifies the CUDA device properties for current active device.
 *
 * \return The size of temporary CUDA Device and HOST buffers.
 */
NVX_C_API nvxcu_tmp_buf_size_t nvxcuFastCorners_GetBufSize(uint32_t width, uint32_t height,
                                                           nvxcu_df_image_e format,
                                                           int32_t nonmax_suppression,
                                                           nvxcu_array_item_type_e arr_type, uint32_t arr_capacity,
                                                           const nvxcu_border_t* border,
                                                           const struct cudaDeviceProp* prop);

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Computes the corners in an image using a method based upon FAST9 algorithm base on
 * \cite rosten_2006_machine and \cite rosten_2008_faster with some modifications described below.
 * \details
 * The FAST corner detector uses pixels on the Bresenham circle around a candidate point to classify
 * whether the candidate point @f$ p @f$ is actually a corner.
 * If \f$ N \f$ contiguous pixels are brighter than the candidate point by at least a threshold value \f$ t \f$
 * (a input parameter \e strength_thresh) or darker by at least \f$ t \f$ , then the candidate
 * point is considered to be a corner.
 * If non-maximum suppression flag is turned on, corner strengths are computed for the detected corners,
 * and they are used to remove multiple or spurious corner responses.
 *
 * \section sec_nvxcu_seg_test_detector NVXCU Segment Test Detector
 *
 * In FAST corner detection, a candidate pixel \f$ p \f$ is detected as a corner or not based on its
 * value and the pixel values on its radius-3 Bresenham circle (16 pixels), given the following
 * parameters.
 *
 * \f{eqnarray}{
 *    I   &=& \text{ input image }                                                                  \\
 *    p   &=& \text{ candidate point position for a corner }                                        \\
 *    I_p &=& \text{ image intensity of the candidate point in image } I                            \\
 *    x   &=& \text{ pixel on the Bresenham circle around the candidate point } p                   \\
 *    I_x &=& \text{ image intensity of the candidate point }                                       \\
 *    t   &=& \text{ intensity difference threshold for a corner, strength_thresh}                                  \\
 *    N   &=& \text{ minimum number of contiguous pixel to detect a corner }                        \\
 *    S   &=& \text{ set of contiguous pixel on the Bresenham circle around the candidate point  }  \\
 *    C_p &=& \text{ corner response at corner location } p                                         \\
 * \f}
 *
 * There are two conditions in FAST corner detection:
 * \arg  C1: A set of \f$ N \f$ contiguous pixels \f$ S \f$, \f$ \forall x \f$ in \f$ S \f$, \f$ I_{x} > I_{p} + t \f$
 * \arg  C2: A set of \f$ N \f$ contiguous pixels \f$ S \f$, \f$ \forall x \f$ in \f$ S \f$, \f$ I_{x} < I_{p} - t \f$
 *
 * If either of the two conditions is true, the candidate pixel \f$ p \f$ is detected as a corner.
 *
 * In this implementation, the minimum number of contiguous pixels \f$ N \f$ is set to 9 (FAST9).
 *
 * The value of the intensity difference threshold \a strength_thresh.
 * of type <tt>\ref NVXCU_TYPE_FLOAT32</tt>  must be within:
 * \f[
 * {UINT8_{MIN}} <  t < {UINT8_{MAX}}
 * \f]
 * These limits are established due to the input data type <tt>\ref NVXCU_DF_IMAGE_U8</tt>.
 *
 * <H3> Corner Strength Computation </H3>
 *
 * If the \e nonmax_suppression input parameter is true, corner strengths (responses) shall be computed for the detected corners.
 * Otherwise, the corner strengths is undefined.
 * The corner strength (response) \f$ C_p \f$ function is defined as the largest threshold \f$ t \f$
 * for which the pixel \f$ p \f$ remains a corner.
 *
 * <H3> Non-maximum suppression </H3>
 *
 * If the \e nonmax_suppression parameter is true, the detected corners are filtered by
 * a non-maxima suppression step. The corner with
 * coordinates \f$(x,y)\f$ is kept if and only if
 * \f{eqnarray*}{
 * C_p(x,y) \geq C_p(x-1,y-1) \; and \; C_p(x,y) \geq C_p(x,y-1) \; and \\ C_p(x,y) \geq C_p(x+1,y-1) \; and \; C_p(x,y) \geq C_p(x-1,y) \; and \\
 * C_p(x,y) > C_p(x+1,y) \; and \; C_p(x,y) >C_p(x-1,y+1) \; and \\
 * C_p(x,y) >C_p(x,y+1) \; and \; C_p(x,y) >C_p(x+1,y+1)
 * \f}
 *
 * \see http://www.edwardrosten.com/work/fast.html
 * \see http://en.wikipedia.org/wiki/Features_from_accelerated_segment_test
 *
 * \param [in]  input                   Specifies the input image.
 *                                          It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                          Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  strength_thresh         Specifies the threshold on difference between intensity of the central pixel
 *                                          and pixels on Bresenham's circle of radius 3.
 * \param [in]  nonmax_suppression      Specifies boolean flag that indicates whether to apply non-maximum suppression.
 * \param [out] corners                 Specifies the output array.
 *                                          It must have \ref NVXCU_TYPE_KEYPOINT or \ref NVXCU_TYPE_KEYPOINTF or \ref NVXCU_TYPE_POINT2F item type.
 *                                          Only \ref nvxcu_plain_array_t is supported.
 * \param [out] num_corners_dev_ptr     Specifies CUDA device pointer to the total number of detected corners.
 * \param [in]  tmp_buf                 Specifies the pointers to temporary buffers.
 *                                          Use \ref nvxcuFastCorners_GetBufSize to get size of the buffers.
 * \param [in]  border                  Specifies the border extrapolation mode.
 *                                          Support for non-zero constant border mode is planned to be removed in future releases
 *                                          as it brings additional complexity to the VisionWorks CUDA API.
 * \param [in]  exec_target             Specifies the execution target.
 *                                          Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuFastCorners(const nvxcu_image_t* input,
                                                float strength_thresh,
                                                int32_t nonmax_suppression,
                                                const nvxcu_array_t* corners,
                                                uint32_t *num_corners_dev_ptr,
                                                const nvxcu_tmp_buf_t* tmp_buf,
                                                const nvxcu_border_t* border,
                                                const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// OpticalFlowPyrLK
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Determine the size of CUDA Device and HOST memory that must be passed to the \ref nvxcuOpticalFlowPyrLK primitive.
 *
 * \see \ref nvxcu_tmp_buf_size_t
 *
 * \param [in] width                Specifies the width of the first level of the input image pyramid.
 * \param [in] height               Specifies the height of the first level of the input image pyramid.
 * \param [in] levels               Specifies the number of levels in the input image pyramid.
 * \param [in] scale                Specifies the input pyramid's scale factor.
 * \param [in] arr_type             Specifies the output array item type.
 * \param [in] capacity             Specifies the output array capacity.
 * \param [in] window_dimension     Specifies the size of the window on which to perform the algorithm.
 * \param [in] calcError            Specifies the boolean flag that indicates whether to calculate tracking error.
 * \param [in] border               Specifies the border extrapolation mode.
 * \param [in] prop                 Specifies the CUDA device properties for current active device.
 *
 * \return The size of temporary CUDA Device and HOST buffers.
 */
NVX_C_API nvxcu_tmp_buf_size_t nvxcuOpticalFlowPyrLK_GetBufSize(uint32_t width, uint32_t height, uint32_t levels, float scale,
                                                                nvxcu_array_item_type_e arr_type, uint32_t capacity,
                                                                uint32_t window_dimension,
                                                                int32_t calcError,
                                                                const nvxcu_border_t* border,
                                                                const struct cudaDeviceProp* prop);
/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Computes the optical flow between two pyramid images using the Lucas-Kanade method.
 * \details This kernel implements the algorithm described in \cite Bouguet2000.
 * The function inputs are an old <tt>\ref nvxcu_pyramid_t</tt> object, a new <tt>\ref nvxcu_pyramid_t</tt> object,
 * and a <tt>\ref nvxcu_array_t</tt> of <tt>\ref nvxcu_keypoint_t</tt> structs
 * to track associated with the old <tt>\ref nvxcu_pyramid_t</tt>. It produces a new <tt>\ref nvxcu_array_t</tt>
 * of <tt>\ref nvxcu_keypoint_t</tt> structs tracked from the old <tt>\ref nvxcu_pyramid_t</tt> to
 * the new <tt>\ref nvxcu_pyramid_t</tt>. Each <tt>\ref nvxcu_keypoint_t</tt> struct
 * in the new <tt>\ref nvxcu_array_t</tt> may be valid or not. The implementation shall return the same
 * number of elements in the new <tt>\ref nvxcu_array_t</tt> that
 * were tracked from the older <tt>\ref nvxcu_array_t</tt>.
 *
 * In more detail:
 * The Lucas-Kanade method finds the affine motion vector \f$ V \f$ for each
 * key point in the old image array, using the following equation:
 * \f[
 * \begin{bmatrix}
 * V_x \\
 * V_y
 * \end{bmatrix} =
 * \begin{bmatrix}
 * \sum_{i}{I_x}^2 & \sum_{i}{I_x*I_y} \\
 * \sum_{i}{I_x*I_y} & \sum_{i}{I_y}^2
 * \end{bmatrix}^{-1}
 * \begin{bmatrix}
 * -\sum_{i}{I_x*I_t} \\
 * -\sum_{i}{I_y*I_t}
 * \end{bmatrix}
 * \f]
 * Where \f$ I_x \f$ and \f$ I_y \f$ are computed using the Scharr gradients on the old image:
 * \f[
 * G_x = \begin{bmatrix}
 *  +3 & 0 & -3 \\
 * +10 & 0 & -10 \\
 *  +3 & 0 & -3
 * \end{bmatrix}
 * \f]
 *
 * \f[
 * G_y = \begin{bmatrix}
 * +3 & +10 & +3 \\
 *  0 &   0 &  0 \\
 * -3 & -10 & -3
 * \end{bmatrix}
 * \f]
 * where \f$ I \f$ is defined as the adjacent pixels to the point
 * \f$ p(x,y) \f$ under consideration. With a given window size of \f$ M \f$,
 * \f$ I \f$ has \f$ M^2 \f$ points and the pixel \f$ p(x,y) \f$ is centered in the window..
 * \f$ I_t \f$ is obtained by a simple difference between the same pixels in
 * both images.
 *
 * In practice, to get an accurate solution, it is necessary to iterate
 * multiple times on this scheme (in a Newton-Raphson fashion) until:
 * - The delta of the affine motion vector between two iterations is smaller than a threshold
 * - And/or it reaches the maximum number of iterations.
 *
 * Each iteration, \f$ I_t \f$ is updated to be the difference
 * between the old image and the pixel shifted with the estimated \f$ V \f$ in the new image.
 * At each iteration, the function needs to check if the tracking point was lost.
 * The criteria for a lost tracking are
 * - The matrix above is not invertible. (The determinant of the matrix is less than
 * a threshold : \f$ 10^{-7} \f$ .)
 * - The minimum eigenvalue of the matrix is smaller then a threshold ( \f$ 10^{-4} \f$ ).
 * - The point tracked coordinate is outside the image coordinates.
 *
 * Clients are responsible for updating the output <tt>\ref nvxcu_array_t</tt> of
 * <tt>\ref nvxcu_keypoint_t</tt> structs array before applying it as the
 * input to the next frame.
 * For example, <tt>\ref nvxcu_keypoint_t</tt> structs with <tt>tracking_status</tt> set to zero
 * may be removed by a client for efficiency.
 *
 * This function updates just the \a x, \a y, and \a tracking_status
 * members of the <tt>\ref nvxcu_keypoint_t</tt> structure and behaves as if it copied the rest from the
 * old tracking <tt>\ref nvxcu_keypoint_t</tt> to new tracking <tt>\ref nvxcu_keypoint_t</tt>.
 *
 * \param [in]     old_images           Specifies the input of first (old) image pyramid.
 *                                          It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                          Only \ref nvxcu_pitch_linear_pyramid_t is supported.
 * \param [in]     new_images           Specifies the input of destination (new) image pyramid.
 *                                          It must have the same size and format as \p old_images.
 *                                          Only \ref nvxcu_pitch_linear_pyramid_t is supported.
 * \param [in]     old_points           Specifies an array of keypoints in the \p old_images high resolution pyramid.
 *                                          It must have \ref NVXCU_TYPE_KEYPOINT or \ref NVXCU_TYPE_KEYPOINTF or \ref NVXCU_TYPE_POINT2F item type.
 *                                          Only \ref nvxcu_plain_array_t is supported.
 * \param [in,out] new_points           Specifies an array of keypoints in the \p new_images high resolution pyramid.
 *                                          It must contain initial estimation.
 *                                          It must have the same item type as \p old_points.
 *                                          It must have capacity greater than or equal to capacity of the \p old_points.
 *                                          Only \ref nvxcu_plain_array_t is supported.
 * \param [in]     termination          Specifies the termination criteria.
 * \param [in]     epsilon              Specifies the error for terminating the algorithm.
 * \param [in]     num_iterations       Specifies the number of iterations.
 * \param [in]     window_dimension     Specifies the size of the window on which to perform the algorithm.
 *                                          It must be greater than or equal to 3 and less than or equal to 32.
 * \param [in]     calcError            Specifies the boolean flag that indicates whether to calculate tracking error.
 * \param [in]     tmp_buf              Specifies the pointers to temporary buffers.
 *                                          Use \ref nvxcuOpticalFlowPyrLK_GetBufSize to get size of the buffers.
 * \param [in]     border               Specifies the border extrapolation mode.
     *                                      \ref NVXCU_BORDER_MODE_CONSTANT with non-zero border value is not supported.
 * \param [in]     exec_target          Specifies the execution target.
 *                                          Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuOpticalFlowPyrLK(const nvxcu_pyramid_t* old_images,
                                                     const nvxcu_pyramid_t* new_images,
                                                     const nvxcu_array_t* old_points,
                                                     const nvxcu_array_t* new_points,
                                                     nvxcu_termination_criteria_e termination,
                                                     float epsilon,
                                                     uint32_t num_iterations,
                                                     uint32_t window_dimension,
                                                     int32_t calcError,
                                                     const nvxcu_tmp_buf_t* tmp_buf,
                                                     const nvxcu_border_t* border,
                                                     const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// FlipImage
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Flips the input image in horizontal, vertical or in both directions.
 * \details
 * @f[
 * dst(y, x) =
 *   \left\{
 *   \begin{array}{l l}
 *   src(height - y - 1, x) & if\;  flip\_mode = NVX\_FLIP\_VERTICAL \\
 *   src(y, width - x - 1) & if\;  flip\_mode = NVX\_FLIP\_HORIZONTAL \\
 *   src(height - y - 1, width - x - 1) & if\;  flip\_mode = NVX\_FLIP\_BOTH \\
 *   \end{array}
 *   \right.
 * @f]
 *
 * \param [in]  input           Specifies the input image.
 *                                  Supported formats: \ref NVXCU_DF_IMAGE_U8, \ref NVXCU_DF_IMAGE_RGB, \ref NVXCU_DF_IMAGE_RGBX.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] output          Specifies the output image.
 *                                  It must have the same size and format as \p input.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  flip_mode       Specifies the flipping mode.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuFlipImage(const nvxcu_image_t* input,
                                              const nvxcu_image_t* output,
                                              nvxcu_flip_mode_e flip_mode,
                                              const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// HarrisTrack
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Determine the size of CUDA Device and HOST memory that must be passed to the \ref nvxcuHarrisTrack primitive.
 *
 * \see \ref nvxcu_tmp_buf_size_t
 *
 * \param [in] width            Specifies the width of the input image.
 * \param [in] height           Specifies the height of the input image.
 * \param [in] format           Specifies the format of the input image.
 * \param [in] arr_type         Specifies the output array item type.
 * \param [in] arr_capacity     Specifies the output array capacity.
 * \param [in] cell_size        Specifies the size of cells for cell-based non-max suppression.
 * \param [in] prop             Specifies the CUDA device properties for current active device.
 *
 * \return The size of temporary CUDA Device and HOST buffers.
 */
NVX_C_API nvxcu_tmp_buf_size_t nvxcuHarrisTrack_GetBufSize(uint32_t width, uint32_t height, nvxcu_df_image_e format,
                                                           nvxcu_array_item_type_e arr_type, uint32_t arr_capacity,
                                                           uint32_t cell_size,
                                                           const struct cudaDeviceProp* prop);

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Detects and tracks Harris corners for the input image.
 * \details
 * @par Corners classification
 *
 * This kernel computes a gradient covariance matrix for each pixel within
 * a @f$ blockSize \times blockSize @f$ window:
 * @f{eqnarray}{
 * G &=& \frac{blockSize}{2} \\
 * A(y, x) &=& \sum\limits_{v=-G}^G \sum\limits_{u=-G}^G (f_x(y + v, x + u))^2 \cdot w(v, u) \\
 * B(y, x) &=& \sum\limits_{v=-G}^G \sum\limits_{u=-G}^G (f_y(y + v, x + u))^2 \cdot w(v, u) \\
 * C(y, x) &=& \sum\limits_{v=-G}^G \sum\limits_{u=-G}^G f_x(y + v, x + u) \cdot f_y(y + v, x + u) \cdot w(v, u)
 * @f}
 *
 * Then, it computes the following characteristics of the matrix:
 * @f{eqnarray}{
 * trace(M(y, x)) &=& A(y, x) + B(y, x) \\
 * det(M(y, x)) &=& A(y, x) \cdot B(y, x) - C(y, x)^2 \\
 * H(y, x) &=& det(M(y, x)) - k  \cdot trace(M(y, x))^2
 * @f}
 *
 * A candidate pixel is classified as a corner, if its @f$ H(y, x) @f$ characteristic
 * is greater than the specified \e threshold.
 *
 * Optionally, a input mask image can be used to filter out corners from
 * specified regions. The primitive only handles pixels with a non-zero
 * mask value.
 *
 * @par Cell-based Non-max Suppression
 *
 * A cell-based, non-max suppression step is performed
 * on all detected corners to remove multiple or spurious responses.
 *
 * The input image is split into cells (\e cell_size is an input parameter),
 * and the corner with the highest @f$ H(y, x) @f$ characteristic is selected within each cell.
 * If there are several corners with the same @f$ H(y, x) @f$ the bottom-most right corner
 * is chosen.
 *
 * @par Tracking
 *
 * Additionally, this primitive can be used in the tracking scenario.
 * It accepts an optional tracked features list from optical flow.
 * The primitive extracts corners only for those cells
 * that do not contain any tracked points.
 *
 * The primitive applies cell-based, non-max suppressions for input
 * tracked points, too, so only non-lost points with the highest strength
 * are left per cell.
 *
 * \param [in]  input                   Specifies the input image.
 *                                          It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                          Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] output                  Specifies the output array of corners.
 *                                          Only \ref NVXCU_TYPE_KEYPOINT, \ref NVXCU_TYPE_KEYPOINTF and \ref NVXCU_TYPE_POINT2F item types are supported.
 *                                          Only \ref nvxcu_plain_array_t is supported.
 * \param [in]  mask                    [optional] Specifies the input mask image.
 *                                          It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                          It must have the same size as \p input.
 *                                          Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  tracked_points          [optional] Specifies the tracked features list.
 *                                          It must have the same item type as \p output.
 *                                          Only \ref nvxcu_plain_array_t is supported.
 * \param [in]  k                       Specifies the Harris K parameter.
 * \param [in]  threshold               Specifies the Harris threshold.
 * \param [in]  cell_size               Specifies the size of cells for cell-based non-max suppression.
 * \param [out] num_corners_dev_ptr     Specifies the CUDA device pointer to the total number of detected corners.
 * \param [in]  tmp_buf                 Specifies the pointers to temporary buffers.
 *                                          Use \ref nvxcuHarrisTrack_GetBufSize to get size of the buffers.
 * \param [in]  exec_target             Specifies the execution target.
 *                                          Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuHarrisTrack(const nvxcu_image_t* input,
                                                const nvxcu_array_t* output,
                                                const nvxcu_image_t* mask,
                                                const nvxcu_array_t* tracked_points,
                                                float k, float threshold, uint32_t cell_size,
                                                size_t *num_corners_dev_ptr,
                                                const nvxcu_tmp_buf_t* tmp_buf,
                                                const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// FastTrack
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Determine the size of CUDA Device and HOST memory that must be passed to the \ref nvxcuFastTrack primitive.
 *
 * \see \ref nvxcu_tmp_buf_size_t
 *
 * \param [in] width            Specifies the width of the input image.
 * \param [in] height           Specifies the height of the input image.
 * \param [in] format           Specifies the format of the input image.
 * \param [in] arr_type         Specifies the output array item type.
 * \param [in] arr_capacity     Specifies the output array capacity.
 * \param [in] cell_size        Specifies the size of cells for cell-based non-max suppression.
 * \param [in] prop             Specifies the CUDA device properties for current active device.
 *
 * \return The size of temporary CUDA Device and HOST buffers.
 */
NVX_C_API nvxcu_tmp_buf_size_t nvxcuFastTrack_GetBufSize(uint32_t width, uint32_t height, nvxcu_df_image_e format,
                                                         nvxcu_array_item_type_e arr_type, uint32_t arr_capacity,
                                                         uint32_t cell_size,
                                                         const struct cudaDeviceProp* prop);

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Detects and tracks corners using the FAST algorithm.
 * \details
 * @par Segment Test Detector
 *
 * The FAST detector extracts corners by evaluating pixels on the Bresenham circle
 * around a candidate point @f$ p @f$.
 *
 * Given the following parameters:
 *
 * - @f$ I @f$ - input image
 * - @f$ p @f$ - candidate point position for a corner
 * - @f$ I_p @f$ - image intensity of the candidate point @f$ p @f$ in image @f$ I @f$
 * - @f$ x @f$ - pixel on the Bresenham circle around the candidate point @f$ p @f$
 * - @f$ I_x @f$ - image intensity of the pixels on the Bresenham circle
 * - @f$ t @f$ - intensity difference threshold for a corner
 * - @f$ N @f$ - minimum number of contiguous pixel to detect a corner
 * - @f$ S @f$ - set of contiguous pixel on the Bresenham circle around the candidate point
 * - @f$ C_p @f$ - corner response at corner location @f$ p @f$
 *
 * There are two conditions for FAST corner detection:
 *
 * - C1: A set of @f$ N @f$ contiguous pixels @f$ S @f$, @f$ \forall x @f$
 *   in @f$ S @f$, @f$ I_{x} > I_{p} + t @f$
 * - C2: A set of @f$ N @f$ contiguous pixels @f$ S @f$, @f$ \forall x @f$
 *   in @f$ S @f$, @f$ I_{x} < I_{p} - t @f$
 *
 * If either of the two conditions is true, the candidate pixel \f$ p \f$ is detected as a corner.
 *
 * Optionally, a input mask image can be used to filter out corners from
 * specified regions. The primitive only handles pixels with a non-zero
 * mask value.
 *
 * @par Corner Strength Computation
 *
 * If a corner has been detected, corner strengths (response, saliency or score)
 * shall be computed for the detected corners.
 * The corner strength \f$ C_p \f$ function is defined as the largest possible threshold \f$ t \f$
 * that makes the pixel \f$ p \f$ remains a corner.
 *
 * @par Cell-based Non-max Suppression
 *
 * A cell-based, non-max suppression step is performed
 * on all detected corners to remove multiple or spurious responses.
 *
 * The input image is split into cells (\e cell_size is an input parameter),
 * and the corner with the highest strength is selected within each cell.
 * If there are several corners with the same strength the bottom-most right corner
 * is chosen.
 *
 * @par Tracking
 *
 * Additionally, the kernel can be used in tracking scenarios.
 * It accepts an optional tracked features list from optical flow.
 * The primitive extracts corners only for those cells
 * that do not contain any tracked points.
 *
 * The primitive applies cell-based, non-max suppressions for input
 * tracked points, too, so only non-lost points with the highest strength
 * are left per cell.
 *
 * @see @cite Rosten06 and @cite Rosten08 for a detailed description of the algorithm.
 *
 * \param [in]  input                   Specifies the input image.
 *                                          It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                          Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] output                  Specifies the output array of corners.
 *                                          Only \ref NVXCU_TYPE_KEYPOINT, \ref NVXCU_TYPE_KEYPOINTF and \ref NVXCU_TYPE_POINT2F item types are supported.
 *                                          Only \ref nvxcu_plain_array_t is supported.
 * \param [in]  mask                    [optional] Specifies the input mask image.
 *                                          It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                          It must have the same size as \p input.
 *                                          Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  tracked_points          [optional] Specifies the tracked features list.
 *                                          It must have the same item type as \p output.
 *                                          Only \ref nvxcu_plain_array_t is supported.
 * \param [in]  type                    Specifies the number of neighborhoods to test.
 *                                          Supported values : 9, 10, 11, 12.
 * \param [in]  threshold               Specifies the threshold on difference between intensity of the central pixel
 *                                          and pixels of a circle around this pixel.
 *                                          The \p threshold value should be less than 255.
 * \param [in]  cell_size               Specifies the size of cells for cell-based non-max suppression.
 * \param [out] num_corners_dev_ptr     Specifies the CUDA device pointer to the total number of detected corners.
 * \param [in]  tmp_buf                 Specifies the pointers to temporary buffers.
 *                                          Use \ref nvxcuFastTrack_GetBufSize to get size of the buffers.
 * \param [in]  exec_target             Specifies the execution target.
 *                                          Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuFastTrack(const nvxcu_image_t* input,
                                              const nvxcu_array_t* output,
                                              const nvxcu_image_t* mask,
                                              const nvxcu_array_t* tracked_points,
                                              uint32_t type, uint32_t threshold, uint32_t cell_size,
                                              size_t *num_corners_dev_ptr,
                                              const nvxcu_tmp_buf_t* tmp_buf,
                                              const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// MultiplyByScalar
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Multiplies an input image by scalar and optionally converts it to another data type.
 * \details To avoid overflow issues, saturate conversion policy is applied after the multiplication.
 *
 * \f[
 * dst(x,y) = saturate<dstType>(\alpha \cdot src(x,y))
 * \f]
 *
 * The table below shows the supported input/output data types. The row indicates the input
 * and the columns indicate the output.
 *
 * | I/O  | 2S16 |
 * |:-----|:----:|
 * | 2S16 |  X   |
 * | 2F32 |  X   |
 *
 * \param [in]  src             Specifies the input image.
 *                                  It must have \ref NVXCU_DF_IMAGE_2S16 format.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] dst             Specifies the output image.
 *                                  It must have the same size as \p src.
 *                                  It must have \ref NVXCU_DF_IMAGE_2S16 or \ref NVXCU_DF_IMAGE_2F32 format.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  alpha           Specifies the \f$ \alpha \f$ coefficient.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuMultiplyByScalar(const nvxcu_image_t* src,
                                                     const nvxcu_image_t* dst,
                                                     float alpha,
                                                     const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// CreateMotionField
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Creates initial motion field from a current image into reference image.
 * \details
 * This kernel computes block-based sum-of-absolute-difference (SAD) value
 * within a search window between the current image and a reference image.
 * The best two motion vectors are selected based a cost function
 * to represent the displacement of the specified block into the reference image.
 *
 * The computed SADs are optionally stored to a look-up table for all positions in
 * the \f$ SW \times SH \f$ search window;
 * the look-up table can be used in the Iterative Motion Estimation algorithm to avoid motion
 * vector recomputation.
 *
 * For each \f$ B \times B \f$ block on the reference image, the function checks all positions
 * in the \f$ SW \times SH \f$ search window on current image and calculates the cost value
 *
 * \f[
 * cost(MV) = SAD(MV) + biasWeight * dist(MV, bias)
 * \f]
 *
 * \image html create_motion_field_cost.png
 *
 * Then the best motion vectors with minimum cost values are picked from each subregion
 * \f$ (0), (1,2), (3), (4, 8), (5, 6, 9, 10), (7, 11), (12), (13, 14), (15) \f$
 * in the search window:
 *
 * \image html create_motion_field_regions.png
 *
 * Finally, two best motion vectors from different subregions are picked so that
 *
 * \f[
 * dist(MV0, MV1) >= mvDivFactor
 * \f]
 *
 * \param [in]  ref_image               Specifies the reference image.
 *                                          It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                          Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  cur_image               Specifies the current image.
 *                                          It must have the same size as \p ref_image.
 *                                          Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  anchor                  [optional] Specifies the anchor field.
 *                                          It must have \f$ [W / B, H / B] \f$ size, where
 *                                          \f$ W \times H \f$ - \p ref_image size and \f$ B \f$ - block size.
 *                                          For each \f$ B \times B \f$ block on \p ref_image the \p anchor image
 *                                          contains an offset of search window on \p cur_image in Q14.2 format (\ref NVXCU_DF_IMAGE_2S16).
 *                                          If the \p anchor parameter is missed, it is assumed that
 *                                          the offset is zero for all blocks.
 *                                          Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  bias                    [optional] Specifies the bias field.
 *                                          It must have \f$ [W / B, H / B] \f$ size, where
 *                                          \f$ W \times H \f$ - \p ref_image size and \f$ B \f$ - block size.
 *                                          For each \f$ B \times B \f$ block on \p ref_image the \p bias image
 *                                          contains a bias vector for cost calculation in Q14.2 format (\ref NVXCU_DF_IMAGE_2S16).
 *                                          If the \p bias parameter is missed, it is assumed that
 *                                          the bias vector is zero for all blocks.
 *                                          Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] best_mv0                [optional] Specifies the output image of the best motion vectors.
 *                                          It must have \f$ [W / B, H / B] \f$ size, where
 *                                          \f$ W \times H \f$ - \p ref_image size and \f$ B \f$ - block size.
 *                                          The motion vectors will be stored in Q14.2 format (\ref NVXCU_DF_IMAGE_2S16).
 *                                          Can be NULL if the primitive is used for SAD table calculation only.
 *                                          Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] best_mv1                [optional] Specifies the output image of the second best motion vectors.
 *                                          It must have \f$ [W / B, H / B] \f$ size, where
 *                                          \f$ W \times H \f$ - \p ref_image size and \f$ B \f$ - block size.
 *                                          The motion vectors will be stored in Q14.2 format (\ref NVXCU_DF_IMAGE_2S16).
 *                                          Can be NULL if the primitive is used for SAD table calculation only.
 *                                          Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] sad_table               [optional] Specifies the optional output image with SAD table.
 *                                          It must have \f$ [W / B * SW * SH, H / B] \f$ size, where
 *                                          \f$ W \times H \f$ - \p ref_image size,  \f$ SW \times SH \f$ - search window size,
 *                                          and \f$ B \f$ - block size.
 *                                          For each \f$ B \times B \f$ block on \p ref_image and for each position in search window
 *                                          the \p sad_table image contains SAD (sum of absolute diferences) value
 *                                          for corresponding blocks in U32 format (\ref NVXCU_DF_IMAGE_U32).
 *                                          The values are stored contiguously, i.e., first \f$ SW * SH \f$ values
 *                                          corresponds to the first block. Search window is treated in row major order started from
 *                                          top left corner.
 *                                          Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  block_size              Specifies the block size.
 * \param [in]  search_window_width     Specifies the search window width.
 * \param [in]  search_window_height    Specifies the search window height.
 *                                          Supported search window sizes: 16x16, 32x32, 64x64, 64x32, 32x16 and 48x32.
 * \param [in]  bias_weight             Specifies the weight of bias term in cost formula.
 * \param [in]  mv_div_factor           Specifies the best motion vectors diversity factor.
 * \param [in]  exec_target             Specifies the execution target.
 *                                          Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuCreateMotionField(const nvxcu_image_t* ref_image,
                                                      const nvxcu_image_t* cur_image,
                                                      const nvxcu_image_t* anchor, // optional
                                                      const nvxcu_image_t* bias, // optional
                                                      const nvxcu_image_t* best_mv0, // optional
                                                      const nvxcu_image_t* best_mv1, // optional
                                                      const nvxcu_image_t* sad_table, // optional
                                                      int32_t block_size,
                                                      int32_t search_window_width, int32_t search_window_height,
                                                      float bias_weight,
                                                      int32_t mv_div_factor,
                                                      const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// RefineMotionField
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Determine the size of CUDA Device and HOST memory that must be passed to the \ref nvxcuRefineMotionField primitive.
 *
 * \see \ref nvxcu_tmp_buf_size_t
 *
 * \param [in] mv_width                 Specifies the input motion field width.
 * \param [in] mv_height                Specifies the input motion field height.
 * \param [in] search_window_width      Specifies the search window width.
 * \param [in] search_window_height     Specifies the search window height.
 * \param [in] prop                     Specifies the CUDA device properties for current active device.
 *
 * \return The size of temporary CUDA Device and HOST buffers.
 */
NVX_C_API nvxcu_tmp_buf_size_t nvxcuRefineMotionField_GetBufSize(uint32_t mv_width, uint32_t mv_height,
                                                                 int32_t search_window_width, int32_t search_window_height,
                                                                 const struct cudaDeviceProp* prop);

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Iteratively refines motion field by applying the motion vectors to a center block in a 3x3 block neighborhood.
 *
 * In this selection, the algorithm uses 14 motion vectors from the surrounding blocks,
 * excluding second best vectors from top left and bottom right corner blocks, and 2 motion vectors from center block.
 * The figure below illustrates the refinement stage iteration for a single block \f$ (i,j) \f$:
 *
 * \image html refine_motion_field.png
 *
 * Best motion vectors for the central block is selected by using a cost function
 * which takes in the SAD value of the block with this particular motion vector
 * and its Manhattan distance to motion vectors in the 3x3 block neighborhood.
 * The cost function used in assessing the best two motion vectors is as follows:
 *
 * \f[
 * cost(MV_{cur}) = SAD(MV_{cur}) + iter * smoothnessFactor * \sum_{MV} dist(MV_{cur}, MV)
 * \f]
 *
 * Local smoothness in the cost function is the sum of manhattan distance values
 * between the tested motion vector and all the motion vectors of the neighboring blocks.
 *
 * After going over 16 motion vectors in 3x3 neighborhood, the
 * best 2 motion vectors are kept as representative motion vectors for the current block, so that
 *
 * \f[
 * dist(MV0, MV1) >= mvDivFactor
 * \f]
 *
 * After each iteration, the motion vector of the candidate block get refined, as well as the
 * motion vectors of the neighboring blocks. This operation is repeated a few iterations to
 * produce a smoother motion field.
 *
 * The smoothness weight is increased in each iteration with the assumption
 * that the quality of the motion vectors are improved.
 *
 * \note The pre-calculated SAD look-up table from the
 * \ref nvxcuCreateMotionField kernel is used in this function.
 *
 * \param [in]  in_mv0                  Specifies the input motion field (first motion vectors).
 *                                          The motion vectors are assumed to be stored in Q14.2 format (\ref NVXCU_DF_IMAGE_2S16).
 *                                          Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  in_mv1                  Specifies the input motion field (second motion vectors).
 *                                          It must have the same size and format as \p in_mv0 image.
 *                                          Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  sad_table               Specifies the input image with SAD table.
 *                                          It must have \f$ [W * SW * SH, H] \f$ size, where
 *                                          \f$ W \times H \f$ - \p in_mv0 size and \f$ SW \times SH \f$ - search window size.
 *                                          The values are assumed to be stored in U32 format (\ref NVXCU_DF_IMAGE_U32).
 *                                          The SAD table can be obtained via \ref nvxcuCreateMotionField primitive.
 *                                          Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] out_mv0                 Specifies the output motion field (first motion vectors).
 *                                          It must have the same size and format as \p in_mv0 image.
 *                                          Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] out_mv1                 [optional] Specifies the output motion field (second motion vectors).
 *                                          It must have the same size and format as \p in_mv0 image.
 *                                          Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  search_window_width     Specifies the search window width.
 * \param [in]  search_window_height    Specifies the search window height.
 * \param [in]  num_iterations          Specifies the number of iterations.
 * \param [in]  smoothness_factor       Specifies the smoothness factor in cost formula.
 * \param [in]  mv_div_factor           Specifies the best motion vectors diversity factor.
 * \param [in]  tmp_buf                 Specifies the pointers to temporary buffers.
 *                                          Use \ref nvxcuRefineMotionField_GetBufSize to get size of the buffers.
 * \param [in]  exec_target             Specifies the execution target.
 *                                          Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuRefineMotionField(const nvxcu_image_t* in_mv0,
                                                      const nvxcu_image_t* in_mv1,
                                                      const nvxcu_image_t* sad_table,
                                                      const nvxcu_image_t* out_mv0,
                                                      const nvxcu_image_t* out_mv1, // optional
                                                      int32_t search_window_width, int32_t search_window_height,
                                                      int32_t num_iterations,
                                                      float smoothness_factor,
                                                      int32_t mv_div_factor,
                                                      const nvxcu_tmp_buf_t* tmp_buf,
                                                      const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// PartitionMotionField
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Partitions motion vector field for blocks onto motion vector field into quarter sized blocks (half size in each dimension).
 *
 * For example, partition motion field for \f$ 8 \times 8 \f$ blocks to motion field for \f$ 4 \times 4 \f$ blocks.
 *
 * As shown in the figure below, each quarter sized block has four large blocks as immediate neighbors.
 * Each large block contribute its best 2 motion vectors as candidates. So totally, 8 motion vectors
 * are used to derive the motion vector for the quarter sized block:
 *
 * \image html partition_motion_field.png
 *
 * The following cost function is used to evaluate the cost of the motion vector candidates:
 *
 * \f[
 * cost(MV_{cur}) = SAD(MV_{cur}) + smoothnessFactor * \sum_{MV} dist(MV_{cur}, MV)
 * \f]
 *
 * After evaluating all 8 motion vectors to the current quarter sized block,
 * the best 2 motion vectors satisfying the relation below are kept for the current block:
 *
 * \f[
 * dist(MV0, MV1) >= mvDivFactor
 * \f]
 *
 * \param [in]  ref_image           Specifies the reference image.
 *                                      It must have \ref NVXCU_DF_IMAGE_U8 format.
 *                                      Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  cur_image           Specifies the current image.
 *                                      It must have the same size and format as \p ref_image.
 *                                      Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  in_mv_0             Specifies the input motion field for bigger blocks (first motion vectors).
 *                                      The motion vectors are assumed to be stored in Q14.2 format (\ref NVXCU_DF_IMAGE_2S16).
 *                                      Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  in_mv_1             Specifies the input motion field for bigger blocks (second motion vectors).
 *                                      It must have the same size and format as \p in_mv_0 image.
 *                                      Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] out_mv_0            Specifies the output motion field for smaller blocks (first motion vectors).
 *                                      It must have the same format as \p in_mv_0 image.
 *                                      It must have twice larger size in each dimension than \p in_mv_0 image.
 *                                      Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] out_mv_1            [optional] Specifies the output motion field for smaller blocks (second motion vectors).
 *                                      It must have the same size and format as \p out_mv_0 image.
 *                                      Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  smoothness_factor   Specifies the smoothness factor in cost formula.
 * \param [in]  mv_div_factor       Specifies the best motion vectors diversity factor.
 * \param [in]  exec_target         Specifies the execution target.
 *                                      Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuPartitionMotionField(const nvxcu_image_t* ref_image,
                                                         const nvxcu_image_t* cur_image,
                                                         const nvxcu_image_t* in_mv_0,
                                                         const nvxcu_image_t* in_mv_1,
                                                         const nvxcu_image_t* out_mv_0,
                                                         const nvxcu_image_t* out_mv_1, // optional
                                                         float smoothness_factor,
                                                         int32_t mv_div_factor,
                                                         const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// StereoBlockMatching
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Determine the size of CUDA Device and HOST memory that must be passed to the \ref nvxcuStereoBlockMatching primitive.
 *
 * \see \ref nvxcu_tmp_buf_size_t
 *
 * \param [in] width            Specifies the input image width.
 * \param [in] height           Specifies the input image height.
 * \param [in] format           Specifies the input image format.
 * \param [in] win_size         Specifies the average window size for sum of absolute differences (SAD).
 * \param [in] max_disparity    Specifies the maximum possible disparity that is considered.
 * \param [in] prop             Specifies the CUDA device properties for current active device.
 *
 * \return The size of temporary CUDA Device and HOST buffers.
 */
NVX_C_API nvxcu_tmp_buf_size_t nvxcuStereoBlockMatching_GetBufSize(uint32_t width, uint32_t height, nvxcu_df_image_e format,
                                                                   uint32_t win_size,
                                                                   uint32_t max_disparity,
                                                                   const struct cudaDeviceProp* prop);

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Computes a dense disparity map for a given stereo pair.
 *
 * This kernel computes a dense disparity image for the input stereo image pair. It requires
 * rectified images as inputs.
 *
 * \par Method
 *
 * Block-based sum of absolute differences (SAD) is used to match the corresponding blocks
 * in the input images and find the optimal disparity in a range of [0 maxDisparity]. The block
 * size is \e win_size x \e win_size. The following equation is used to determine the optimal
 * disparity:
 * \f{eqnarray}{
 * D(y, x) &=& {argmin}_d {SAD (L(y, x), R(y, x - d))} \\
 * SAD (L(y, x), R(y, x - d)) &=& \sum_{k={-r}}^r \sum_{l={-r}}^r {abs(L(y+k, x+l) - R(y+k, x-d+l))}
 * \f}
 * where
 * \f[
 * r = \frac{win_size - 1}{2}
 * \f]
 *
 * \see \cite StereoBM
 *
 * \param [in]  left            Specifies the left image.
 *                                  Only \ref NVXCU_DF_IMAGE_U8 format is supported.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  right           Specifies the right image.
 *                                  It must have the same size and format as \a left.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] disp            Specifies the output disparity.
 *                                  Only \ref NVXCU_DF_IMAGE_U8 format is supported.
 *                                  It must have the same size as \a left.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  win_size        Specifies the average window size for sum of absolute differences (SAD).
 *                                  It must be an odd integer in range \f$ [3, 31] \f$.
 * \param [in]  max_disparity   Specifies the maximum possible disparity that is considered.
 *                                  It must be a positive integer not greater than 256 and divisible by 8.
 * \param [in]  tmp_buf         Specifies the pointers to temporary buffers.
 *                                  Use \ref nvxcuStereoBlockMatching_GetBufSize to get size of the buffers.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuStereoBlockMatching(const nvxcu_image_t* left,
                                                        const nvxcu_image_t* right,
                                                        const nvxcu_image_t* disp,
                                                        uint32_t win_size,
                                                        uint32_t max_disparity,
                                                        const nvxcu_tmp_buf_t* tmp_buf,
                                                        const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// SemiGlobalMatching
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Determine the size of CUDA Device and HOST memory that must be passed to the \ref nvxcuSemiGlobalMatching primitive.
 *
 * \see \ref nvxcu_tmp_buf_size_t
 *
 * \param [in] width            Specifies the input image width.
 * \param [in] height           Specifies the input image height.
 * \param [in] format           Specifies the input image format.
 * \param [in] minD             Specifies the minimum disparity value.
 * \param [in] maxD             Specifies the maximum disparity value.
 * \param [in] sad              Specifies the average window size for sum of absolute differences.
 * \param [in] ct_win_size      Specifies the census transform window size.
 * \param [in] flags            Specifies extra flags. It must be a bitwise OR combination of \ref nvxcu_sgm_flags_e values or
 *                                  `0` for default behavior.
 * \param [in] prop             Specifies the CUDA device properties for current active device.
 *
 * \return The size of temporary CUDA Device and HOST buffers.
 */
NVX_C_API nvxcu_tmp_buf_size_t nvxcuSemiGlobalMatching_GetBufSize(uint32_t width, uint32_t height, nvxcu_df_image_e format,
                                                                  int32_t minD, int32_t maxD,
                                                                  int32_t sad, int32_t ct_win_size, nvxcu_sgm_flags_e flags,
                                                                  const struct cudaDeviceProp* prop);

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Evaluates disparity given 2 stereo images using the SGM algorithm.
 * \details
 *
 * @see @cite SGBM2007
 *
 * \param [in]  left            Specifies the left stereo image.
 *                                  Only \ref NVXCU_DF_IMAGE_U8 format is supported.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 *                                  Width must be divisible by 4
 * \param [in]  right           Specifies the right stereo image.
 *                                  It must have the same size and format as \a left.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] disparity       Specifies the output disparity.
 *                                  It contains values from minD-1 to maxD (exclusive) represented in Q11.4 fixed point format.
 *                                  Only \ref NVXCU_DF_IMAGE_U16 format is supported.
 *                                  It must have the same size as \a left.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  minD            Specifies the minimum disparity value.
 * \param [in]  maxD            Specifies the maximum disparity value.
 * \param [in]  P1              Specifies the smoothness penalty.
 * \param [in]  P2              Specifies the discontiguous penalty.
 * \param [in]  sad             Specifies the average window size for sum of absolute differences (set to 1 for original SGM).
 * \param [in]  ct_win_size     Specifies the census transform window size.
 * \param [in]  hc_win_size     Specifies the hamming cost window size.
 * \param [in]  clip            Specifies clip value for cost (used to preserve overflow in cost function)
 * \param [in]  max_diff        Specifies maximum allowed difference (in integer pixel units) in the left-right disparity check.
 * \param [in]  uniqueness      Specifies margin in percentage by which the best (minimum) computed cost function value
 *                                  should “win” the second best value to consider the found match correct.
 * \param [in]  scanlines_mask  Specifies scan line directions. Any bit-OR of \ref nvxcu_scanline_e values is suitable.
 * \param [in]  flags           Specifies extra flags. It must be a bitwise OR combination of \ref nvxcu_sgm_flags_e values or
 *                                  `0` for default behavior.
 * \param [in]  tmp_buf         Specifies the pointers to temporary buffers.
 *                                  Use \ref nvxcuSemiGlobalMatching_GetBufSize to get size of the buffers.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuSemiGlobalMatching(const nvxcu_image_t* left,
                                                       const nvxcu_image_t* right,
                                                       const nvxcu_image_t* disparity,
                                                       int32_t minD,
                                                       int32_t maxD,
                                                       int32_t P1,
                                                       int32_t P2,
                                                       int32_t sad,
                                                       int32_t ct_win_size,
                                                       int32_t hc_win_size,
                                                       int32_t clip,
                                                       int32_t max_diff,
                                                       int32_t uniqueness,
                                                       nvxcu_scanline_e scanlines_mask,
                                                       nvxcu_sgm_flags_e flags,
                                                       const nvxcu_tmp_buf_t* tmp_buf,
                                                       const nvxcu_exec_target_t* exec_target);

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Determines the size of CUDA Device and HOST memory that must be passed
 * to the \ref nvxcuComputeCostBT primitive.
 *
 * \see \ref nvxcu_tmp_buf_size_t
 *
 * \param [in] width            Specifies the input image width.
 * \param [in] height           Specifies the input image height.
 * \param [in] format           Specifies the input image format.
 * \param [in] prop             Specifies the CUDA device properties for current active device.
 *
 * \return The size of temporary CUDA Device and HOST buffers.
 */
NVX_C_API nvxcu_tmp_buf_size_t nvxcuComputeCostBT_GetBufSize(uint32_t width, uint32_t height,
                                                             nvxcu_df_image_e format,
                                                             const struct cudaDeviceProp* prop);

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Compute Birchfield-Tomasi cost function.
 * \details  @see @cite SGBM2007
 *
 * \param [in]  left              Specifies the left stereo image.
 *                                    Only `NVXCU_DF_IMAGE_U8` format is supported.
 *                                    Only \ref nvxcu_pitch_linear_image_t is supported.
 *                                    Width must be divisible by 4
 * \param [in]  right             Specifies the right stereo image.
 *                                    It must have the same size and format as \a left.
 * \param [out] cost              Specifies the resulting cost.
 *                                    Only `NVXCU_DF_IMAGE_U8` format is
 *                                    supported.  It must have the size W*D x H,
 *                                    where W and H are the width and height of
 *                                    \a left, and D = maxD - minD.
 * \param [in]  minD              Specifies the minimum disparity value.
 * \param [in]  maxD              Specifies the maximum disparity value.
 * \param [in]  clip              Specifies the clipping factor for gradient component of the cost values.
 * \param [in]  tmp_buf           Specifies the pointers to temporary buffers.
 *                                    Use \ref nvxcuComputeCostBT_GetBufSize to get size of the buffers.
 * \param [in]  exec_target       Specifies the execution target.
 *                                    Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuComputeCostBT(const nvxcu_image_t* left,
                                                  const nvxcu_image_t* right,
                                                  const nvxcu_image_t* cost,
                                                  int32_t minD,
                                                  int32_t maxD,
                                                  int32_t clip,
                                                  const nvxcu_tmp_buf_t* tmp_buf,
                                                  const nvxcu_exec_target_t* exec_target);
/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Determines the size of CUDA Device and HOST memory that must be passed
 * to the \ref nvxcuComputeModifiedCostBT primitive.
 *
 * \see \ref nvxcu_tmp_buf_size_t
 *
 * \param [in] width            Specifies the input image width.
 * \param [in] height           Specifies the input image height.
 * \param [in] format           Specifies the input image format.
 * \param [in] prop             Specifies the CUDA device properties for current active device.
 *
 * \return The size of temporary CUDA Device and HOST buffers.
 */
NVX_C_API nvxcu_tmp_buf_size_t nvxcuComputeModifiedCostBT_GetBufSize(uint32_t width, uint32_t height,
                                                                     nvxcu_df_image_e format,
                                                                     const struct cudaDeviceProp* prop);

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Compute Modified Birchfield-Tomasi cost function. It is computed on
 * Sobel inputs instead of intensity information.
 *
 * \see \ref nvx_p_semiGlobalMatching
 *
 * \param [in]  left              Specifies the left stereo image.
 *                                    Only `NVXCU_DF_IMAGE_U8` format is supported.
 *                                    Only \ref nvxcu_pitch_linear_image_t is supported.
 *                                    Width must be divisible by 4
 * \param [in]  right             Specifies the right stereo image.
 *                                    It must have the same size and format as \a left.
 * \param [out] cost              Specifies the resulting cost.
 *                                    Only `NVXCU_DF_IMAGE_U8` format is
 *                                    supported.  It must have the size W*D x H,
 *                                    where W and H are the width and height of
 *                                    \a left, and D = maxD - minD.
 * \param [in]  minD              Specifies the minimum disparity value.
 * \param [in]  maxD              Specifies the maximum disparity value.
 * \param [in]  clip              Specifies the clipping factor for gradient component of the cost values.
 * \param [in]  tmp_buf           Specifies the pointers to temporary buffers.
 *                                    Use \ref nvxcuComputeCostBT_GetBufSize to get size of the buffers.
 * \param [in]  exec_target       Specifies the execution target.
 *                                    Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuComputeModifiedCostBT(const nvxcu_image_t* left,
                                                          const nvxcu_image_t* right,
                                                          const nvxcu_image_t* cost,
                                                          int32_t minD,
                                                          int32_t maxD,
                                                          int32_t clip,
                                                          const nvxcu_tmp_buf_t* tmp_buf,
                                                          const nvxcu_exec_target_t* exec_target);

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Convolve cost function before cost aggregation step.
 * \details @see @cite SGBM2007
 *
 * \param [in]  pixel_cost        Specifies the input cost volume.
 *                                    Only `NVXCU_DF_IMAGE_U8` format is supported.
 *                                    Only \ref nvxcu_pitch_linear_image_t is supported.
 *                                    Width must be divisible by \a D
 * \param [out] block_cost        Specifies the resulting cost volume.
 *                                    It must have the same size and format as \a pixel_cost.
 * \param [in]  D                 Specifies the number of disparities in cost volume (maxD - minD).
 * \param [in]  win_size          Specifies the convolution window size.
 * \param [in]  exec_target       Specifies the execution target.
 *                                    Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuConvolveCost(const nvxcu_image_t* pixel_cost,
                                                 const nvxcu_image_t* block_cost,
                                                 int32_t D,
                                                 int32_t win_size,
                                                 const nvxcu_exec_target_t* exec_target);

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Aggregate cost volume over multiple scan lines.
 * \details @see @cite SGBM2007
 *
 * \param [in]  input_cost        Specifies the input cost volume.
 *                                    Only `NVXCU_DF_IMAGE_U8` format is supported.
 *                                    Only \ref nvxcu_pitch_linear_image_t is supported.
 *                                    Width must be divisible by \a D
 * \param [out] output_cost       Specifies the resulting aggregated cost volume.
 *                                    Only `NVXCU_DF_IMAGE_S16` format is supported.
 *                                    Only \ref nvxcu_pitch_linear_image_t is supported.
 *                                    It must have the same size as \a input_cost.
 * \param [in]  D                 Specifies the number of disparities in cost volume (maxD - minD).
 * \param [in]  P1                Specifies the smoothness penalty.
 * \param [in]  P2                Specifies the discontiguous penalty. P2 must be greater than P1.
 * \param [in]  scanlines_mask    Specifies the mask of scan line directions. Any bitwise-OR of nvxcu_scanline_e values is suitable.
 * \param [in]  exec_target       Specifies the execution target.
 *                                    Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuAggregateCostScanlines(const nvxcu_image_t* input_cost,
                                                           const nvxcu_image_t* output_cost,
                                                           int32_t D,
                                                           int32_t P1,
                                                           int32_t P2,
                                                           nvxcu_scanline_e scanlines_mask,
                                                           const nvxcu_exec_target_t* exec_target);

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Compute disparity image given the aggregated cost.
 *
 * \details @see @cite SGBM2007
 *
 * \param [in]  cost              Specifies the input cost volume.
 *                                    Only `NVXCU_DF_IMAGE_S16` format is supported.
 *                                    Only \ref nvxcu_pitch_linear_image_t is supported.
 *                                    Width must be divisible by (maxD - minD)
 * \param [out] disparity         Specifies the resulting disparity map. It contains values from minD-1 to maxD (exclusive)
 *                                represented in Q11.4 format.
 *                                    Only `NVXCU_DF_IMAGE_S16` format is supported.
 *                                    The \a disparity image must have the
 *                                    size of WxH if (W*D)xH is the size of the
 *                                    \a cost image (D = maxD - minD).
 * \param [in]  minD              Specifies the minimum disparity value.
 * \param [in]  maxD              Specifies the maximum disparity value.
 * \param [in]  uniqueness        Specifies the margin in percentage by which the best (minimum) computed cost function value
 *                                should the second best value to consider the found match correct.
 * \param [in]  maxDiff           Specifies the maximum allowed difference (in integer pixel units) in the left-right disparity check.
 * \param [in]  exec_target       Specifies the execution target.
 *                                    Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuComputeDisparity(const nvxcu_image_t* cost,
                                                     const nvxcu_image_t* disparity,
                                                     int32_t minD,
                                                     int32_t maxD,
                                                     int32_t uniqueness,
                                                     int32_t maxDiff,
                                                     const nvxcu_exec_target_t* exec_target);


//----------------------------------------------------------------------------
// Cost Prior
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Sets the cost of the maximum disparity value to zero if this (or
 *        larger) value was established on a lower-resolution level. This gives
 *        a strong prior in the higher resolution SGM result towards the
 *        subsampled SGM result for large disparities.
 *
 * \details @see @cite SGBM2007
 *
 * \param [in]  prev            Specifies the disparity image from the previous pyramid level
 *                                  Only \ref NVXCU_DF_IMAGE_S16 format is supported.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 *                                  Width must be divisible by 4
 * \param [out] cost            Specifies the cost on the current step.
 *                                  It must have the size 2*W*Dx2*H and
 *                                  NVXCU_DF_IMAGE_U8 format (where WxH is the
 *                                  size of prev).
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  D               Specifies the size of the disparity range.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */

NVX_C_API nvxcu_error_status_e nvxcuPSGMCostPrior(const nvxcu_image_t* prev,
                                                  const nvxcu_image_t* cost,
                                                  int32_t D,
                                                  const nvxcu_exec_target_t* exec_target);


//----------------------------------------------------------------------------
// Disparity Merge
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Merges the disparity from previous level of pyramid to the current
 *        level. If the disparity on the current level is closer than 1px to
 *        maximum, the disparity from the previous level is taken. Thus, small
 *        disparity values are taken from higher resolution images.
 *
 * \details @see @cite SGBM2007
 *
 * \param [in]  prev            Specifies the disparity image from the previous pyramid level
 *                                  Only \ref NVXCU_DF_IMAGE_S16 format is supported.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 *                                  Width must be divisible by 4
 * \param [out] curr            Specifies the disparity image from the current pyramid level.
 *                                  It must have the same size and format as \a prev.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  D               Specifies the size of disparity range.
 * \param [in]  exec_target     Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */

NVX_C_API nvxcu_error_status_e nvxcuPSGMDisparityMerge(const nvxcu_image_t* prev,
                                                       const nvxcu_image_t* curr,
                                                       int32_t D,
                                                       const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// Census Transform
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Applies Census Transform to an image.
 *
 * \details @see @cite SGBM2007
 *
 * \param [in]  src               Specifies the source image (grayscale)
 *                                  Only \ref NVXCU_DF_IMAGE_U8 format is supported.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported
 *                                  Width must be divisible by 4
 * \param [out] dst               Specifies the destination image
 *                                  Only \ref NVXCU_DF_IMAGE_U32 format is supported.
 *                                  The \a dst image must have the same size as the \a src image.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported
 * \param [in]  win_size          Specifies the window size of the transform
 *                                  Must be an odd positive integer.
 * \param [in]  exec_target       Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */

NVX_C_API nvxcu_error_status_e nvxcuCensusTransform(const nvxcu_image_t* src,
                                                    const nvxcu_image_t* dst,
                                                    int32_t win_size,
                                                    const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// Compute Cost Hamming
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Hamming cost function
 *
 * \details @see @cite SGBM2007
 *
 * \param [in]  left              Specifies the left stereo image
 *                                  Only \ref NVXCU_DF_IMAGE_U32 format is supported.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported
 *                                  Width must be divisible by 4
 * \param [in]  right             Specifies the right stereo image
 *                                  The \a right image must have the same size and type as the \a left image.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] cost              Specifies the resulting cost.
 *                                  The size of the \a cost image must be W*D x H,
 *                                  where W and H are the width and height of the
 *                                  \a left image, and D = maxD - minD.
 *                                  Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  minD              Specifies the minimum disparity value.
 * \param [in]  maxD              Specifies the maximum disparity value.
 * \param [in]  win_size          Specifies the window size of the cost function
 *                                  Must be an odd positive integer.
 * \param [in]  exec_target       Specifies the execution target.
 *                                  Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */

NVX_C_API nvxcu_error_status_e nvxcuComputeCostHamming(const nvxcu_image_t* left,
                                                       const nvxcu_image_t* right,
                                                       const nvxcu_image_t* cost,
                                                       int32_t minD,
                                                       int32_t maxD,
                                                       int32_t win_size,
                                                       const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// HoughLines
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Determine the size of CUDA Device and HOST memory that must be passed to the \ref nvxcuHoughLines primitive.
 *
 * \see \ref nvxcu_tmp_buf_size_t
 *
 * \param [in] width            Specifies the input image width.
 * \param [in] height           Specifies the input image height.
 * \param [in] format           Specifies the input image format.
 * \param [in] arr_capacity     Specifies the output array capacity.
 * \param [in] rho              Specifies the distance resolution of the accumulator in pixels.
 * \param [in] theta            Specifies the angle resolution of the accumulator in radians.
 * \param [in] prop             Specifies the CUDA device properties for current active device.
 *
 * \return The size of temporary CUDA Device and HOST buffers.
 */
NVX_C_API nvxcu_tmp_buf_size_t nvxcuHoughLines_GetBufSize(uint32_t width, uint32_t height, nvxcu_df_image_e format,
                                                          uint32_t arr_capacity,
                                                          float rho, float theta,
                                                          const struct cudaDeviceProp* prop);

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Finds lines on image using standard Hough transform.
 * \details
 * \see \cite Tomasi98
 *
 * Two parameters \f$ (\rho, \theta) \f$ are used to determine a line in the algorithm.
 *
 * \f$ \rho \f$ is the distance from the coordinate origin.
 * \f$ (0, 0) \f$ the coordinate origin (top-left corner of the image).
 *
 * \f$ \theta \f$ is the line rotation angle in radians.
 * \f$ (0 \sim \textrm{vertical line}, \pi/2 \sim \textrm{horizontal line}) \f$.
 *
 * \param [in]  input               Specifies the input image.
 *                                      Only \ref NVXCU_DF_IMAGE_U8 format is supported.
 *                                      The image width and height must be less than \f$ 2^{16} \f$.
 *                                      Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] output               Specifies the output lines list.
 *                                      Only \ref NVXCU_TYPE_POINT3F item type is supported.
 *                                      Only \ref nvxcu_plain_array_t is supported.
 * \param [in]  rho                 Specifies the distance resolution of the accumulator in pixels.
 *                                      It must be a positive value.
 * \param [in]  theta               Specifies the angle resolution of the accumulator in radians.
 *                                      It must be in range \f$ (0, \pi] \f$.
 * \param [in]  threshold           Specifies the accumulator threshold parameter.
 *                                      Only lines that get enough votes (> \a threshold) are returned.
 * \param [out] num_lines_dev_ptr   Specifies the CUDA device pointer to the total number of detected lines.
 * \param [in]  tmp_buf             Specifies the pointers to temporary buffers.
 *                                      Use \ref nvxcuHoughLines_GetBufSize to get size of the buffers.
 * \param [in]  exec_target         Specifies the execution target.
 *                                      Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuHoughLines(const nvxcu_image_t* input,
                                               const nvxcu_array_t* output,
                                               float rho, float theta, uint32_t threshold,
                                               uint32_t *num_lines_dev_ptr,
                                               const nvxcu_tmp_buf_t* tmp_buf,
                                               const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// HoughSegments
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Determine the size of CUDA Device and HOST memory that must be passed to the \ref nvxcuHoughSegments primitive.
 *
 * \see \ref nvxcu_tmp_buf_size_t
 *
 * \param [in] width                Specifies the input image width.
 * \param [in] height               Specifies the input image height.
 * \param [in] format               Specifies the input image format.
 * \param [in] arr_capacity         Specifies the output array capacity.
 * \param [in] rho                  Specifies the distance resolution of the accumulator in pixels.
 * \param [in] theta                Specifies the angle resolution of the accumulator in radians.
 * \param [in] min_line_length      Specifies the minimum line length. Shorter segments are rejected.
 * \param [in] max_line_gap         Specifies the maximum allowed gap between points on the same line to link them.
 * \param [in] prop                 Specifies the CUDA device properties for current active device.
 *
 * \return The size of temporary CUDA Device and HOST buffers.
 */
NVX_C_API nvxcu_tmp_buf_size_t nvxcuHoughSegments_GetBufSize(uint32_t width, uint32_t height, nvxcu_df_image_e format,
                                                             uint32_t arr_capacity,
                                                             float rho, float theta,
                                                             uint32_t min_line_length, uint32_t max_line_gap,
                                                             const struct cudaDeviceProp* prop);

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Finds line segments in a binary image using the probabilistic Hough transform.
 * \details
 * \see \cite MatasGK00.
 *
 * Four parameters \f$ (x_1, y_1, x_2, y_2) \f$ are used to determine a line segment,
 * where \f$ (x_1, y_1) \f$ and \f$ (x_2, y_2) \f$ are the ending points of each detected line segment.
 *
 * Probabilistic Hough transform is more efficient if the picture contains
 * a few long linear segments. It returns line segments rather than the whole line.
 *
 * \param [in]  input                   Specifies the input image (8-bit grayscale).
 *                                          Only \ref NVXCU_DF_IMAGE_U8 format is supported.
 *                                          The image width and height must be less than \f$ 2^{16} \f$.
 *                                          Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] output                  Specifies the output lines list.
 *                                          Only \ref NVXCU_TYPE_POINT4F item type is supported.
 *                                          Only \ref nvxcu_plain_array_t is supported.
 * \param [in]  rho                     Specifies the distance resolution of the accumulator in pixels.
 *                                          It must be a positive value.
 * \param [in]  theta                   Specifies the angle resolution of the accumulator in radians.
 *                                          It must be in range \f$ (0, \pi] \f$.
 * \param [in]  threshold               Specifies the accumulator threshold parameter.
 *                                          Only lines that get enough votes (> \a threshold) are returned.
 * \param [in]  min_line_length         Specifies the minimum line length. Shorter segments are rejected.
 * \param [in]  max_line_gap            Specifies the maximum allowed gap between points on the same line to link them.
 * \param [out] num_segments_dev_ptr    Specifies the CUDA device pointer to the total number of detected segments.
 * \param [in]  tmp_buf                 Specifies the pointers to temporary buffers.
 *                                          Use \ref nvxcuHoughSegments_GetBufSize to get size of the buffers.
 * \param [in]  exec_target             Specifies the execution target.
 *                                          Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuHoughSegments(const nvxcu_image_t* input,
                                                  const nvxcu_array_t* output,
                                                  float rho, float theta, uint32_t threshold,
                                                  uint32_t min_line_length, uint32_t max_line_gap,
                                                  uint32_t *num_segments_dev_ptr,
                                                  const nvxcu_tmp_buf_t* tmp_buf,
                                                  const nvxcu_exec_target_t* exec_target);

//----------------------------------------------------------------------------
// HoughCircles
//----------------------------------------------------------------------------

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Determine the size of CUDA Device and HOST memory that must be passed to the \ref nvxcuHoughCircles primitive.
 *
 * \see \ref nvxcu_tmp_buf_size_t
 *
 * \param [in] width            Specifies the input image width.
 * \param [in] height           Specifies the input image height.
 * \param [in] format           Specifies the input image format.
 * \param [in] arr_capacity     Specifies the output array capacity.
 * \param [in] dp               Specifies the inverse ratio of the accumulator resolution to the image resolution.
 * \param [in] min_dist         Specifies the minimum distance between the centers of the detected circles.
 * \param [in] min_radius       Specifies the minimum circle radius.
 * \param [in] max_radius       Specifies the maximum circle radius.
 * \param [in] prop             Specifies the CUDA device properties for current active device.
 *
 * \return The size of temporary CUDA Device and HOST buffers.
 */
NVX_C_API nvxcu_tmp_buf_size_t nvxcuHoughCircles_GetBufSize(uint32_t width, uint32_t height, nvxcu_df_image_e format,
                                                            uint32_t arr_capacity,
                                                            float dp, float min_dist,
                                                            uint32_t min_radius, uint32_t max_radius,
                                                            const struct cudaDeviceProp* prop);

/**
 * \ingroup nvx_cuda_api_primitives
 * \brief Detects circles in a binary image.
 * \details
 * This kernel uses a modified version of the Hough transform.
 *
 * \see \cite Yuen89acomparative
 *
 * \param [in]  edges                   Specifies the input binary image with edges
 *                                          (for example, output from \ref nvxcuCannyEdgeDetector).
 *                                          Only \ref NVXCU_DF_IMAGE_U8 format is supported.
 *                                          Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  dx                      Specifies the input image with horizontal derivatives
 *                                          (for example, output from \ref nvxcuSobel3x3).
 *                                          Only \ref NVXCU_DF_IMAGE_S16 format is supported.
 *                                          It must have the same size as \p edges image.
 *                                          Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [in]  dy                      Specifies the input image with vertical derivatives
 *                                          (for example, output from \ref nvxcuSobel3x3).
 *                                          Only \ref NVXCU_DF_IMAGE_S16 format is supported.
 *                                          It must have the same size as \p edges image.
 *                                          Only \ref nvxcu_pitch_linear_image_t is supported.
 * \param [out] circles                 Specifies the output array with detected circles.
 *                                          Each circle is encoded as a \ref NVXCU_TYPE_POINT3F (x, y, radius).
 *                                          Only \ref nvxcu_plain_array_t is supported.
 * \param [out] num_detections_dev_ptr  Specifies the CUDA device pointer to the total number of detected circles.
 * \param [in]  dp                      Specifies the inverse ratio of the accumulator resolution to the image resolution.
 *                                          For example, if `dp=1`, the accumulator has the same resolution as the input image.
 *                                          If `dp=2`, the accumulator has the width and height twice as small as the input image.
 *                                          It must be greater or equal than 1.
 * \param [in]  min_dist                Specifies the minimum distance between the centers of the detected circles.
 *                                          If the parameter is too small, multiple neighbor circles may be falsely detected
 *                                          in addition to a true one.
 *                                          If it is too large, some circles may be missed.
 *                                          It must be a positive value.
 * \param [in]  min_radius              Specifies the minimum circle radius.
 * \param [in]  max_radius              Specifies the maximum circle radius.
 *                                          It must not be less than \p min_radius.
 * \param [in]  acc_threshold           Specifies the accumulator threshold for the circle centers at the detection stage.
 *                                          The smaller the threshold is, the more false circles may be detected.
 *                                          Circles corresponding to the larger accumulator values are returned first.
 * \param [in]  tmp_buf                 Specifies the pointers to temporary buffers.
 *                                          Use \ref nvxcuHoughCircles_GetBufSize to get size of the buffers.
 * \param [in]  exec_target             Specifies the execution target.
 *                                          Only \ref nvxcu_stream_exec_target_t is supported.
 *
 * \return An \ref nvxcu_error_status_e code.
 */
NVX_C_API nvxcu_error_status_e nvxcuHoughCircles(const nvxcu_image_t* edges,
                                                 const nvxcu_image_t* dx,
                                                 const nvxcu_image_t* dy,
                                                 const nvxcu_array_t* circles,
                                                 uint32_t *num_detections_dev_ptr,
                                                 float dp,
                                                 float min_dist,
                                                 uint32_t min_radius, uint32_t max_radius,
                                                 uint32_t acc_threshold,
                                                 const nvxcu_tmp_buf_t* tmp_buf,
                                                 const nvxcu_exec_target_t* exec_target);

#endif
